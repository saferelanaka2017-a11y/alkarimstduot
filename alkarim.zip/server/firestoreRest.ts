import fs from 'node:fs';
import path from 'node:path';

interface FirebaseConfig {
  projectId: string;
  firestoreDatabaseId: string;
}

const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
const firebaseConfig: FirebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

type FirestoreValue =
  | { stringValue: string }
  | { integerValue: string }
  | { doubleValue: number }
  | { booleanValue: boolean }
  | { timestampValue: string }
  | { arrayValue: { values?: FirestoreValue[] } }
  | { mapValue: { fields?: Record<string, FirestoreValue> } }
  | { nullValue: null };

function decodeFirestoreValue(val: FirestoreValue | undefined): unknown {
  if (!val) return undefined;
  if ('stringValue' in val) return val.stringValue;
  if ('integerValue' in val) return Number(val.integerValue);
  if ('doubleValue' in val) return val.doubleValue;
  if ('booleanValue' in val) return val.booleanValue;
  if ('timestampValue' in val) return val.timestampValue;
  if ('nullValue' in val) return null;
  if ('arrayValue' in val) {
    return (val.arrayValue.values || []).map((v) => decodeFirestoreValue(v));
  }
  if ('mapValue' in val) {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(val.mapValue.fields || {})) {
      out[k] = decodeFirestoreValue(v);
    }
    return out;
  }
  return undefined;
}

function decodeDoc(doc: { name?: string; fields?: Record<string, FirestoreValue> }): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(doc.fields || {})) {
    out[k] = decodeFirestoreValue(v);
  }
  return out;
}

const FIRESTORE_BASE = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId}/documents`;

export async function fetchPublicAppsFromFirestore(): Promise<Record<string, unknown>[]> {
  try {
    const url = `${FIRESTORE_BASE}:runQuery`;
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        structuredQuery: {
          from: [{ collectionId: 'apps' }],
          where: {
            fieldFilter: {
              field: { fieldPath: 'visibility' },
              op: 'EQUAL',
              value: { stringValue: 'public' },
            },
          },
          limit: 50,
        },
      }),
    });
    if (!resp.ok) return [];
    const rows = (await resp.json()) as Array<{ document?: { name?: string; fields?: Record<string, FirestoreValue> } }>;
    return rows.filter((r) => r.document).map((r) => decodeDoc(r.document!));
  } catch {
    return [];
  }
}

export async function fetchPublicAppBySlug(slug: string): Promise<{
  app: Record<string, unknown> | null;
  releases: Record<string, unknown>[];
}> {
  if (!/^[a-z0-9-]+$/.test(slug)) {
    return { app: null, releases: [] };
  }
  try {
    const resp = await fetch(`${FIRESTORE_BASE}:runQuery`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        structuredQuery: {
          from: [{ collectionId: 'apps' }],
          where: {
            compositeFilter: {
              op: 'AND',
              filters: [
                {
                  fieldFilter: {
                    field: { fieldPath: 'visibility' },
                    op: 'EQUAL',
                    value: { stringValue: 'public' },
                  },
                },
                {
                  fieldFilter: {
                    field: { fieldPath: 'slug' },
                    op: 'EQUAL',
                    value: { stringValue: slug },
                  },
                },
              ],
            },
          },
          limit: 1,
        },
      }),
    });
    if (!resp.ok) return { app: null, releases: [] };
    const rows = (await resp.json()) as Array<{ document?: { name?: string; fields?: Record<string, FirestoreValue> } }>;
    const doc = rows.find((r) => r.document)?.document;
    if (!doc) return { app: null, releases: [] };

    const app = decodeDoc(doc);
    const appId = String(app.id || '');
    if (!/^[a-zA-Z0-9_-]+$/.test(appId)) {
      return { app, releases: [] };
    }

    const relResp = await fetch(`${FIRESTORE_BASE}/apps/${appId}:runQuery`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        structuredQuery: {
          from: [{ collectionId: 'releases' }],
          where: {
            fieldFilter: {
              field: { fieldPath: 'visibility' },
              op: 'EQUAL',
              value: { stringValue: 'public' },
            },
          },
          limit: 25,
        },
      }),
    });
    if (!relResp.ok) return { app, releases: [] };
    const relRows = (await relResp.json()) as Array<{ document?: { fields?: Record<string, FirestoreValue> } }>;
    const releases = relRows.filter((r) => r.document).map((r) => decodeDoc(r.document!));
    return { app, releases };
  } catch {
    return { app: null, releases: [] };
  }
}

async function queryPackageChunksInApp(
  appId: string,
  packageId: string,
  authHeader?: string
): Promise<Buffer | null> {
  if (!/^[a-zA-Z0-9_-]+$/.test(appId)) return null;
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (authHeader && authHeader.startsWith('Bearer ')) {
    headers.Authorization = authHeader;
  }
  const resp = await fetch(`${FIRESTORE_BASE}/apps/${appId}:runQuery`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      structuredQuery: {
        from: [{ collectionId: 'package_chunks' }],
        where: {
          fieldFilter: {
            field: { fieldPath: 'packageId' },
            op: 'EQUAL',
            value: { stringValue: packageId },
          },
        },
        limit: 8,
      },
    }),
  });
  if (!resp.ok) return null;
  const rows = (await resp.json()) as Array<{ document?: { fields?: Record<string, FirestoreValue> } }>;
  const docs = rows.filter((r) => r.document).map((r) => decodeDoc(r.document!));
  if (docs.length === 0) return null;

  const expectedTotal = Number(docs[0].totalChunks || 0);
  if (!Number.isInteger(expectedTotal) || expectedTotal < 1 || docs.length < expectedTotal) {
    return null;
  }

  const sorted = docs
    .filter((d) => typeof d.dataBase64 === 'string' && typeof d.chunkIndex === 'number')
    .sort((a, b) => Number(a.chunkIndex) - Number(b.chunkIndex));
  if (sorted.length < expectedTotal) return null;

  const buffers: Buffer[] = [];
  for (let i = 0; i < expectedTotal; i++) {
    const chunk = sorted[i];
    if (!chunk || Number(chunk.chunkIndex) !== i) return null;
    buffers.push(Buffer.from(String(chunk.dataBase64), 'base64'));
  }
  return Buffer.concat(buffers);
}

export async function restorePackageBufferFromFirestore(
  packageId: string,
  options?: { appId?: string; authHeader?: string }
): Promise<Buffer | null> {
  if (!packageId || packageId.startsWith('pkg-')) return null;
  try {
    if (options?.appId) {
      const direct = await queryPackageChunksInApp(options.appId, packageId, options.authHeader);
      if (direct) return direct;
    }
    const apps = await fetchPublicAppsFromFirestore();
    for (const appDoc of apps) {
      const candidateAppId = String(appDoc.id || '');
      if (!candidateAppId || candidateAppId === options?.appId) continue;
      const buf = await queryPackageChunksInApp(candidateAppId, packageId, options?.authHeader);
      if (buf) return buf;
    }
    return null;
  } catch {
    return null;
  }
}
