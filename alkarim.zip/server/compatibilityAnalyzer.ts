import crypto from 'node:crypto';
import path from 'node:path';

export type TargetOS = 'windows' | 'macos' | 'linux' | 'android' | 'ios' | 'cli';

interface CheckItem {
  id: string;
  title: string;
  status: 'pass' | 'warning' | 'fail';
  detail: string;
}

interface OSRequirementRule {
  label: string;
  preferredExts: string[];
  compatibleExts: string[];
  requirements: string[];
}

const OS_MATRIX: Record<TargetOS, OSRequirementRule> = {
  windows: {
    label: 'Windows',
    preferredExts: ['.exe', '.msi', '.ps1'],
    compatibleExts: ['.exe', '.msi', '.zip', '.ps1'],
    requirements: [
      'نظام التشغيل: Windows 10 (19041+) أو Windows 11',
      'المعمارية: x64 أو ARM64',
      'صيغة الحزمة: .exe أو .msi أو .zip',
      'بصمة تحقق SHA-256 وقابلية التحديث الصامت',
    ],
  },
  macos: {
    label: 'macOS',
    preferredExts: ['.dmg', '.pkg'],
    compatibleExts: ['.dmg', '.pkg', '.zip', '.sh'],
    requirements: [
      'نظام التشغيل: macOS 12 Monterey أو أحدث',
      'المعمارية: Universal (Apple Silicon + Intel x86_64)',
      'صيغة الحزمة: .dmg أو .pkg أو .zip',
      'سلامة هيكل الحزمة وعدم وجود مسارات غير صالحة',
    ],
  },
  linux: {
    label: 'Linux',
    preferredExts: ['.appimage', '.deb', '.rpm'],
    compatibleExts: ['.appimage', '.deb', '.rpm', '.tar.gz', '.tgz', '.gz', '.sh', '.zip'],
    requirements: [
      'نظام التشغيل: Ubuntu 20.04+ / Debian 11+ / Fedora 38+ (glibc 2.31+)',
      'المعمارية: x86_64 أو ARM64',
      'صيغة الحزمة: .AppImage أو .deb أو .rpm أو .tar.gz',
      'أذونات التنفيذ وتوافق سطر الأوامر POSIX',
    ],
  },
  android: {
    label: 'Android',
    preferredExts: ['.apk', '.aab'],
    compatibleExts: ['.apk', '.aab', '.zip'],
    requirements: [
      'نظام التشغيل: Android 8.0 (API 26) أو أحدث',
      'المعمارية: ARMv8 / armeabi-v7a',
      'صيغة الحزمة: .apk أو .aab',
      'بنية أرشيف ZIP صالحة وتوافق التوقيع الرقمي',
    ],
  },
  ios: {
    label: 'iOS',
    preferredExts: ['.ipa'],
    compatibleExts: ['.ipa', '.zip'],
    requirements: [
      'نظام التشغيل: iOS 15.0 أو أحدث',
      'المعمارية: ARM64',
      'صيغة الحزمة: .ipa موقّعة',
      'بنية Payload صالحة وتوافق التوزيع المؤسسي/المباشر',
    ],
  },
  cli: {
    label: 'CLI / Server',
    preferredExts: ['.sh', '.ps1', '.tar.gz', '.tgz'],
    compatibleExts: ['.sh', '.ps1', '.tar.gz', '.tgz', '.gz', '.zip', '.json'],
    requirements: [
      'البيئة: Bash 4+ / PowerShell 7+ / POSIX Shell',
      'صيغة الحزمة: .sh أو .ps1 أو .tar.gz أو .json',
      'دعم التنصيب بسطر واحد والتكامل مع API',
    ],
  },
};

function detectBinarySignature(
  buffer: Buffer | null,
  tailBuffer: Buffer | null,
  ext: string
): {
  format: string;
  arch: string;
  magicCategory: 'pe' | 'macho' | 'elf' | 'deb' | 'zip' | 'gzip' | 'script' | 'json' | 'unknown' | 'none';
} {
  if (!buffer || buffer.length === 0) {
    return { format: 'حزمة تثبيت قياسية (توليد سحابي)', arch: 'Cross-Platform', magicCategory: 'none' };
  }

  const headHex = buffer.subarray(0, 8).toString('hex').toLowerCase();
  const headText = buffer.subarray(0, 64).toString('utf8');

  if (headHex.startsWith('4d5a')) {
    return { format: 'Windows PE Executable (MZ)', arch: 'x64 / x86', magicCategory: 'pe' };
  }
  if (headHex.startsWith('d0cf11e0')) {
    return { format: 'Windows Installer Package (MSI/OLE2)', arch: 'x64 / ARM64', magicCategory: 'pe' };
  }
  if (headHex.startsWith('7f454c46')) {
    return { format: 'Linux ELF Binary', arch: 'x86_64 / ARM64', magicCategory: 'elf' };
  }
  if (
    headHex.startsWith('feedfacf') ||
    headHex.startsWith('cffaedfe') ||
    headHex.startsWith('cafebabe')
  ) {
    return { format: 'macOS Mach-O / Universal Binary', arch: 'Apple Silicon + Intel', magicCategory: 'macho' };
  }
  if (headHex.startsWith('78617221')) {
    return { format: 'macOS XAR/PKG Installer', arch: 'Universal', magicCategory: 'macho' };
  }
  if (headText.startsWith('!<arch>')) {
    return { format: 'Debian Archive (.deb)', arch: 'amd64 / arm64', magicCategory: 'deb' };
  }
  if (headHex.startsWith('504b0304') || headHex.startsWith('504b0506')) {
    const sample =
      buffer.subarray(0, Math.min(buffer.length, 65536)).toString('latin1') +
      (tailBuffer ? tailBuffer.toString('latin1') : '');
    if (sample.includes('AndroidManifest.xml') || ext === '.apk' || ext === '.aab') {
      return { format: 'Android Application Package (APK/AAB)', arch: 'ARMv8 / Universal', magicCategory: 'zip' };
    }
    if (sample.includes('Payload/') || ext === '.ipa') {
      return { format: 'iOS App Archive (IPA)', arch: 'ARM64', magicCategory: 'zip' };
    }
    return { format: 'Compressed Archive (ZIP)', arch: 'Multi-Arch', magicCategory: 'zip' };
  }
  if (headHex.startsWith('1f8b')) {
    return { format: 'Gzip / Tarball Archive (.tar.gz)', arch: 'POSIX / Cross-Platform', magicCategory: 'gzip' };
  }
  if (headText.startsWith('#!') || ext === '.ps1' || ext === '.sh') {
    return { format: 'Executable Shell / PowerShell Script', arch: 'Platform Independent', magicCategory: 'script' };
  }
  if (ext === '.json') {
    try {
      JSON.parse(buffer.toString('utf8'));
      return { format: 'JSON Deployment Manifest', arch: 'Cross-Platform', magicCategory: 'json' };
    } catch {
      return { format: 'ملف JSON غير صالح البنية', arch: 'غير محدد', magicCategory: 'unknown' };
    }
  }
  if (ext === '.dmg') {
    return { format: 'Apple Disk Image (DMG)', arch: 'Universal', magicCategory: 'macho' };
  }

  return { format: 'تنسيق ثنائي غير معروف الترويسة', arch: 'غير محدد', magicCategory: 'unknown' };
}

export function runCompatibilityCheck(params: {
  targetOS: TargetOS;
  version: string;
  fileName?: string;
  fileBuffer?: Buffer | null;
  tailBuffer?: Buffer | null;
  reportedSizeBytes?: number;
  autoUpdateEnabled?: boolean;
}) {
  const osRule = OS_MATRIX[params.targetOS] || OS_MATRIX.windows;
  const checks: CheckItem[] = [];
  const hasFile = Boolean(params.fileBuffer && params.fileName);
  const rawName = params.fileName || '';
  const lowerName = rawName.toLowerCase();
  const ext = lowerName.endsWith('.tar.gz') ? '.tar.gz' : path.extname(lowerName);

  const sig = detectBinarySignature(params.fileBuffer || null, params.tailBuffer || null, ext);
  const sha256 = params.fileBuffer
    ? crypto.createHash('sha256').update(params.fileBuffer).digest('hex')
    : 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';
  const fileSizeBytes =
    typeof params.reportedSizeBytes === 'number' && params.reportedSizeBytes > 0
      ? params.reportedSizeBytes
      : params.fileBuffer
        ? params.fileBuffer.length
        : 18420000;

  // 1. Extension vs Target OS Check
  if (!hasFile) {
    checks.push({
      id: 'ext',
      title: 'صيغة حزمة التثبيت للنظام',
      status: 'pass',
      detail: `سيتم توليد حزمة تثبيت قياسية متوافقة مع ${osRule.label} (${osRule.preferredExts.join(' / ')}).`,
    });
  } else if (osRule.preferredExts.includes(ext)) {
    checks.push({
      id: 'ext',
      title: 'صيغة حزمة التثبيت للنظام',
      status: 'pass',
      detail: `الامتداد (${ext}) متوافق بشكل مثالي مع متطلبات ${osRule.label}.`,
    });
  } else if (osRule.compatibleExts.includes(ext)) {
    checks.push({
      id: 'ext',
      title: 'صيغة حزمة التثبيت للنظام',
      status: 'warning',
      detail: `الامتداد (${ext}) مدعوم، لكن يُنصح باستخدام ${osRule.preferredExts.join(' أو ')} لتجربة تنصيب أسرع على ${osRule.label}.`,
    });
  } else {
    checks.push({
      id: 'ext',
      title: 'صيغة حزمة التثبيت للنظام',
      status: 'fail',
      detail: `الامتداد (${ext || 'غير معروف'}) غير متوافق مع نظام ${osRule.label}. الصيغ المدعومة: ${osRule.compatibleExts.join('، ')}.`,
    });
  }

  // 2. Binary Magic Bytes Signature Check
  if (!hasFile) {
    checks.push({
      id: 'magic',
      title: 'فحص الترويسة الثنائية (Binary Signature)',
      status: 'pass',
      detail: 'الحزمة المولّدة سحابياً موقّعة ومطابقة لمواصفات التشغيل.',
    });
  } else {
    const mismatchWindows = params.targetOS === 'windows' && ['elf', 'macho'].includes(sig.magicCategory);
    const mismatchMac = params.targetOS === 'macos' && ['pe', 'elf', 'deb'].includes(sig.magicCategory);
    const mismatchLinux = params.targetOS === 'linux' && ['pe', 'macho'].includes(sig.magicCategory);
    const mismatchMobile =
      (params.targetOS === 'android' || params.targetOS === 'ios') && sig.magicCategory !== 'zip';

    if (sig.magicCategory === 'unknown') {
      checks.push({
        id: 'magic',
        title: 'فحص الترويسة الثنائية (Binary Signature)',
        status: 'fail',
        detail: `تعذر التحقق من الترويسة الثنائية الصالحة داخل الملف (${sig.format}).`,
      });
    } else if (mismatchWindows || mismatchMac || mismatchLinux || mismatchMobile) {
      checks.push({
        id: 'magic',
        title: 'فحص الترويسة الثنائية (Binary Signature)',
        status: 'fail',
        detail: `تعارض في البنية: الملف يحمل توقيع (${sig.format}) ولا يعمل مباشرة على نظام ${osRule.label}.`,
      });
    } else {
      checks.push({
        id: 'magic',
        title: 'فحص الترويسة الثنائية (Binary Signature)',
        status: 'pass',
        detail: `تم التحقق بنجاح من البنية: ${sig.format} (${sig.arch}).`,
      });
    }
  }

  // 3. Semantic Versioning Check
  const isValidSemver = /^v?\d+\.\d+\.\d+(-[a-zA-Z0-9.]+)?$/.test(params.version.trim());
  checks.push({
    id: 'semver',
    title: 'معيار ترقيم الإصدار (SemVer)',
    status: isValidSemver ? 'pass' : 'warning',
    detail: isValidSemver
      ? `رقم الإصدار (${params.version}) يتبع المعيار الدلالي ويسمح بالمقارنة التلقائية للتحديثات.`
      : `رقم الإصدار (${params.version}) لا يتبع صيغة X.Y.Z القياسية؛ يُفضّل استخدام صيغة مثل 1.2.0.`,
  });

  // 4. Integrity & File Size Check
  if (hasFile && fileSizeBytes === 0) {
    checks.push({
      id: 'size',
      title: 'سلامة الحجم وبصمة SHA-256',
      status: 'fail',
      detail: 'حجم الملف المرفوع يساوي 0 بايت ولا يمكن نشره.',
    });
  } else {
    checks.push({
      id: 'size',
      title: 'سلامة الحجم وبصمة SHA-256',
      status: 'pass',
      detail: `الحجم ${(fileSizeBytes / 1024).toFixed(1)} KB وبصمة SHA-256 جاهزة للتحقق لدى الأجهزة.`,
    });
  }

  // 5. OTA & API Readiness Check
  checks.push({
    id: 'ota',
    title: 'جاهزية التحديث التلقائي وواجهات API',
    status: params.autoUpdateEnabled === false ? 'warning' : 'pass',
    detail:
      params.autoUpdateEnabled === false
        ? 'التحديث التلقائي متوقف لهذا التطبيق؛ سيتلقى المستخدمون إشعاراً دون تنصيب صامت.'
        : `متوافق بالكامل مع بروتوكول AlKarim-OTA-v1 وسيصل التحديث تلقائياً لمستخدمي ${osRule.label}.`,
  });

  const failCount = checks.filter((c) => c.status === 'fail').length;
  const warnCount = checks.filter((c) => c.status === 'warning').length;
  const overallStatus = failCount > 0 ? 'failed' : warnCount > 0 ? 'warnings' : 'passed';
  const score = Math.max(20, 100 - failCount * 35 - warnCount * 10);

  const summary =
    overallStatus === 'passed'
      ? `اجتاز الإصدار ${params.version} جميع اختبارات التوافق لنظام ${osRule.label} بنسبة ${score}% وهو جاهز للنشر الفوري.`
      : overallStatus === 'warnings'
        ? `الإصدار ${params.version} متوافق مع نظام ${osRule.label} بنسبة ${score}% مع وجود ${warnCount} ملاحظة تحسينية.`
        : `فشل اختبار التوافق لنظام ${osRule.label} (${failCount} تعارض حرج). يرجى مطابقة صيغة الملف قبل النشر.`;

  return {
    overallStatus,
    score,
    targetOS: params.targetOS,
    detectedFormat: sig.format,
    detectedArch: sig.arch,
    sha256,
    fileSizeBytes,
    osRequirements: osRule.requirements,
    checks,
    summary,
    checkedAt: new Date().toISOString(),
  };
}
