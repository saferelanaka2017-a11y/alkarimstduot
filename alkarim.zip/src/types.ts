export type TargetOS = 'windows' | 'macos' | 'linux' | 'android' | 'ios' | 'cli';
export type ReleaseChannel = 'stable' | 'beta' | 'canary';
export type AppCategory = 'productivity' | 'developer' | 'security' | 'utilities' | 'media' | 'enterprise';
export type AppVisibility = 'public' | 'private';
export type ReleaseStatus = 'published' | 'scheduled';
export type ReportPeriod = 'daily' | 'weekly' | 'monthly';

export type NavSection =
  | 'analytics'
  | 'apps'
  | 'portal'
  | 'api'
  | 'reports'
  | 'security';

export interface UserProfile {
  uid: string;
  displayName: string;
  photoURL: string;
  role: 'user' | 'developer' | 'admin';
  twoFactorEnabled: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface UserPrivateSecurity {
  email: string;
  provider: string;
  twoFactorEnabled: boolean;
  totpSecret: string;
  backupCodesCount: number;
  updatedAt?: unknown;
}

export interface SoftwareApp {
  id: string;
  slug: string;
  ownerId: string;
  ownerName: string;
  name: string;
  description: string;
  category: AppCategory;
  iconUrl: string;
  latestVersion: string;
  channel: ReleaseChannel;
  autoUpdate: boolean;
  mandatoryUpdate: boolean;
  supportedOS: TargetOS[];
  downloadsCount: number;
  activeUsersCount: number;
  crashFreeRate: number;
  apiEnabled: boolean;
  visibility: AppVisibility;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface AppRelease {
  id: string;
  appId: string;
  ownerId: string;
  version: string;
  channel: ReleaseChannel;
  targetOS: TargetOS;
  fileName: string;
  fileSizeBytes: number;
  sha256: string;
  downloadUrl: string;
  releaseNotes: string;
  mandatory: boolean;
  visibility: AppVisibility;
  status?: ReleaseStatus;
  scheduledFor?: string;
  downloads: number;
  createdAt?: unknown;
}

export interface ApiKeyRecord {
  id: string;
  ownerId: string;
  appId: string;
  label: string;
  prefix: string;
  keyHash: string;
  scopes: string[];
  status: 'active' | 'revoked';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface PeriodicReport {
  id: string;
  ownerId: string;
  appId: string;
  appName: string;
  period: ReportPeriod;
  totalDownloads: number;
  activeUsers: number;
  autoUpdateRate: number;
  crashFreeRate: number;
  summary: string;
  createdAt?: unknown;
}

export type CompatibilityStatus = 'passed' | 'warnings' | 'failed';
export type CheckItemStatus = 'pass' | 'warning' | 'fail';

export interface CompatibilityCheckItem {
  id: string;
  title: string;
  status: CheckItemStatus;
  detail: string;
}

export interface CompatibilityCheckResult {
  overallStatus: CompatibilityStatus;
  score: number;
  targetOS: TargetOS;
  detectedFormat: string;
  detectedArch: string;
  sha256: string;
  fileSizeBytes: number;
  osRequirements: string[];
  checks: CompatibilityCheckItem[];
  summary: string;
  checkedAt: string;
}

export interface CompatibilityReportRecord {
  id: string;
  appId: string;
  ownerId: string;
  version: string;
  targetOS: TargetOS;
  overallStatus: CompatibilityStatus;
  score: number;
  detectedFormat: string;
  summary: string;
  createdAt?: unknown;
}

export type DateRangePreset = '24h' | '7d' | '30d' | '90d' | 'custom';

export interface DateRangeFilter {
  preset: DateRangePreset;
  fromDate: string; // YYYY-MM-DD
  toDate: string;   // YYYY-MM-DD
}

export const OS_LABELS: Record<TargetOS, { label: string; arch: string; ext: string }> = {
  windows: { label: 'Windows', arch: 'x64 / ARM64', ext: '.exe / .msi' },
  macos: { label: 'macOS', arch: 'Universal (Apple Silicon & Intel)', ext: '.dmg / .pkg' },
  linux: { label: 'Linux', arch: 'x86_64 / ARM64', ext: '.AppImage / .deb' },
  android: { label: 'Android', arch: 'ARMv8 / Universal', ext: '.apk / .aab' },
  ios: { label: 'iOS', arch: 'ARM64', ext: '.ipa' },
  cli: { label: 'CLI / Server', arch: 'Cross-Platform', ext: '.sh / .tar.gz' },
};

export const CATEGORY_LABELS: Record<AppCategory, string> = {
  productivity: 'الإنتاجية والأعمال',
  developer: 'أدوات المطورين',
  security: 'الأمن السيبراني',
  utilities: 'أدوات النظام',
  media: 'الوسائط والتصميم',
  enterprise: 'الأنظمة المؤسسية',
};

export const CHANNEL_LABELS: Record<ReleaseChannel, string> = {
  stable: 'مستقر (Stable)',
  beta: 'تجريبي (Beta)',
  canary: 'معاينة مبكرة (Canary)',
};
