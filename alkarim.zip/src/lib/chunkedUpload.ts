export const MAX_UPLOAD_SIZE_BYTES = 250 * 1024 * 1024;
export const CHUNK_SIZE_BYTES = 2 * 1024 * 1024;

export interface UploadProgressState {
  loaded: number;
  total: number;
  pct: number;
  chunkIndex: number;
  totalChunks: number;
  speedBps: number;
  etaSeconds: number | null;
  retryAttempt: number;
  statusText: string;
}

export interface UploadedPackageResult {
  packageId: string;
  fileName: string;
  fileSizeBytes: number;
  sha256: string;
  downloadUrl: string;
}

export class UploadCancelledError extends Error {
  constructor(message = 'تم إلغاء عملية الرفع بناءً على طلبك.') {
    super(message);
    this.name = 'UploadCancelledError';
  }
}

const ALLOWED_EXTENSIONS = [
  '.exe',
  '.msi',
  '.dmg',
  '.pkg',
  '.appimage',
  '.deb',
  '.rpm',
  '.apk',
  '.aab',
  '.ipa',
  '.zip',
  '.tar.gz',
  '.gz',
  '.tgz',
  '.sh',
  '.ps1',
  '.json',
];

function isExtensionSupported(fileName: string): boolean {
  const lower = fileName.toLowerCase();
  return ALLOWED_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new UploadCancelledError());
      return;
    }
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(timer);
      reject(new UploadCancelledError());
    };
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

async function fetchJsonWithRetry<T>(
  url: string,
  buildInit: () => Promise<RequestInit>,
  maxAttempts = 3,
  timeoutMs = 25000,
  signal?: AbortSignal
): Promise<T> {
  let lastError = 'تعذر الاتصال بالخادم';

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    if (signal?.aborted) {
      throw new UploadCancelledError();
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const forwardAbort = () => controller.abort();
    signal?.addEventListener('abort', forwardAbort, { once: true });

    try {
      const init = await buildInit();
      const resp = await fetch(url, { ...init, signal: controller.signal });
      const rawText = await resp.text();
      let parsed: Record<string, unknown> | null = null;
      if (rawText) {
        try {
          parsed = JSON.parse(rawText) as Record<string, unknown>;
        } catch {
          parsed = null;
        }
      }

      if (resp.ok && parsed) {
        return parsed as unknown as T;
      }

      const serverMsg =
        parsed && typeof parsed.error === 'string' ? parsed.error : '';

      // Do not retry deterministic 4xx client errors (except 408 / 429)
      if (resp.status >= 400 && resp.status < 500 && resp.status !== 408 && resp.status !== 429) {
        throw new Error(
          serverMsg ||
            (resp.status === 401
              ? 'انتهت صلاحية جلسة الدخول. يرجى تحديث الصفحة أو إعادة تسجيل الدخول.'
              : resp.status === 403
                ? 'ليس لديك صلاحية تنفيذ عملية الرفع. تأكد من تفعيل البريد الإلكتروني وصلاحية حساب المطور.'
                : `تعذر قبول الطلب من الخادم (HTTP ${resp.status})`)
        );
      }

      lastError =
        serverMsg ||
        `استجابة غير متوقعة من الخادم (HTTP ${resp.status}) أثناء معالجة الطلب.`;
    } catch (err) {
      if (err instanceof UploadCancelledError || signal?.aborted) {
        throw new UploadCancelledError();
      }
      if (err instanceof Error && !(err instanceof DOMException && err.name === 'AbortError')) {
        // Re-throw non-retryable client validation errors immediately
        if (
          err.message.includes('انتهت صلاحية') ||
          err.message.includes('ليس لديك صلاحية') ||
          err.message.includes('غير مدعوم') ||
          err.message.includes('يتجاوز الحد الأقصى')
        ) {
          throw err;
        }
        lastError =
          typeof navigator !== 'undefined' && !navigator.onLine
            ? 'انقطع الاتصال بالإنترنت. يرجى التأكد من استقرار الشبكة والمحاولة مجدداً.'
            : err.message;
      } else {
        lastError = 'انتهت مهلة الاتصال بالخادم بسبب بطء الشبكة.';
      }
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', forwardAbort);
    }

    if (attempt < maxAttempts) {
      await sleep(attempt * 1200, signal);
    }
  }

  throw new Error(lastError);
}

interface ChunkUploadResponse {
  receivedBytes: number;
  nextChunkIndex: number;
  duplicateIgnored?: boolean;
  expectedChunkIndex?: number;
  error?: string;
}

function sendSingleChunkXHR(params: {
  url: string;
  token?: string;
  uploadId: string;
  chunkIndex: number;
  chunkBlob: Blob;
  fileName: string;
  timeoutMs: number;
  signal?: AbortSignal;
  onChunkProgress: (bytesLoadedInChunk: number) => void;
}): Promise<{ status: number; body: ChunkUploadResponse | null }> {
  return new Promise((resolve, reject) => {
    if (params.signal?.aborted) {
      reject(new UploadCancelledError());
      return;
    }

    const xhr = new XMLHttpRequest();
    xhr.open('POST', params.url, true);
    xhr.timeout = params.timeoutMs;
    if (params.token) {
      xhr.setRequestHeader('Authorization', `Bearer ${params.token}`);
    }

    const onAbortSignal = () => {
      xhr.abort();
      reject(new UploadCancelledError());
    };
    params.signal?.addEventListener('abort', onAbortSignal, { once: true });

    const cleanup = () => {
      params.signal?.removeEventListener('abort', onAbortSignal);
    };

    xhr.upload.onprogress = (evt) => {
      if (evt.lengthComputable) {
        params.onChunkProgress(evt.loaded);
      }
    };

    xhr.onload = () => {
      cleanup();
      let parsed: ChunkUploadResponse | null = null;
      if (xhr.responseText) {
        try {
          parsed = JSON.parse(xhr.responseText) as ChunkUploadResponse;
        } catch {
          parsed = null;
        }
      }
      resolve({ status: xhr.status, body: parsed });
    };

    xhr.onerror = () => {
      cleanup();
      const offline = typeof navigator !== 'undefined' && !navigator.onLine;
      reject(
        new Error(
          offline
            ? 'انقطع الاتصال بالإنترنت أثناء نقل البيانات.'
            : 'تعذر الوصول إلى الخادم بسبب ضعف أو تقلب الشبكة.'
        )
      );
    };

    xhr.ontimeout = () => {
      cleanup();
      reject(new Error('انتهت مهلة إرسال الجزء بسبب بطء الاتصال بالإنترنت.'));
    };

    xhr.onabort = () => {
      cleanup();
      reject(new UploadCancelledError());
    };

    const formData = new FormData();
    formData.append('uploadId', params.uploadId);
    formData.append('chunkIndex', String(params.chunkIndex));
    formData.append('chunk', params.chunkBlob, params.fileName);
    xhr.send(formData);
  });
}

export async function uploadFileInChunks(options: {
  file: File;
  getToken: () => Promise<string | undefined>;
  onProgress: (state: UploadProgressState) => void;
  signal?: AbortSignal;
}): Promise<UploadedPackageResult> {
  const { file, getToken, onProgress, signal } = options;

  // Client-side validation with explicit explanatory messages
  if (file.size === 0) {
    throw new Error('حجم الملف المختار يساوي 0 بايت ولا يمكن رفعه. يرجى التحقق من سلامة الملف.');
  }
  if (file.size > MAX_UPLOAD_SIZE_BYTES) {
    const sizeMB = (file.size / (1024 * 1024)).toFixed(1);
    throw new Error(
      `حجم الملف (${sizeMB} MB) يتجاوز الحد الأقصى المسموح به للرفع السحابي وهو 250 MB.`
    );
  }
  if (!isExtensionSupported(file.name)) {
    throw new Error(
      `امتداد الملف "${file.name}" غير مدعوم. الصيغ المدعومة: .exe, .msi, .dmg, .pkg, .AppImage, .deb, .rpm, .apk, .aab, .ipa, .zip, .tar.gz, .sh, .ps1`
    );
  }
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    throw new Error('لا يوجد اتصال بالإنترنت حالياً. يرجى توصيل الشبكة ثم إعادة المحاولة.');
  }

  onProgress({
    loaded: 0,
    total: file.size,
    pct: 0,
    chunkIndex: 0,
    totalChunks: Math.max(1, Math.ceil(file.size / CHUNK_SIZE_BYTES)),
    speedBps: 0,
    etaSeconds: null,
    retryAttempt: 0,
    statusText: 'جاري تهيئة جلسة الرفع السحابية...',
  });

  // Step 1: Initialize session
  const initData = await fetchJsonWithRetry<{ uploadId: string; chunkSizeBytes?: number }>(
    '/api/packages/upload/init',
    async () => {
      const token = await getToken();
      return {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ fileName: file.name, fileSizeBytes: file.size }),
      };
    },
    3,
    25000,
    signal
  );

  const uploadId = initData.uploadId;
  const chunkSize = initData.chunkSizeBytes || CHUNK_SIZE_BYTES;
  const totalChunks = Math.max(1, Math.ceil(file.size / chunkSize));
  const startTime = Date.now();

  try {
    let chunkIndex = 0;

    while (chunkIndex < totalChunks) {
      if (signal?.aborted) {
        throw new UploadCancelledError();
      }

      const startByte = chunkIndex * chunkSize;
      const endByte = Math.min(startByte + chunkSize, file.size);
      const chunkBlob = file.slice(startByte, endByte);

      const maxChunkRetries = 4;
      let chunkCommitted = false;
      let lastChunkError = '';

      for (let attempt = 1; attempt <= maxChunkRetries; attempt++) {
        if (signal?.aborted) {
          throw new UploadCancelledError();
        }

        const token = await getToken();
        try {
          const { status, body } = await sendSingleChunkXHR({
            url: '/api/packages/upload/chunk',
            token,
            uploadId,
            chunkIndex,
            chunkBlob,
            fileName: file.name,
            timeoutMs: 60000,
            signal,
            onChunkProgress: (bytesInChunk) => {
              const totalLoaded = Math.min(file.size, startByte + bytesInChunk);
              const elapsedSec = Math.max(0.25, (Date.now() - startTime) / 1000);
              const speedBps = totalLoaded / elapsedSec;
              const remainingBytes = Math.max(0, file.size - totalLoaded);
              const etaSeconds = speedBps > 0 ? Math.ceil(remainingBytes / speedBps) : null;
              const pct = Math.min(99, Math.round((totalLoaded / file.size) * 100));

              onProgress({
                loaded: totalLoaded,
                total: file.size,
                pct,
                chunkIndex: chunkIndex + 1,
                totalChunks,
                speedBps,
                etaSeconds,
                retryAttempt: attempt > 1 ? attempt - 1 : 0,
                statusText:
                  attempt > 1
                    ? `ضعف في الاتصال — إعادة إرسال الجزء ${chunkIndex + 1} من ${totalChunks} (محاولة ${attempt}/${maxChunkRetries})...`
                    : `جاري رفع الجزء ${chunkIndex + 1} من ${totalChunks}...`,
              });
            },
          });

          if (status >= 200 && status < 300) {
            chunkCommitted = true;
            if (body && typeof body.nextChunkIndex === 'number') {
              chunkIndex = body.nextChunkIndex;
            } else {
              chunkIndex += 1;
            }
            break;
          }

          if (status === 409 && body && typeof body.expectedChunkIndex === 'number') {
            // Re-sync chunk offset with server cleanly
            chunkIndex = body.expectedChunkIndex;
            chunkCommitted = true;
            break;
          }

          const errMsg = body?.error || `فشل الخادم في معالجة الجزء ${chunkIndex + 1} (رمز ${status}).`;
          if (status >= 400 && status < 500 && status !== 408 && status !== 429) {
            throw new Error(errMsg);
          }
          lastChunkError = errMsg;
        } catch (err) {
          if (err instanceof UploadCancelledError || signal?.aborted) {
            throw new UploadCancelledError();
          }
          const msg = err instanceof Error ? err.message : 'فشل نقل الجزء';
          if (
            msg.includes('انتهت صلاحية') ||
            msg.includes('غير موجودة') ||
            msg.includes('تجاوز الحجم') ||
            msg.includes('صيغ')
          ) {
            throw err;
          }
          lastChunkError = msg;
        }

        if (attempt < maxChunkRetries) {
          const backoffMs = Math.min(6000, attempt * 1500);
          onProgress({
            loaded: startByte,
            total: file.size,
            pct: Math.min(99, Math.round((startByte / file.size) * 100)),
            chunkIndex: chunkIndex + 1,
            totalChunks,
            speedBps: 0,
            etaSeconds: null,
            retryAttempt: attempt,
            statusText: `تعذر إرسال الجزء ${chunkIndex + 1} (${lastChunkError}). سيتم إعادة المحاولة تلقائياً...`,
          });
          await sleep(backoffMs, signal);
        }
      }

      if (!chunkCommitted) {
        throw new Error(
          `تعذر رفع الجزء ${chunkIndex + 1} من ${totalChunks} بعد ${maxChunkRetries} محاولات بسبب ضعف أو انقطاع الاتصال: ${lastChunkError}`
        );
      }
    }

    onProgress({
      loaded: file.size,
      total: file.size,
      pct: 99,
      chunkIndex: totalChunks,
      totalChunks,
      speedBps: 0,
      etaSeconds: 1,
      retryAttempt: 0,
      statusText: 'اكتمل نقل الأجزاء — جاري دمج الحزمة وحساب بصمة SHA-256...',
    });

    // Step 3: Complete & compute final SHA-256
    const result = await fetchJsonWithRetry<UploadedPackageResult>(
      '/api/packages/upload/complete',
      async () => {
        const token = await getToken();
        return {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ uploadId }),
        };
      },
      2,
      45000,
      signal
    );

    onProgress({
      loaded: file.size,
      total: file.size,
      pct: 100,
      chunkIndex: totalChunks,
      totalChunks,
      speedBps: 0,
      etaSeconds: 0,
      retryAttempt: 0,
      statusText: 'تم التحقق من سلامة الحزمة بنجاح',
    });

    return result;
  } catch (err) {
    // Best-effort server temp file cleanup when cancelled or fatally aborted
    if (err instanceof UploadCancelledError || signal?.aborted) {
      try {
        const token = await getToken();
        await fetch('/api/packages/upload/abort', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ uploadId }),
        });
      } catch {
        // ignore cleanup failure
      }
    }
    throw err;
  }
}
