export interface DownloadProgressState {
  phase: 'preparing' | 'downloading' | 'saving';
  percent: number;
  receivedBytes: number;
  totalBytes: number;
  currentChunk: number;
  totalChunks: number;
  speedBytesPerSec: number;
  etaSeconds: number | null;
  statusText: string;
}

export class DownloadCancelledError extends Error {
  constructor(message = 'تم إلغاء عملية التحميل.') {
    super(message);
    this.name = 'DownloadCancelledError';
  }
}

const DEFAULT_DOWNLOAD_CHUNK_SIZE = 2 * 1024 * 1024; // 2 MB per Range request (bypasses Cloud Run 32 MB cap)
const MAX_CHUNK_RETRIES = 4;

function triggerBrowserSave(blob: Blob, fileName: string) {
  const blobUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = blobUrl;
  link.download = fileName;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => {
    URL.revokeObjectURL(blobUrl);
  }, 60_000);
}

function triggerDirectUrlDownload(url: string, fileName: string) {
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  link.rel = 'noreferrer';
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function normalizeScriptFileName(fileName: string, osHint?: string): string {
  const isWin =
    osHint?.toLowerCase() === 'windows' || /\.(exe|msi|ps1)$/i.test(fileName);
  const targetExt = isWin ? '.ps1' : '.sh';
  const base = fileName.replace(/\.(exe|msi|dmg|pkg|appimage|deb|rpm|apk|aab|ipa|ps1|sh)$/i, '');
  return `${base || 'installer'}${targetExt}`;
}

function downloadWithXhr(params: {
  url: string;
  start?: number;
  end?: number;
  token?: string;
  onChunkProgress: (loadedBytes: number) => void;
  signal?: AbortSignal;
}): Promise<{ status: number; buffer: ArrayBuffer }> {
  return new Promise((resolve, reject) => {
    if (params.signal?.aborted) {
      reject(new DownloadCancelledError());
      return;
    }

    const xhr = new XMLHttpRequest();
    xhr.open('GET', params.url, true);
    xhr.responseType = 'arraybuffer';
    xhr.timeout = 90_000;
    if (typeof params.start === 'number' && typeof params.end === 'number') {
      xhr.setRequestHeader('Range', `bytes=${params.start}-${params.end}`);
    }
    if (params.token) {
      xhr.setRequestHeader('Authorization', `Bearer ${params.token}`);
    }

    const onAbort = () => {
      xhr.abort();
      reject(new DownloadCancelledError());
    };
    params.signal?.addEventListener('abort', onAbort, { once: true });

    const cleanup = () => {
      params.signal?.removeEventListener('abort', onAbort);
    };

    xhr.onprogress = (ev) => {
      params.onChunkProgress(ev.loaded);
    };

    xhr.onload = () => {
      cleanup();
      if (xhr.status === 206 || xhr.status === 200) {
        resolve({ status: xhr.status, buffer: xhr.response as ArrayBuffer });
        return;
      }
      let serverErr = '';
      try {
        const text = new TextDecoder().decode(new Uint8Array(xhr.response as ArrayBuffer));
        const parsed = JSON.parse(text) as { error?: string };
        if (parsed.error) serverErr = parsed.error;
      } catch {
        // ignore non-JSON error body
      }
      reject(new Error(serverErr || `تعذر تحميل الحزمة من الخادم (HTTP ${xhr.status}).`));
    };

    xhr.onerror = () => {
      cleanup();
      reject(new Error('انقطع الاتصال بالشبكة أثناء تحميل الحزمة.'));
    };

    xhr.ontimeout = () => {
      cleanup();
      reject(new Error('انتهت مهلة انتظار استجابة الخادم أثناء التحميل.'));
    };

    xhr.onabort = () => {
      cleanup();
      reject(new DownloadCancelledError());
    };

    xhr.send();
  });
}

function extractPackageId(downloadUrl: string): string | null {
  try {
    const parsed = new URL(
      downloadUrl,
      typeof window !== 'undefined' ? window.location.origin : 'http://localhost'
    );
    const prefix = '/api/packages/download/';
    if (parsed.pathname.startsWith(prefix)) {
      return decodeURIComponent(parsed.pathname.slice(prefix.length));
    }
  } catch {
    // ignore URL parse issues
  }
  return null;
}

export async function downloadPackage(options: {
  downloadUrl: string;
  fileName: string;
  appId?: string;
  targetOS?: string;
  getToken?: () => Promise<string | undefined>;
  onProgress?: (state: DownloadProgressState) => void;
  signal?: AbortSignal;
}): Promise<void> {
  const { downloadUrl, fileName, appId, targetOS, getToken, onProgress, signal } = options;

  if (signal?.aborted) {
    throw new DownloadCancelledError();
  }

  onProgress?.({
    phase: 'preparing',
    percent: 0,
    receivedBytes: 0,
    totalBytes: 0,
    currentChunk: 0,
    totalChunks: 1,
    speedBytesPerSec: 0,
    etaSeconds: null,
    statusText: 'جاري التحقق من جاهزية الحزمة على الخادم...',
  });

  const packageId = extractPackageId(downloadUrl);

  // If URL is external or non-package endpoint
  if (!packageId) {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'http://localhost';
    const parsed = new URL(downloadUrl, origin);
    const isCrossOrigin = parsed.origin !== origin;

    if (isCrossOrigin) {
      triggerDirectUrlDownload(parsed.toString(), fileName);
      onProgress?.({
        phase: 'saving',
        percent: 100,
        receivedBytes: 1,
        totalBytes: 1,
        currentChunk: 1,
        totalChunks: 1,
        speedBytesPerSec: 0,
        etaSeconds: 0,
        statusText: 'بدأ تنزيل الملف من الرابط الخارجي...',
      });
      return;
    }

    const resp = await fetch(parsed.toString(), { signal });
    if (!resp.ok) {
      throw new Error(`فشل تحميل الملف (HTTP ${resp.status}).`);
    }
    const blob = await resp.blob();
    triggerBrowserSave(blob, fileName);
    onProgress?.({
      phase: 'saving',
      percent: 100,
      receivedBytes: blob.size,
      totalBytes: blob.size,
      currentChunk: 1,
      totalChunks: 1,
      speedBytesPerSec: blob.size,
      etaSeconds: 0,
      statusText: 'اكتمل التحميل وبدأ حفظ الملف على جهازك.',
    });
    return;
  }

  const token = await getToken?.().catch(() => undefined);
  const infoUrl = new URL(
    `/api/packages/info/${encodeURIComponent(packageId)}`,
    typeof window !== 'undefined' ? window.location.origin : 'http://localhost'
  );
  if (appId) {
    infoUrl.searchParams.set('appId', appId);
  }

  const infoResp = await fetch(infoUrl.pathname + infoUrl.search, {
    headers: token ? { Authorization: `Bearer ${token}` } : undefined,
    signal,
  });
  if (!infoResp.ok) {
    let msg = `تعذر الوصول إلى معلومات الحزمة (HTTP ${infoResp.status}).`;
    try {
      const errData = (await infoResp.json()) as { error?: string };
      if (errData.error) msg = errData.error;
    } catch {
      // keep fallback
    }
    throw new Error(msg);
  }

  const info = (await infoResp.json()) as {
    exists: boolean;
    isBinary: boolean;
    fileSizeBytes: number;
    missingLargeBinary?: boolean;
  };

  if (!info.exists) {
    throw new Error(
      info.missingLargeBinary
        ? 'ملف الحزمة غير متوفر حالياً على هذا الخادم (قد يكون تم مسحه بعد إعادة تشغيل الخادم). يرجى إعادة رفع الإصدار من لوحة المطور ثم إعادة المحاولة.'
        : 'لم يتم العثور على ملف الحزمة على الخادم. يرجى إعادة رفع الإصدار والمحاولة مجدداً.'
    );
  }

  // Fallback installer scripts (pkg-* when no binary was attached)
  if (!info.isBinary || info.fileSizeBytes <= 0) {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'http://localhost';
    const parsedScriptUrl = new URL(downloadUrl, origin);
    const osFromQuery = parsedScriptUrl.searchParams.get('os') || targetOS || 'windows';
    const safeScriptName = normalizeScriptFileName(fileName, osFromQuery);
    parsedScriptUrl.searchParams.set('filename', safeScriptName);
    if (!parsedScriptUrl.searchParams.get('os')) {
      parsedScriptUrl.searchParams.set('os', osFromQuery);
    }

    const resp = await fetch(parsedScriptUrl.pathname + parsedScriptUrl.search, { signal });
    if (!resp.ok) {
      throw new Error(`تعذر تحميل ملف التنصيب (HTTP ${resp.status}).`);
    }
    const blob = await resp.blob();
    triggerBrowserSave(blob, safeScriptName);
    onProgress?.({
      phase: 'saving',
      percent: 100,
      receivedBytes: blob.size,
      totalBytes: blob.size,
      currentChunk: 1,
      totalChunks: 1,
      speedBytesPerSec: blob.size,
      etaSeconds: 0,
      statusText: 'اكتمل التحميل وبدأ حفظ أداة التنصيب على جهازك.',
    });
    return;
  }

  const totalBytes = info.fileSizeBytes;
  const chunkSize = DEFAULT_DOWNLOAD_CHUNK_SIZE;
  const baseDownloadUrlObj = new URL(
    `/api/packages/download/${encodeURIComponent(packageId)}`,
    typeof window !== 'undefined' ? window.location.origin : 'http://localhost'
  );
  baseDownloadUrlObj.searchParams.set('filename', fileName);
  if (appId) {
    baseDownloadUrlObj.searchParams.set('appId', appId);
  }
  const baseDownloadUrl = baseDownloadUrlObj.pathname + baseDownloadUrlObj.search;

  const startedAt = Date.now();

  // Small/medium binary <= 2 MB: single clean GET request without Range header
  if (totalBytes <= chunkSize) {
    const single = await downloadWithXhr({
      url: baseDownloadUrl,
      token,
      signal,
      onChunkProgress: (loadedBytes) => {
        const received = Math.min(totalBytes, loadedBytes);
        const elapsedSec = Math.max(0.2, (Date.now() - startedAt) / 1000);
        const speed = received / elapsedSec;
        const eta = speed > 0 ? Math.ceil((totalBytes - received) / speed) : null;
        const percent = Math.min(99, Math.round((received / totalBytes) * 100));
        onProgress?.({
          phase: 'downloading',
          percent,
          receivedBytes: received,
          totalBytes,
          currentChunk: 1,
          totalChunks: 1,
          speedBytesPerSec: speed,
          etaSeconds: eta,
          statusText: 'جاري تحميل الحزمة...',
        });
      },
    });

    onProgress?.({
      phase: 'saving',
      percent: 100,
      receivedBytes: totalBytes,
      totalBytes,
      currentChunk: 1,
      totalChunks: 1,
      speedBytesPerSec: totalBytes / Math.max(0.25, (Date.now() - startedAt) / 1000),
      etaSeconds: 0,
      statusText: 'اكتمل التنزيل — جاري حفظ الملف على جهازك...',
    });

    const finalBlob = new Blob([single.buffer], { type: 'application/octet-stream' });
    triggerBrowserSave(finalBlob, fileName);
    return;
  }

  const totalChunks = Math.max(1, Math.ceil(totalBytes / chunkSize));
  const chunkBuffers: ArrayBuffer[] = [];
  let completedBytes = 0;

  for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
    if (signal?.aborted) {
      throw new DownloadCancelledError();
    }

    const start = chunkIndex * chunkSize;
    const end = Math.min(totalBytes - 1, start + chunkSize - 1);
    const expectedLen = end - start + 1;

    let chunkResult: { status: number; buffer: ArrayBuffer } | null = null;
    let lastErr: unknown = null;

    for (let attempt = 0; attempt <= MAX_CHUNK_RETRIES; attempt++) {
      if (signal?.aborted) {
        throw new DownloadCancelledError();
      }
      try {
        chunkResult = await downloadWithXhr({
          url: baseDownloadUrl,
          start,
          end,
          token,
          signal,
          onChunkProgress: (loadedInChunk) => {
            const totalReceived = Math.min(totalBytes, completedBytes + Math.min(loadedInChunk, expectedLen));
            const elapsedSec = Math.max(0.25, (Date.now() - startedAt) / 1000);
            const speed = totalReceived / elapsedSec;
            const remaining = totalBytes - totalReceived;
            const eta = speed > 0 ? Math.ceil(remaining / speed) : null;
            const percent = Math.min(99, Math.round((totalReceived / totalBytes) * 100));

            onProgress?.({
              phase: 'downloading',
              percent,
              receivedBytes: totalReceived,
              totalBytes,
              currentChunk: chunkIndex + 1,
              totalChunks,
              speedBytesPerSec: speed,
              etaSeconds: eta,
              statusText: `جاري تحميل الجزء ${chunkIndex + 1} من ${totalChunks}...`,
            });
          },
        });
        break;
      } catch (err) {
        if (err instanceof DownloadCancelledError) throw err;
        lastErr = err;
        if (attempt < MAX_CHUNK_RETRIES) {
          onProgress?.({
            phase: 'downloading',
            percent: Math.min(99, Math.round((completedBytes / totalBytes) * 100)),
            receivedBytes: completedBytes,
            totalBytes,
            currentChunk: chunkIndex + 1,
            totalChunks,
            speedBytesPerSec: 0,
            etaSeconds: null,
            statusText: `اضطراب مؤقت في الاتصال — إعادة محاولة تحميل الجزء ${chunkIndex + 1} (${attempt + 1}/${MAX_CHUNK_RETRIES})...`,
          });
          await new Promise((r) => setTimeout(r, 800 * (attempt + 1)));
        }
      }
    }

    if (!chunkResult) {
      throw lastErr instanceof Error ? lastErr : new Error('فشل تحميل الحزمة بعد عدة محاولات.');
    }

    // If an intermediate proxy ignored Range and returned the complete file on chunk 0, save immediately without duplicating
    if (chunkIndex === 0 && chunkResult.status === 200 && chunkResult.buffer.byteLength >= totalBytes) {
      chunkBuffers.push(chunkResult.buffer);
      completedBytes = chunkResult.buffer.byteLength;
      break;
    }

    if (chunkResult.status === 200 && chunkResult.buffer.byteLength > expectedLen) {
      throw new Error('تعذر استكمال التحميل المجزأ بسبب استجابة غير متوافقة من الخادم الوسيط.');
    }

    chunkBuffers.push(chunkResult.buffer);
    completedBytes += chunkResult.buffer.byteLength;
  }

  onProgress?.({
    phase: 'saving',
    percent: 100,
    receivedBytes: totalBytes,
    totalBytes,
    currentChunk: totalChunks,
    totalChunks,
    speedBytesPerSec: totalBytes / Math.max(0.25, (Date.now() - startedAt) / 1000),
    etaSeconds: 0,
    statusText: 'اكتمل التنزيل — جاري حفظ الملف على جهازك...',
  });

  const finalBlob = new Blob(chunkBuffers, { type: 'application/octet-stream' });
  triggerBrowserSave(finalBlob, fileName);
}
