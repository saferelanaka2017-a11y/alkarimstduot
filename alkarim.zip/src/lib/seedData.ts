import { doc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from './firestoreErrors';

export async function seedInitialWorkspaceData(uid: string, ownerName: string): Promise<void> {
  const safeOwnerName = (ownerName || 'مطور AlKarim').trim().slice(0, 80) || 'مطور AlKarim';
  const safeSlugSuffix = uid.slice(0, 6).toLowerCase().replace(/[^a-z0-9]/g, 'a') || 'dev';

  const sampleApps = [
    {
      id: `app_cloudsync_${uid.slice(0, 8)}`,
      slug: `cloudsync-${safeSlugSuffix}`,
      ownerId: uid,
      ownerName: safeOwnerName,
      name: 'كلاود سينك برو (CloudSync Pro)',
      description: 'أداة مزامنة الملفات السحابية الفورية عبر الأجهزة مع التشفير الكامل والتحديث التلقائي الصامت.',
      category: 'productivity',
      iconUrl: '/src/assets/images/app_icon_cloudsync_1795296596170.jpg',
      latestVersion: '3.4.2',
      channel: 'stable',
      autoUpdate: true,
      mandatoryUpdate: false,
      supportedOS: ['windows', 'macos', 'linux', 'android'],
      downloadsCount: 14820,
      activeUsersCount: 6340,
      crashFreeRate: 99.6,
      apiEnabled: true,
      visibility: 'public',
    },
    {
      id: `app_devcli_${uid.slice(0, 8)}`,
      slug: `devcli-${safeSlugSuffix}`,
      ownerId: uid,
      ownerName: safeOwnerName,
      name: 'طرفية المطور (AlKarim CLI)',
      description: 'واجهة سطر أوامر متكاملة لأتمتة النشر، إدارة الحزم، والربط المباشر مع خطوط CI/CD.',
      category: 'developer',
      iconUrl: '/src/assets/images/app_icon_devcli_1795296596094.jpg',
      latestVersion: '2.9.0',
      channel: 'stable',
      autoUpdate: true,
      mandatoryUpdate: true,
      supportedOS: ['windows', 'macos', 'linux', 'cli'],
      downloadsCount: 9415,
      activeUsersCount: 4180,
      crashFreeRate: 99.8,
      apiEnabled: true,
      visibility: 'public',
    },
    {
      id: `app_secshield_${uid.slice(0, 8)}`,
      slug: `secshield-${safeSlugSuffix}`,
      ownerId: uid,
      ownerName: safeOwnerName,
      name: 'درع الحماية المؤسسي (SecShield)',
      description: 'مراقبة نقاط النهاية، فحص التوقيعات الرقمية للحزم، وتنفيذ التحديثات الأمنية الإلزامية فوراً.',
      category: 'security',
      iconUrl: '/src/assets/images/app_icon_secshield_1795296596126.jpg',
      latestVersion: '4.1.5',
      channel: 'beta',
      autoUpdate: true,
      mandatoryUpdate: true,
      supportedOS: ['windows', 'macos', 'linux', 'ios'],
      downloadsCount: 7260,
      activeUsersCount: 3890,
      crashFreeRate: 99.4,
      apiEnabled: true,
      visibility: 'public',
    },
  ];

  // Step 1: Commit parent app documents first so Firestore security rules
  // exists(/apps/$(appId)) and get(/apps/$(appId)) resolve against committed state.
  const appsBatch = writeBatch(db);
  for (const app of sampleApps) {
    appsBatch.set(doc(db, 'apps', app.id), {
      ...app,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }

  try {
    await appsBatch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'apps');
  }

  // Step 2: Commit child releases and initial periodic report referencing committed apps.
  const childrenBatch = writeBatch(db);
  for (const app of sampleApps) {
    const primaryOS = app.supportedOS[0];
    const releaseId = `rel_${app.latestVersion.replace(/\./g, '_')}_${primaryOS}`;
    childrenBatch.set(doc(db, 'apps', app.id, 'releases', releaseId), {
      id: releaseId,
      appId: app.id,
      ownerId: uid,
      version: app.latestVersion,
      channel: app.channel,
      targetOS: primaryOS,
      fileName: `${app.slug}-v${app.latestVersion}-${primaryOS}-setup.exe`,
      fileSizeBytes: 28450900,
      sha256: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
      downloadUrl: `/api/packages/download/pkg-${app.slug}?os=${primaryOS}&version=${app.latestVersion}`,
      releaseNotes: `تحديث ${app.latestVersion}: تحسين سرعة المزامنة السحابية، دعم أنظمة ARM64، وإصلاحات أمنية موثقة.`,
      mandatory: app.mandatoryUpdate,
      visibility: app.visibility,
      downloads: Math.floor(app.downloadsCount * 0.45),
      createdAt: serverTimestamp(),
    });
  }

  const reportId = `rep_weekly_${uid.slice(0, 8)}`;
  childrenBatch.set(doc(db, 'reports', reportId), {
    id: reportId,
    ownerId: uid,
    appId: sampleApps[0].id,
    appName: sampleApps[0].name,
    period: 'weekly',
    totalDownloads: sampleApps[0].downloadsCount,
    activeUsers: sampleApps[0].activeUsersCount,
    autoUpdateRate: 96.4,
    crashFreeRate: 99.6,
    summary: 'أداء مستقر بنسبة 99.6% بدون أعطال مع استجابة تحديث تلقائي خلال أقل من 4 دقائق لدى 96.4% من الأجهزة المتصلة.',
    createdAt: serverTimestamp(),
  });

  try {
    await childrenBatch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'apps/releases');
  }
}
