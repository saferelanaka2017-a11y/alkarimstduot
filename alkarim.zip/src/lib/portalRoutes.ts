export type PortalEntryMode = 'default' | 'developer' | 'client';

export function getPortalEntryModeFromLocation(): PortalEntryMode {
  if (typeof window === 'undefined') return 'default';
  const path = window.location.pathname.toLowerCase();
  if (/^\/(developer|dev)(\/|$)/.test(path)) {
    return 'developer';
  }
  if (/^\/(client|clients|portal|download)(\/|$)/.test(path)) {
    return 'client';
  }

  const params = new URLSearchParams(window.location.search);
  const roleParam = (params.get('role') || params.get('mode') || '').toLowerCase();
  if (roleParam === 'developer' || roleParam === 'dev') return 'developer';
  if (roleParam === 'client' || roleParam === 'user' || params.get('portal') === '1') {
    return 'client';
  }
  return 'default';
}

export function getAppQueryParam(): string | null {
  if (typeof window === 'undefined') return null;
  const val = new URLSearchParams(window.location.search).get('app');
  return val && val.trim() ? val.trim() : null;
}

export function navigatePortalRoute(mode: PortalEntryMode) {
  if (typeof window === 'undefined') return;
  const targetPath = mode === 'developer' ? '/developer' : mode === 'client' ? '/client' : '/';
  if (window.location.pathname !== targetPath || window.location.search) {
    window.history.pushState({}, '', targetPath);
  }
}

export function buildPortalLinks(origin: string, appSlug?: string) {
  const cleanOrigin = origin.replace(/\/+$/, '');
  const developerUrl = `${cleanOrigin}/developer`;
  const clientUrl = `${cleanOrigin}/client`;
  const appClientUrl = appSlug ? `${cleanOrigin}/client?app=${encodeURIComponent(appSlug)}` : null;
  return { developerUrl, clientUrl, appClientUrl };
}
