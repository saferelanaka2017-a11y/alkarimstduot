import { initializeApp } from 'firebase/app';
import {
  Auth,
  getAuth,
  GoogleAuthProvider,
  FacebookAuthProvider,
  GithubAuthProvider,
  TwitterAuthProvider,
} from 'firebase/auth';
import { Firestore, getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { PortalEntryMode } from './lib/portalRoutes';

const devApp = initializeApp(firebaseConfig);
export const devDb = getFirestore(devApp, firebaseConfig.firestoreDatabaseId);
export const devAuth = getAuth(devApp);
devAuth.languageCode = 'ar';

const clientApp = initializeApp(firebaseConfig, 'clientPortal');
export const clientDb = getFirestore(clientApp, firebaseConfig.firestoreDatabaseId);
export const clientAuth = getAuth(clientApp);
clientAuth.languageCode = 'ar';

export function getFirebaseForMode(mode: PortalEntryMode): { auth: Auth; db: Firestore } {
  return mode === 'client'
    ? { auth: clientAuth, db: clientDb }
    : { auth: devAuth, db: devDb };
}

export const db = devDb;
export const auth = devAuth;

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });
export const facebookProvider = new FacebookAuthProvider();
export const githubProvider = new GithubAuthProvider();
export const twitterProvider = new TwitterAuthProvider();

export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
      return false;
    }
    return true;
  }
}

testConnection();
