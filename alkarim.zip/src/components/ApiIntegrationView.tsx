import React, { useState } from 'react';
import {
  Check,
  Code2,
  Copy,
  Key,
  Play,
  Plus,
  Trash2,
} from 'lucide-react';
import { ApiKeyRecord, SoftwareApp } from '../types';

interface ApiIntegrationViewProps {
  apps: SoftwareApp[];
  apiKeys: ApiKeyRecord[];
  onCreateApiKey: (label: string, appId: string, scopes: string[]) => Promise<string>;
  onRevokeOrDeleteKey: (key: ApiKeyRecord, action: 'revoke' | 'delete') => Promise<void>;
}

type SdkLang = 'curl' | 'typescript' | 'python' | 'csharp';

export const ApiIntegrationView: React.FC<ApiIntegrationViewProps> = ({
  apps,
  apiKeys,
  onCreateApiKey,
  onRevokeOrDeleteKey,
}) => {
  const [label, setLabel] = useState('');
  const [targetAppId, setTargetAppId] = useState('all');
  const [creating, setCreating] = useState(false);
  const [newlyCreatedSecret, setNewlyCreatedSecret] = useState<string | null>(null);
  const [copiedSecret, setCopiedSecret] = useState(false);

  // Live API Endpoint Tester
  const [testAppSlug, setTestAppSlug] = useState(apps[0]?.slug || '');
  const [endpointType, setEndpointType] = useState<'manifest' | 'ota-check' | 'install' | 'health'>('ota-check');
  const [testResult, setTestResult] = useState<string>('');
  const [testStatus, setTestStatus] = useState<number | null>(null);
  const [testing, setTesting] = useState(false);

  // SDK Snippet Tabs
  const [sdkLang, setSdkLang] = useState<SdkLang>('typescript');
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  const selectedSlug = testAppSlug || apps[0]?.slug || 'demo-app';
  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://alkarim.app';

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!label.trim()) return;
    setCreating(true);
    try {
      const secret = await onCreateApiKey(label.trim(), targetAppId, [
        'apps:read',
        'releases:publish',
        'ota:trigger',
        'telemetry:write',
      ]);
      setNewlyCreatedSecret(secret);
      setLabel('');
    } finally {
      setCreating(false);
    }
  };

  const runLiveApiTest = async () => {
    setTesting(true);
    setTestResult('');
    try {
      const path =
        endpointType === 'health'
          ? '/api/v1/health'
          : endpointType === 'manifest'
            ? `/api/v1/apps/${selectedSlug}/manifest`
            : endpointType === 'install'
              ? `/api/v1/install/${selectedSlug}?os=linux`
              : `/api/v1/apps/${selectedSlug}/ota-check?currentVersion=1.0.0&os=windows`;

      const resp = await fetch(path);
      setTestStatus(resp.status);
      const text = await resp.text();
      try {
        setTestResult(JSON.stringify(JSON.parse(text), null, 2));
      } catch {
        setTestResult(text);
      }
    } catch (err) {
      setTestStatus(0);
      setTestResult(err instanceof Error ? err.message : 'Network error');
    } finally {
      setTesting(false);
    }
  };

  const snippets: Record<SdkLang, string> = {
    curl: `curl -s "${origin}/api/v1/apps/${selectedSlug}/ota-check?currentVersion=1.0.0&os=windows" \\
  -H "Authorization: Bearer YOUR_ALKARIM_API_KEY"`,
    typescript: `const res = await fetch(
  "${origin}/api/v1/apps/${selectedSlug}/ota-check?currentVersion=1.0.0&os=windows",
  { headers: { Authorization: "Bearer YOUR_ALKARIM_API_KEY" } }
);
const update = await res.json();
if (update.updateAvailable) {
  console.log("New version ready:", update.latestVersion, update.downloadUrl);
}`,
    python: `import requests

resp = requests.get(
    "${origin}/api/v1/apps/${selectedSlug}/ota-check",
    params={"currentVersion": "1.0.0", "os": "linux"},
    headers={"Authorization": "Bearer YOUR_ALKARIM_API_KEY"},
)
print(resp.json())`,
    csharp: `using var client = new HttpClient();
client.DefaultRequestHeaders.Add("Authorization", "Bearer YOUR_ALKARIM_API_KEY");
var json = await client.GetStringAsync(
    "${origin}/api/v1/apps/${selectedSlug}/manifest"
);
Console.WriteLine(json);`,
  };

  return (
    <div className="space-y-6">
      {/* API Keys Management */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            مفاتيح التكامل البرمجي (API Keys)
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            تُحفظ المفاتيح في قاعدة البيانات بصيغة مشفرة (SHA-256) لربط خطوط النشر التلقائي CI/CD ودمج التحديثات داخل برامجك.
          </p>
        </div>

        <form onSubmit={handleCreate} className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="اسم المفتاح (مثال: GitHub Actions Release)"
            className="flex-1 px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
            required
          />
          <select
            value={targetAppId}
            onChange={(e) => setTargetAppId(e.target.value)}
            className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200"
          >
            <option value="all">جميع التطبيقات</option>
            {apps.map((app) => (
              <option key={app.id} value={app.id}>{app.name}</option>
            ))}
          </select>
          <button
            type="submit"
            disabled={creating}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-medium whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            توليد مفتاح جديد
          </button>
        </form>

        {newlyCreatedSecret && (
          <div className="p-4 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 space-y-2">
            <div className="flex items-center justify-between text-xs font-medium text-emerald-900 dark:text-emerald-200">
              <span>انسخ المفتاح الآن — لن يتم عرضه كاملاً مرة أخرى:</span>
              <button
                type="button"
                onClick={async () => {
                  await navigator.clipboard.writeText(newlyCreatedSecret);
                  setCopiedSecret(true);
                  setTimeout(() => setCopiedSecret(false), 1800);
                }}
                className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-300 hover:underline"
              >
                {copiedSecret ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedSecret ? 'تم النسخ' : 'نسخ المفتاح'}
              </button>
            </div>
            <pre className="p-2.5 rounded bg-white dark:bg-slate-950 border border-emerald-200 dark:border-emerald-900 text-xs font-mono text-slate-900 dark:text-slate-100 overflow-x-auto">
              {newlyCreatedSecret}
            </pre>
          </div>
        )}

        <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
          {apiKeys.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">
              لا توجد مفاتيح API منشأة حتى الآن.
            </div>
          ) : (
            apiKeys.map((k) => (
              <div key={k.id} className="px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-3">
                  <Key className="w-4 h-4 text-slate-400 shrink-0" />
                  <div>
                    <div className="font-semibold text-slate-900 dark:text-white">{k.label}</div>
                    <div className="text-slate-500 dark:text-slate-400 font-mono mt-0.5">
                      {k.prefix}•••••••• · {k.status === 'active' ? 'نشط' : 'ملغى'}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {k.status === 'active' && (
                    <button
                      type="button"
                      onClick={() => onRevokeOrDeleteKey(k, 'revoke')}
                      className="px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      تعطيل
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => onRevokeOrDeleteKey(k, 'delete')}
                    className="p-1.5 text-red-600 hover:text-red-700 dark:text-red-400"
                    aria-label="حذف المفتاح"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      {/* Live Interactive API Tester + SDK Snippets */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              اختبار واجهات البرمجة الحي (REST API)
            </h3>
            {testStatus !== null && (
              <span className="font-mono text-xs text-emerald-700 dark:text-emerald-400">
                HTTP {testStatus}
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <select
              value={selectedSlug}
              onChange={(e) => setTestAppSlug(e.target.value)}
              className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200"
            >
              {apps.map((app) => (
                <option key={app.id} value={app.slug}>{app.name}</option>
              ))}
            </select>

            <select
              value={endpointType}
              onChange={(e) => setEndpointType(e.target.value as 'manifest' | 'ota-check' | 'install' | 'health')}
              className="px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200"
            >
              <option value="ota-check">GET /api/v1/apps/:slug/ota-check</option>
              <option value="manifest">GET /api/v1/apps/:slug/manifest</option>
              <option value="install">GET /api/v1/install/:slug</option>
              <option value="health">GET /api/v1/health</option>
            </select>
          </div>

          <button
            type="button"
            disabled={testing}
            onClick={runLiveApiTest}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-medium"
          >
            <Play className="w-3.5 h-3.5" />
            {testing ? 'جاري التنفيذ...' : 'تشغيل الطلب الحي'}
          </button>

          <pre className="p-4 rounded-lg bg-slate-950 text-emerald-300 text-xs font-mono h-60 overflow-auto border border-slate-800">
            <code>{testResult || '// اضغط "تشغيل الطلب الحي" لمعاينة استجابة JSON الفعلية من الخادم'}</code>
          </pre>
        </div>

        {/* Multi-Language SDK Snippets */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Code2 className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                أكواد التكامل المباشر (SDK & CLI)
              </h3>
            </div>
            <button
              type="button"
              onClick={async () => {
                await navigator.clipboard.writeText(snippets[sdkLang]);
                setCopiedSnippet(true);
                setTimeout(() => setCopiedSnippet(false), 1800);
              }}
              className="inline-flex items-center gap-1 text-xs text-emerald-700 dark:text-emerald-400 hover:underline"
            >
              {copiedSnippet ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedSnippet ? 'تم النسخ' : 'نسخ الكود'}
            </button>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg w-fit">
            {(['typescript', 'curl', 'python', 'csharp'] as SdkLang[]).map((lang) => (
              <button
                key={lang}
                type="button"
                onClick={() => setSdkLang(lang)}
                className={`px-3 py-1.5 rounded-md text-xs font-mono transition-colors ${
                  sdkLang === lang
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>

          <pre className="p-4 rounded-lg bg-slate-950 text-slate-100 text-xs font-mono h-60 overflow-auto border border-slate-800">
            <code>{snippets[sdkLang]}</code>
          </pre>
        </div>
      </section>
    </div>
  );
};
