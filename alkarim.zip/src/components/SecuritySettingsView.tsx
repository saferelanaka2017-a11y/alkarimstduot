import React from 'react';
import { User } from 'firebase/auth';
import { Bell, CheckCircle2, Mail, ShieldCheck } from 'lucide-react';

interface SecuritySettingsViewProps {
  user: User;
  notificationPermission: NotificationPermission | 'unsupported';
  onRequestNotifications: () => Promise<void>;
}

export const SecuritySettingsView: React.FC<SecuritySettingsViewProps> = ({
  user,
  notificationPermission,
  onRequestNotifications,
}) => {
  const providerLabel =
    user.providerData
      .map((p) => (p.providerId === 'password' ? 'البريد الإلكتروني وكلمة المرور' : p.providerId))
      .join(', ') || 'البريد الإلكتروني وكلمة المرور';

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Account & Sign-in Summary */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              بيانات الحساب وتسجيل الدخول
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              حسابك يعمل بالدخول المباشر عبر البريد الإلكتروني أو المزود المرتبط دون الحاجة لرموز تحقق إضافية.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800">
            <div className="text-slate-500 mb-1 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5" />
              <span>البريد الإلكتروني</span>
            </div>
            <div className="font-mono text-slate-900 dark:text-white truncate">{user.email}</div>
          </div>
          <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800">
            <div className="text-slate-500 mb-1">حالة الحساب</div>
            <div className="font-medium text-emerald-700 dark:text-emerald-400">
              مفعل ونشط (دخول مباشر)
            </div>
          </div>
          <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800">
            <div className="text-slate-500 mb-1">طريقة الدخول</div>
            <div className="text-slate-900 dark:text-white font-medium">{providerLabel}</div>
          </div>
        </div>
      </section>

      {/* Real-Time Device Update Notifications Permission */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              إشعارات التحديث الفورية على الجهاز
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              تنبيه المستخدمين فوراً عبر المتصفح والنظام عند صدور تحديث جديد لأي تطبيق مثبّت.
            </p>
          </div>
        </div>

        {notificationPermission === 'granted' ? (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400 whitespace-nowrap">
            <CheckCircle2 className="w-4 h-4" />
            مفعّلة على هذا الجهاز
          </span>
        ) : notificationPermission === 'unsupported' ? (
          <span className="text-xs text-slate-500">إشعارات النظام غير مدعومة في هذا المتصفح</span>
        ) : (
          <button
            type="button"
            onClick={onRequestNotifications}
            className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200 whitespace-nowrap shrink-0"
          >
            تفعيل إشعارات المتصفح الفورية
          </button>
        )}
      </section>
    </div>
  );
};
