import React, { useState } from 'react';
import { Check, Code2, Copy, Download, ExternalLink, Link2, X } from 'lucide-react';
import { buildPortalLinks } from '../lib/portalRoutes';
import { SoftwareApp } from '../types';

interface PortalLinksModalProps {
  open: boolean;
  onClose: () => void;
  selectedApp?: SoftwareApp | null;
  onOpenInCurrentTab?: (mode: 'developer' | 'client') => void;
}

export const PortalLinksModal: React.FC<PortalLinksModalProps> = ({
  open,
  onClose,
  selectedApp,
  onOpenInCurrentTab,
}) => {
  const [copiedKey, setCopiedKey] = useState<'developer' | 'client' | 'app' | null>(null);

  if (!open) return null;

  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const { developerUrl, clientUrl, appClientUrl } = buildPortalLinks(
    origin,
    selectedApp?.visibility === 'public' ? selectedApp.slug : undefined
  );

  const handleCopy = async (key: 'developer' | 'client' | 'app', url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2000);
    } catch {
      // ignore clipboard errors
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4"
      dir="rtl"
    >
      <div className="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Link2 className="w-4 h-4 text-emerald-600" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              روابط المنصة المخصصة (المطور والعملاء)
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 divide-y divide-slate-100 dark:divide-slate-800 space-y-5">
          {/* Developer Link */}
          <div className="space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
                  <Code2 className="w-4 h-4 text-emerald-600" />
                  <span>1. رابط المطور (لوحة التحكم والنشر)</span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  مخصص لك وللمطورين فقط: يفتح صفحة دخول المطور ولوحة رفع البرامج والإحصائيات ومفاتيح API.
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <code
                dir="ltr"
                className="flex-1 px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-mono text-slate-800 dark:text-slate-200 truncate text-left"
              >
                {developerUrl}
              </code>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => handleCopy('developer', developerUrl)}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium transition-colors whitespace-nowrap"
                >
                  {copiedKey === 'developer' ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ الرابط</span>
                    </>
                  )}
                </button>
                <a
                  href={developerUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center gap-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>فتح</span>
                </a>
                {onOpenInCurrentTab && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenInCurrentTab('developer');
                      onClose();
                    }}
                    className="inline-flex items-center justify-center px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
                  >
                    عرض هنا
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Client Link */}
          <div className="pt-5 space-y-3">
            <div>
              <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
                <Download className="w-4 h-4 text-emerald-600" />
                <span>2. رابط العملاء (بوابة التحميل والتحديث المباشر)</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                شاركه مع عملائك: يفتح صفحة تسجيل دخول مستقلة للعميل ثم بوابة التحميل دون استخدام حساب المطور أو ظهور أي أدوات خاصة به.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <code
                dir="ltr"
                className="flex-1 px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-mono text-slate-800 dark:text-slate-200 truncate text-left"
              >
                {clientUrl}
              </code>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => handleCopy('client', clientUrl)}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-100 text-xs font-medium transition-colors whitespace-nowrap"
                >
                  {copiedKey === 'client' ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ الرابط</span>
                    </>
                  )}
                </button>
                <a
                  href={clientUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center gap-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>فتح</span>
                </a>
                {onOpenInCurrentTab && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenInCurrentTab('client');
                      onClose();
                    }}
                    className="inline-flex items-center justify-center px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 text-xs font-medium whitespace-nowrap"
                  >
                    عرض هنا
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Direct App Link for Clients if a public app is selected */}
          {appClientUrl && selectedApp && (
            <div className="pt-5 space-y-2.5">
              <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                رابط مباشر للعملاء لبرنامج «{selectedApp.name}»:
              </div>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <code
                  dir="ltr"
                  className="flex-1 px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-mono text-slate-700 dark:text-slate-300 truncate text-left"
                >
                  {appClientUrl}
                </code>
                <button
                  type="button"
                  onClick={() => handleCopy('app', appClientUrl)}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap shrink-0"
                >
                  {copiedKey === 'app' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ رابط البرنامج</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
