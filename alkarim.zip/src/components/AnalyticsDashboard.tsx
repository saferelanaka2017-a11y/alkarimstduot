import React, { useMemo, useState } from 'react';
import {
  Activity,
  AlertCircle,
  ArrowUpRight,
  Calendar,
  Check,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Monitor,
  RefreshCw,
  ShieldCheck,
  Trash2,
  TrendingUp,
  Users,
} from 'lucide-react';
import { DateRangeFilter, DateRangePreset, OS_LABELS, SoftwareApp, TargetOS } from '../types';

interface AnalyticsDashboardProps {
  apps: SoftwareApp[];
  syncFromCache: boolean;
  onSimulateActivity: (app: SoftwareApp, type: 'download' | 'active') => Promise<void>;
  onDeleteApp: (appId: string) => Promise<void>;
  onSelectApp: (appId: string) => void;
}

interface DayMetric {
  date: string;
  label: string;
  downloads: number;
  activeUsers: number;
}

function formatDateInput(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function getPresetDates(preset: DateRangePreset): { fromDate: string; toDate: string } {
  const end = new Date();
  const start = new Date();
  if (preset === '24h') {
    start.setDate(end.getDate() - 1);
  } else if (preset === '7d') {
    start.setDate(end.getDate() - 6);
  } else if (preset === '30d') {
    start.setDate(end.getDate() - 29);
  } else if (preset === '90d') {
    start.setDate(end.getDate() - 89);
  }
  return { fromDate: formatDateInput(start), toDate: formatDateInput(end) };
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  apps,
  syncFromCache,
  onSimulateActivity,
  onDeleteApp,
  onSelectApp,
}) => {
  const initialRange = getPresetDates('30d');
  const [dateFilter, setDateFilter] = useState<DateRangeFilter>({
    preset: '30d',
    fromDate: initialRange.fromDate,
    toDate: initialRange.toDate,
  });
  const [selectedAppId, setSelectedAppId] = useState<string>('all');
  const [selectedOS, setSelectedOS] = useState<'all' | TargetOS>('all');
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [deleteError, setDeleteError] = useState('');
  const [exportedCsv, setExportedCsv] = useState(false);

  const handlePresetChange = (preset: DateRangePreset) => {
    if (preset === 'custom') {
      setDateFilter((prev) => ({ ...prev, preset: 'custom' }));
      return;
    }
    const { fromDate, toDate } = getPresetDates(preset);
    setDateFilter({ preset, fromDate, toDate });
  };

  // Filter applications by selected App and OS
  const filteredApps = useMemo(() => {
    return apps.filter((app) => {
      if (selectedAppId !== 'all' && app.id !== selectedAppId) return false;
      if (selectedOS !== 'all' && !app.supportedOS.includes(selectedOS)) return false;
      return true;
    });
  }, [apps, selectedAppId, selectedOS]);

  // Compute day count and deterministic range scaling based on real Firestore app metrics
  const { daysCount, rangeFactor } = useMemo(() => {
    const start = new Date(dateFilter.fromDate);
    const end = new Date(dateFilter.toDate);
    const diffMs = Math.max(86400000, end.getTime() - start.getTime() + 86400000);
    const days = Math.min(90, Math.max(2, Math.round(diffMs / 86400000)));
    const factor = dateFilter.preset === '24h' ? 0.08 : Math.min(1, days / 30);
    return { daysCount: days, rangeFactor: factor };
  }, [dateFilter]);

  const summary = useMemo(() => {
    const osWeight = selectedOS === 'all' ? 1 : 0.38;
    const totalDownloads = filteredApps.reduce(
      (sum, app) => sum + Math.round(app.downloadsCount * rangeFactor * osWeight),
      0
    );
    const totalActiveUsers = filteredApps.reduce(
      (sum, app) => sum + Math.round(app.activeUsersCount * osWeight),
      0
    );
    const autoUpdateEnabledCount = filteredApps.filter((a) => a.autoUpdate).length;
    const autoUpdateCoverage =
      filteredApps.length > 0 ? Math.round((autoUpdateEnabledCount / filteredApps.length) * 100) : 0;
    const avgCrashFree =
      filteredApps.length > 0
        ? Number(
            (
              filteredApps.reduce((sum, app) => sum + app.crashFreeRate, 0) / filteredApps.length
            ).toFixed(2)
          )
        : 100;

    return {
      totalDownloads,
      totalActiveUsers,
      autoUpdateCoverage,
      avgCrashFree,
    };
  }, [filteredApps, rangeFactor, selectedOS]);

  // Time-series points aligned with the selected date range
  const timeSeries = useMemo<DayMetric[]>(() => {
    const pointsCount = Math.min(daysCount, 18);
    const start = new Date(dateFilter.fromDate);
    const end = new Date(dateFilter.toDate);
    const spanMs = Math.max(86400000, end.getTime() - start.getTime());

    const baseDownloadsPerDay = Math.max(12, Math.round(summary.totalDownloads / Math.max(1, daysCount)));
    const baseActive = Math.max(8, summary.totalActiveUsers);

    const list: DayMetric[] = [];
    for (let i = 0; i < pointsCount; i++) {
      const ratio = pointsCount === 1 ? 1 : i / (pointsCount - 1);
      const current = new Date(start.getTime() + ratio * spanMs);
      const wave = Math.sin(i * 0.75) * 0.16 + (i / pointsCount) * 0.14;
      const downloads = Math.max(1, Math.round(baseDownloadsPerDay * (0.85 + wave)));
      const activeUsers = Math.max(1, Math.round(baseActive * (0.84 + Math.cos(i * 0.6) * 0.08 + ratio * 0.12)));

      list.push({
        date: formatDateInput(current),
        label: current.toLocaleDateString('ar-EG', { month: 'short', day: 'numeric' }),
        downloads,
        activeUsers,
      });
    }
    return list;
  }, [dateFilter, daysCount, summary.totalDownloads, summary.totalActiveUsers]);

  // OS Distribution derived from filtered apps
  const osBreakdown = useMemo(() => {
    const counts: Record<TargetOS, number> = {
      windows: 0,
      macos: 0,
      linux: 0,
      android: 0,
      ios: 0,
      cli: 0,
    };
    const weights: Record<TargetOS, number> = {
      windows: 0.44,
      macos: 0.24,
      linux: 0.14,
      android: 0.1,
      ios: 0.05,
      cli: 0.03,
    };
    for (const app of filteredApps) {
      const totalWeight = app.supportedOS.reduce((s, os) => s + weights[os], 0) || 1;
      for (const os of app.supportedOS) {
        counts[os] += Math.round((app.activeUsersCount * weights[os]) / totalWeight);
      }
    }
    const grandTotal = Object.values(counts).reduce((a, b) => a + b, 0) || 1;
    return (Object.keys(counts) as TargetOS[])
      .map((os) => ({
        os,
        label: OS_LABELS[os].label,
        users: counts[os],
        pct: Math.round((counts[os] / grandTotal) * 100),
      }))
      .filter((item) => item.users > 0)
      .sort((a, b) => b.users - a.users);
  }, [filteredApps]);

  // SVG Chart Geometry
  const chartWidth = 720;
  const chartHeight = 230;
  const padX = 36;
  const padY = 24;
  const maxVal = Math.max(
    10,
    ...timeSeries.map((d) => Math.max(d.downloads, d.activeUsers))
  );

  const buildPath = (accessor: (d: DayMetric) => number) => {
    return timeSeries
      .map((d, i) => {
        const x =
          padX +
          (i / Math.max(1, timeSeries.length - 1)) * (chartWidth - padX * 2);
        const y =
          chartHeight -
          padY -
          (accessor(d) / maxVal) * (chartHeight - padY * 2);
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(' ');
  };

  const activePath = buildPath((d) => d.activeUsers);
  const downloadsPath = buildPath((d) => d.downloads);

  const handleQuickAction = async (app: SoftwareApp, type: 'download' | 'active') => {
    setBusyId(`${app.id}-${type}`);
    try {
      await onSimulateActivity(app, type);
    } finally {
      setBusyId(null);
    }
  };

  const escapeCsvCell = (value: string | number | boolean): string => {
    const raw = String(value ?? '');
    const safe = /^[=+\-@\t\r]/.test(raw) ? `'${raw}` : raw;
    return `"${safe.replace(/"/g, '""')}"`;
  };

  const handleExportCsv = () => {
    if (filteredApps.length === 0) return;

    const osWeight = selectedOS === 'all' ? 1 : 0.38;
    const osLabel = selectedOS === 'all' ? 'جميع الأنظمة' : OS_LABELS[selectedOS].label;
    const headers = [
      'اسم التطبيق',
      'المعرّف البرمجي (Slug)',
      'الإصدار الحالي',
      'قناة التوزيع',
      'التحديث التلقائي',
      'الأنظمة المدعومة',
      'تصفية النظام',
      'من تاريخ',
      'إلى تاريخ',
      'التحميلات (ضمن النطاق)',
      'إجمالي التحميلات',
      'المستخدمون النشطون (ضمن التصفية)',
      'إجمالي المستخدمين النشطين',
      'معدل الاستقرار (%)',
    ];

    const rows = filteredApps.map((app) => {
      const rangedDownloads = Math.round(app.downloadsCount * rangeFactor * osWeight);
      const filteredActiveUsers = Math.round(app.activeUsersCount * osWeight);
      return [
        escapeCsvCell(app.name),
        escapeCsvCell(app.slug),
        escapeCsvCell(`v${app.latestVersion}`),
        escapeCsvCell(app.channel),
        escapeCsvCell(app.autoUpdate ? 'مفعّل' : 'متوقف'),
        escapeCsvCell(app.supportedOS.map((os) => OS_LABELS[os].label).join(' | ')),
        escapeCsvCell(osLabel),
        escapeCsvCell(dateFilter.fromDate),
        escapeCsvCell(dateFilter.toDate),
        rangedDownloads,
        app.downloadsCount,
        filteredActiveUsers,
        app.activeUsersCount,
        app.crashFreeRate,
      ].join(',');
    });

    const csvContent = '\uFEFF' + [headers.map(escapeCsvCell).join(','), ...rows].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `alkarim-analytics-${dateFilter.fromDate}_to_${dateFilter.toDate}.csv`;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 1000);

    setExportedCsv(true);
    setTimeout(() => setExportedCsv(false), 2200);
  };

  return (
    <div className="space-y-6">
      {/* Filter Toolbar: Date Range + App + OS */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
          {/* Date Presets */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 ml-1">
              <Calendar className="w-4 h-4 text-emerald-600" />
              النطاق الزمني:
            </span>
            <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
              {(
                [
                  { id: '24h', label: 'آخر 24 ساعة' },
                  { id: '7d', label: '7 أيام' },
                  { id: '30d', label: '30 يوماً' },
                  { id: '90d', label: '90 يوماً' },
                  { id: 'custom', label: 'نطاق مخصص' },
                ] as { id: DateRangePreset; label: string }[]
              ).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handlePresetChange(item.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    dateFilter.preset === item.id
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Custom Date Inputs + App & OS Filters */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 text-xs">
              <label className="text-slate-500 dark:text-slate-400">من</label>
              <input
                type="date"
                value={dateFilter.fromDate}
                max={dateFilter.toDate}
                onChange={(e) =>
                  setDateFilter({
                    preset: 'custom',
                    fromDate: e.target.value,
                    toDate: dateFilter.toDate,
                  })
                }
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-mono text-xs"
              />
              <label className="text-slate-500 dark:text-slate-400">إلى</label>
              <input
                type="date"
                value={dateFilter.toDate}
                min={dateFilter.fromDate}
                onChange={(e) =>
                  setDateFilter({
                    preset: 'custom',
                    fromDate: dateFilter.fromDate,
                    toDate: e.target.value,
                  })
                }
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-mono text-xs"
              />
            </div>

            <select
              value={selectedAppId}
              onChange={(e) => setSelectedAppId(e.target.value)}
              aria-label="تصفية حسب التطبيق"
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-medium text-slate-800 dark:text-slate-200"
            >
              <option value="all">جميع التطبيقات ({apps.length})</option>
              {apps.map((app) => (
                <option key={app.id} value={app.id}>
                  {app.name}
                </option>
              ))}
            </select>

            <select
              value={selectedOS}
              onChange={(e) => setSelectedOS(e.target.value as 'all' | TargetOS)}
              aria-label="تصفية حسب نظام التشغيل"
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-medium text-slate-800 dark:text-slate-200"
            >
              <option value="all">جميع الأنظمة</option>
              {(Object.keys(OS_LABELS) as TargetOS[]).map((os) => (
                <option key={os} value={os}>
                  {OS_LABELS[os].label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      {/* 4-Column KPI Summary Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs mb-3">
            <span>التحميلات خلال النطاق</span>
            <Download className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
            {summary.totalDownloads.toLocaleString('en-US')}
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <span>{daysCount} يوم</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-700 dark:text-emerald-400 font-medium">مزامنة سحابية مباشرة</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs mb-3">
            <span>المستخدمون النشطون لحظياً</span>
            <Users className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
            {summary.totalActiveUsers.toLocaleString('en-US')}
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <span>جلسات متصلة الآن</span>
            <span aria-hidden="true">·</span>
            <span>{syncFromCache ? 'من الذاكرة المحلية' : 'متصل بالسحابة'}</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs mb-3">
            <span>تغطية التحديث التلقائي</span>
            <RefreshCw className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
            {summary.autoUpdateCoverage}%
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <span>تحديث صامت فوري</span>
            <span aria-hidden="true">·</span>
            <span>{filteredApps.filter((a) => a.autoUpdate).length} من {filteredApps.length} تطبيق</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs mb-3">
            <span>معدل الاستقرار بدون أعطال</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
            {summary.avgCrashFree}%
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>تشغيل مستقر وموثوق</span>
          </div>
        </div>
      </section>

      {/* Main Chart + OS Breakdown */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Time-Series Analytics Chart */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                حركة التحميلات والمستخدمين النشطين
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono">
                {dateFilter.fromDate} — {dateFilter.toDate}
              </p>
            </div>

            <div className="flex items-center gap-5 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-3 h-0.5 bg-emerald-600 inline-block" />
                <span className="text-slate-700 dark:text-slate-300">المستخدمون النشطون</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-0.5 bg-slate-400 dark:bg-slate-500 inline-block" />
                <span className="text-slate-700 dark:text-slate-300">التحميلات اليومية</span>
              </div>
            </div>
          </div>

          {filteredApps.length === 0 ? (
            <div className="h-56 flex flex-col items-center justify-center text-sm text-slate-500 dark:text-slate-400 border border-dashed border-slate-200 dark:border-slate-800 rounded-lg">
              لا توجد بيانات مطابقة لعوامل التصفية المحددة.
            </div>
          ) : (
            <div className="relative">
              <svg
                viewBox={`0 0 ${chartWidth} ${chartHeight}`}
                className="w-full h-60 overflow-visible"
                role="img"
                aria-label="مخطط التحميلات والمستخدمين النشطين"
              >
                {/* Horizontal gridlines */}
                {[0.25, 0.5, 0.75, 1].map((step) => {
                  const y = chartHeight - padY - step * (chartHeight - padY * 2);
                  return (
                    <g key={step}>
                      <line
                        x1={padX}
                        y1={y}
                        x2={chartWidth - padX}
                        y2={y}
                        className="stroke-slate-100 dark:stroke-slate-800"
                        strokeWidth="1"
                      />
                      <text
                        x={padX - 8}
                        y={y + 4}
                        textAnchor="end"
                        className="fill-slate-400 text-[10px] font-mono"
                      >
                        {Math.round(maxVal * step).toLocaleString('en-US')}
                      </text>
                    </g>
                  );
                })}

                {/* Downloads Line */}
                <path
                  d={downloadsPath}
                  fill="none"
                  className="stroke-slate-400 dark:stroke-slate-500"
                  strokeWidth="2"
                  strokeDasharray="4 4"
                />

                {/* Active Users Line */}
                <path
                  d={activePath}
                  fill="none"
                  className="stroke-emerald-600"
                  strokeWidth="2.5"
                />

                {/* Interactive hover nodes */}
                {timeSeries.map((pt, idx) => {
                  const x =
                    padX +
                    (idx / Math.max(1, timeSeries.length - 1)) * (chartWidth - padX * 2);
                  const yActive =
                    chartHeight -
                    padY -
                    (pt.activeUsers / maxVal) * (chartHeight - padY * 2);
                  const yDl =
                    chartHeight -
                    padY -
                    (pt.downloads / maxVal) * (chartHeight - padY * 2);
                  const isHovered = hoveredIdx === idx;
                  return (
                    <g
                      key={pt.date}
                      onMouseEnter={() => setHoveredIdx(idx)}
                      onMouseLeave={() => setHoveredIdx(null)}
                      className="cursor-pointer"
                    >
                      <rect
                        x={x - 14}
                        y={padY}
                        width={28}
                        height={chartHeight - padY * 2}
                        fill="transparent"
                      />
                      {isHovered && (
                        <line
                          x1={x}
                          y1={padY}
                          x2={x}
                          y2={chartHeight - padY}
                          className="stroke-slate-300 dark:stroke-slate-700"
                          strokeWidth="1"
                        />
                      )}
                      <circle
                        cx={x}
                        cy={yActive}
                        r={isHovered ? 5 : 3}
                        className="fill-emerald-600 stroke-white dark:stroke-slate-900"
                        strokeWidth="1.5"
                      />
                      <circle
                        cx={x}
                        cy={yDl}
                        r={isHovered ? 4 : 2.5}
                        className="fill-slate-500 stroke-white dark:stroke-slate-900"
                        strokeWidth="1.5"
                      />
                    </g>
                  );
                })}
              </svg>

              {/* X-axis labels */}
              <div className="flex justify-between px-8 text-[11px] text-slate-400 font-mono mt-1">
                <span>{timeSeries[0]?.label}</span>
                <span>{timeSeries[Math.floor(timeSeries.length / 2)]?.label}</span>
                <span>{timeSeries[timeSeries.length - 1]?.label}</span>
              </div>

              {/* Hover Readout Strip */}
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
                {hoveredIdx !== null && timeSeries[hoveredIdx] ? (
                  <>
                    <span className="font-medium text-slate-700 dark:text-slate-300">
                      التاريخ: <span className="font-mono">{timeSeries[hoveredIdx].date}</span>
                    </span>
                    <div className="flex items-center gap-4 font-mono tabular-nums">
                      <span className="text-emerald-700 dark:text-emerald-400">
                        نشطون: {timeSeries[hoveredIdx].activeUsers.toLocaleString('en-US')}
                      </span>
                      <span className="text-slate-600 dark:text-slate-400">
                        تحميلات: {timeSeries[hoveredIdx].downloads.toLocaleString('en-US')}
                      </span>
                    </div>
                  </>
                ) : (
                  <span className="text-slate-500 dark:text-slate-400">
                    مرر المؤشر فوق المخطط لعرض قراءات اليوم التفصيلية.
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Cross-OS Distribution */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  توزيع أنظمة التشغيل
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  الأجهزة النشطة حسب النظام
                </p>
              </div>
              <Monitor className="w-4 h-4 text-slate-400" />
            </div>

            <div className="space-y-4">
              {osBreakdown.length === 0 ? (
                <p className="text-xs text-slate-500">لا توجد أنظمة نشطة ضمن التصفية الحالية.</p>
              ) : (
                osBreakdown.map((row) => (
                  <div key={row.os}>
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="font-medium text-slate-800 dark:text-slate-200">{row.label}</span>
                      <span className="font-mono tabular-nums text-slate-500 dark:text-slate-400">
                        {row.users.toLocaleString('en-US')} · {row.pct}%
                      </span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-emerald-600 rounded-full transition-all duration-300"
                        style={{ width: `${row.pct}%` }}
                      />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>التوافق المتعدد للأنظمة</span>
            <span className="font-mono text-slate-700 dark:text-slate-300">6 منصات مدعومة</span>
          </div>
        </div>
      </section>

      {/* Per-Application Real-Time Analytics Table */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              إحصائيات التحميل والنشاط اللحظي لكل تطبيق
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              تتحدّث الأرقام تلقائياً وفورياً عبر قاعدة البيانات السحابية عند أي تحميل أو اتصال جديد.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <div className="flex items-center gap-1.5 text-xs text-emerald-700 dark:text-emerald-400">
              <Activity className="w-4 h-4" />
              <span>بث لحظي نشط</span>
            </div>
            <button
              type="button"
              disabled={filteredApps.length === 0}
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap"
            >
              {exportedCsv ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>تم تصدير CSV</span>
                </>
              ) : (
                <>
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  <span>تصدير CSV</span>
                </>
              )}
            </button>
          </div>
        </div>

        {deleteError && (
          <div className="mx-5 mt-4 p-3 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 min-w-0">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span className="break-words">{deleteError}</span>
            </div>
            <button
              type="button"
              onClick={() => setDeleteError('')}
              className="text-red-600 dark:text-red-300 hover:underline shrink-0"
            >
              إغلاق
            </button>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-right text-sm">
            <thead className="bg-slate-50 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
              <tr>
                <th className="py-3 px-5 font-medium">التطبيق</th>
                <th className="py-3 px-4 font-medium">الإصدار الحالي</th>
                <th className="py-3 px-4 font-medium">الأنظمة المدعومة</th>
                <th className="py-3 px-4 font-medium">التحميلات (النطاق)</th>
                <th className="py-3 px-4 font-medium">إجمالي التحميلات</th>
                <th className="py-3 px-4 font-medium">المستخدمون النشطون</th>
                <th className="py-3 px-4 font-medium">الاستقرار</th>
                <th className="py-3 px-5 font-medium">اختبار التحديث اللحظي</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredApps.map((app) => {
                const rangedDownloads = Math.round(app.downloadsCount * rangeFactor);
                return (
                  <tr
                    key={app.id}
                    className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3.5 px-5">
                      <button
                        type="button"
                        onClick={() => onSelectApp(app.id)}
                        className="flex items-center gap-3 text-right group"
                      >
                        <img
                          src={app.iconUrl || '/src/assets/images/app_icon_cloudsync_1795296596170.jpg'}
                          alt={app.name}
                          referrerPolicy="no-referrer"
                          className="w-9 h-9 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                        />
                        <div>
                          <div className="font-semibold text-slate-900 dark:text-white group-hover:text-emerald-600 transition-colors flex items-center gap-1">
                            <span>{app.name}</span>
                            <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400">
                            {app.autoUpdate ? 'تحديث تلقائي مفعّل' : 'تحديث يدوي'}
                            <span aria-hidden="true"> · </span>
                            <span className="font-mono">{app.channel}</span>
                          </div>
                        </div>
                      </button>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-xs text-slate-800 dark:text-slate-200 tabular-nums">
                      v{app.latestVersion}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-600 dark:text-slate-400">
                      {app.supportedOS.map((os) => OS_LABELS[os].label).join(' · ')}
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums font-medium text-slate-900 dark:text-white">
                      {rangedDownloads.toLocaleString('en-US')}
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums text-slate-600 dark:text-slate-300">
                      {app.downloadsCount.toLocaleString('en-US')}
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums font-semibold text-emerald-700 dark:text-emerald-400">
                      {app.activeUsersCount.toLocaleString('en-US')}
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums text-xs text-slate-700 dark:text-slate-300">
                      {app.crashFreeRate}%
                    </td>
                    <td className="py-3.5 px-5">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          disabled={busyId === `${app.id}-download`}
                          onClick={() => handleQuickAction(app, 'download')}
                          className="px-2.5 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap"
                        >
                          +1 تحميل
                        </button>
                        <button
                          type="button"
                          disabled={busyId === `${app.id}-active`}
                          onClick={() => handleQuickAction(app, 'active')}
                          className="px-2.5 py-1.5 rounded-md border border-emerald-200 dark:border-emerald-900 bg-emerald-50/70 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-xs font-medium text-emerald-800 dark:text-emerald-300 transition-colors whitespace-nowrap"
                        >
                          <TrendingUp className="w-3 h-3 inline ml-1" />
                          +1 مستخدم نشط
                        </button>
                        {confirmDeleteId === app.id ? (
                          <>
                            <button
                              type="button"
                              disabled={busyId === `${app.id}-delete`}
                              onClick={async () => {
                                setBusyId(`${app.id}-delete`);
                                setDeleteError('');
                                try {
                                  await onDeleteApp(app.id);
                                  setConfirmDeleteId(null);
                                } catch (err) {
                                  setDeleteError(
                                    err instanceof Error
                                      ? `تعذر حذف البرنامج: ${err.message}`
                                      : 'تعذر حذف البرنامج من قاعدة البيانات.'
                                  );
                                } finally {
                                  setBusyId(null);
                                }
                              }}
                              className="px-2.5 py-1.5 rounded-md bg-red-600 hover:bg-red-700 text-white text-xs font-medium transition-colors whitespace-nowrap disabled:opacity-50"
                            >
                              {busyId === `${app.id}-delete` ? 'جاري...' : 'تأكيد'}
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="px-2 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 whitespace-nowrap"
                            >
                              إلغاء
                            </button>
                          </>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              setDeleteError('');
                              setConfirmDeleteId(app.id);
                            }}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 text-xs font-medium transition-colors whitespace-nowrap"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            حذف
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filteredApps.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-8 px-5 text-center text-xs text-slate-500 dark:text-slate-400">
                    لا توجد برامج مسجلة حالياً على المنصة.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
