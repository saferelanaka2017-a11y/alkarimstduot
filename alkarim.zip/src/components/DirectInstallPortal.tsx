import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  Check,
  CheckCircle2,
  Copy,
  Download,
  Monitor,
  ShieldCheck,
  Terminal,
  X,
} from 'lucide-react';
import { AppRelease, OS_LABELS, SoftwareApp, TargetOS } from '../types';
import {
  DownloadCancelledError,
  downloadPackage,
  type DownloadProgressState,
} from '../lib/chunkedDownload';

interface DirectInstallPortalProps {
  apps: SoftwareApp[];
  releasesByApp: Record<string, AppRelease[]>;
  installedVersions: Record<string, string>;
  initialSelectedAppId?: string | null;
  onDownloadAndInstall: (app: SoftwareApp, os: TargetOS) => Promise<void>;
  getAuthToken?: () => Promise<string | undefined>;
  isPublicStandalone?: boolean;
  onBackToLogin?: () => void;
}

function detectClientOS(): TargetOS {
  if (typeof navigator === 'undefined') return 'windows';
  const ua = navigator.userAgent.toLowerCase();
  if (ua.includes('android')) return 'android';
  if (ua.includes('iphone') || ua.includes('ipad')) return 'ios';
  if (ua.includes('mac')) return 'macos';
  if (ua.includes('linux')) return 'linux';
  return 'windows';
}

function semverCompare(a: string, b: string): number {
  const pa = a.replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
  const pb = b.replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length, 3);
  for (let i = 0; i < len; i++) {
    const va = pa[i] || 0;
    const vb = pb[i] || 0;
    if (va > vb) return 1;
    if (va < vb) return -1;
  }
  return 0;
}

function getReleaseTimeMs(createdAt: unknown): number {
  if (!createdAt) return 0;
  if (typeof createdAt === 'object' && createdAt !== null) {
    const ts = createdAt as { toMillis?: () => number; seconds?: number };
    if (typeof ts.toMillis === 'function') return ts.toMillis();
    if (typeof ts.seconds === 'number') return ts.seconds * 1000;
  }
  if (typeof createdAt === 'string') {
    const ms = Date.parse(createdAt);
    return Number.isFinite(ms) ? ms : 0;
  }
  return 0;
}

export const DirectInstallPortal: React.FC<DirectInstallPortalProps> = ({
  apps,
  releasesByApp,
  installedVersions,
  initialSelectedAppId,
  onDownloadAndInstall,
  getAuthToken,
  isPublicStandalone = false,
  onBackToLogin,
}) => {
  const detectedOS = useMemo(() => detectClientOS(), []);
  const visibleApps = apps;
  const [selectedId, setSelectedId] = useState<string | null>(initialSelectedAppId || null);

  useEffect(() => {
    if (initialSelectedAppId) {
      setSelectedId(initialSelectedAppId);
    }
  }, [initialSelectedAppId]);

  const activeApp =
    visibleApps.find((a) => a.id === selectedId || a.slug === selectedId) ||
    visibleApps.find((a) => a.id === initialSelectedAppId || a.slug === initialSelectedAppId) ||
    visibleApps[0] ||
    null;

  const [selectedOS, setSelectedOS] = useState<TargetOS>(
    activeApp?.supportedOS.includes(detectedOS)
      ? detectedOS
      : activeApp?.supportedOS[0] || 'windows'
  );
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [installing, setInstalling] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<DownloadProgressState | null>(null);
  const [downloadError, setDownloadError] = useState('');
  const [installSuccess, setInstallSuccess] = useState(false);
  const downloadAbortRef = useRef<AbortController | null>(null);

  const activeReleases = useMemo(() => {
    if (!activeApp) return [];
    return (releasesByApp[activeApp.id] || [])
      .filter((r) => r.status !== 'scheduled')
      .sort((a, b) => {
        const timeDiff = getReleaseTimeMs(b.createdAt) - getReleaseTimeMs(a.createdAt);
        if (timeDiff !== 0) return timeDiff;
        return semverCompare(b.version, a.version);
      });
  }, [activeApp, releasesByApp]);

  // Keep selectedOS aligned with the active app's supported OS list & uploaded releases
  useEffect(() => {
    if (!activeApp) return;
    const hasExactRelease = activeReleases.some((r) => r.targetOS === selectedOS);
    if (activeApp.supportedOS.includes(selectedOS) && (activeReleases.length === 0 || hasExactRelease)) {
      return;
    }
    if (activeReleases.length > 0) {
      const preferred =
        activeReleases.find((r) => r.targetOS === detectedOS)?.targetOS || activeReleases[0].targetOS;
      setSelectedOS(preferred);
    } else if (activeApp.supportedOS.length > 0) {
      setSelectedOS(
        activeApp.supportedOS.includes(detectedOS) ? detectedOS : activeApp.supportedOS[0]
      );
    }
  }, [activeApp?.id, activeApp?.supportedOS, activeReleases, detectedOS]);

  const normalizedLatest = (activeApp?.latestVersion || '').replace(/^v/i, '');
  const matchingRelease =
    activeReleases.find(
      (r) => r.targetOS === selectedOS && r.version.replace(/^v/i, '') === normalizedLatest
    ) || activeReleases.find((r) => r.targetOS === selectedOS);

  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const cliCommand = activeApp
    ? selectedOS === 'windows'
      ? `irm "${origin}/api/v1/install/${activeApp.slug}?os=windows" | iex`
      : `curl -fsSL "${origin}/api/v1/install/${activeApp.slug}?os=${selectedOS}" | sh`
    : '';

  const handleCopy = async () => {
    if (!cliCommand) return;
    await navigator.clipboard.writeText(cliCommand);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 1800);
  };

  const handleCancelDownload = () => {
    downloadAbortRef.current?.abort();
  };

  const handleDirectInstall = async () => {
    if (!activeApp) return;
    const abortController = new AbortController();
    downloadAbortRef.current = abortController;
    setInstalling(true);
    setInstallSuccess(false);
    setDownloadError('');
    setDownloadProgress(null);

    const targetVersion = matchingRelease?.version || activeApp.latestVersion;
    const url =
      matchingRelease?.downloadUrl ||
      `/api/packages/download/pkg-${activeApp.slug}?os=${selectedOS}&version=${encodeURIComponent(targetVersion)}`;
    const fallbackFileName = `${activeApp.slug}-v${targetVersion}-${selectedOS}.${
      selectedOS === 'windows' ? 'ps1' : 'sh'
    }`;
    const fileName = matchingRelease?.fileName || fallbackFileName;

    try {
      await downloadPackage({
        downloadUrl: url,
        fileName,
        appId: activeApp.id,
        targetOS: selectedOS,
        getToken: getAuthToken,
        onProgress: (state) => setDownloadProgress(state),
        signal: abortController.signal,
      });
      setInstallSuccess(true);
      onDownloadAndInstall(activeApp, selectedOS).catch(() => {
        // Keep downloaded file intact even if analytics increment fails for unauthenticated/private preview
      });
    } catch (err) {
      if (err instanceof DownloadCancelledError) {
        setDownloadError('تم إلغاء تحميل الحزمة.');
      } else {
        setDownloadError(
          err instanceof Error ? err.message : 'تعذر تحميل الحزمة. يرجى التحقق من الاتصال والمحاولة مجدداً.'
        );
      }
    } finally {
      downloadAbortRef.current = null;
      setInstalling(false);
      setDownloadProgress(null);
    }
  };

  const installedVer = activeApp ? installedVersions[activeApp.id] : undefined;
  const isUpToDate = installedVer && activeApp && installedVer === activeApp.latestVersion;

  return (
    <div className={isPublicStandalone ? 'min-h-screen bg-slate-50 dark:bg-slate-950 p-6 sm:p-10' : 'space-y-6'} dir="rtl">
      {isPublicStandalone && (
        <header className="max-w-5xl mx-auto mb-8 flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <img
              src="/src/assets/images/alkarim_brand_emblem_1795296596572.jpg"
              alt="AlKarim"
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-lg object-cover border border-slate-200 dark:border-slate-800"
            />
            <div>
              <span className="text-lg font-bold text-slate-900 dark:text-white">AlKarim</span>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                بوابة العملاء والتحميل المباشر
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {onBackToLogin && (
              <button
                type="button"
                onClick={onBackToLogin}
                className="px-4 py-2 rounded-lg bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-medium whitespace-nowrap"
              >
                تسجيل دخول العميل
              </button>
            )}
          </div>
        </header>
      )}

      <div className={isPublicStandalone ? 'max-w-5xl mx-auto space-y-6' : 'space-y-6'}>
        {/* App Selector Row */}
        {visibleApps.length > 0 && (
          <div className="flex flex-wrap items-center gap-2">
            {visibleApps.map((app) => {
              const isSelected = activeApp?.id === app.id;
              return (
                <button
                  key={app.id}
                  type="button"
                  onClick={() => {
                    setSelectedId(app.id);
                    setInstallSuccess(false);
                    setDownloadError('');
                    if (!app.supportedOS.includes(selectedOS)) {
                      setSelectedOS(app.supportedOS[0] || 'windows');
                    }
                  }}
                  className={`flex items-center gap-2.5 px-3.5 py-2 rounded-xl border text-xs font-medium transition-colors whitespace-nowrap ${
                    isSelected
                      ? 'bg-white dark:bg-slate-900 border-emerald-600 text-slate-900 dark:text-white'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <img
                    src={app.iconUrl || '/src/assets/images/app_icon_cloudsync_1795296596170.jpg'}
                    alt={app.name}
                    referrerPolicy="no-referrer"
                    className="w-5 h-5 rounded object-cover"
                  />
                  <span>{app.name}</span>
                </button>
              );
            })}
          </div>
        )}

        {!activeApp ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center text-sm text-slate-500">
            لا توجد برامج عامة متاحة في بوابة التحميل المباشر حالياً.
          </div>
        ) : (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 sm:p-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Right Info Column */}
              <div className="lg:col-span-7 space-y-5">
                <div className="flex items-start gap-4">
                  <img
                    src={activeApp.iconUrl || '/src/assets/images/app_icon_cloudsync_1795296596170.jpg'}
                    alt={activeApp.name}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                  />
                  <div>
                    <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
                      {activeApp.name}
                    </h1>
                    <div className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 flex flex-wrap items-center gap-2">
                      <span className="font-mono text-emerald-700 dark:text-emerald-400 font-semibold">
                        الإصدار v{activeApp.latestVersion}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>نظامك المكتشف: {OS_LABELS[detectedOS].label}</span>
                      <span aria-hidden="true">·</span>
                      <span>{activeApp.autoUpdate ? 'تحديث تلقائي مفعّل' : 'تحديث يدوي'}</span>
                    </div>
                  </div>
                </div>

                <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {activeApp.description}
                </p>

                {/* OS Tabs */}
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">
                    اختر نظام التشغيل للتنصيب المباشر:
                  </label>
                  <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg w-fit">
                    {activeApp.supportedOS.map((os) => (
                      <button
                        key={os}
                        type="button"
                        onClick={() => {
                          setSelectedOS(os);
                          setDownloadError('');
                          setInstallSuccess(false);
                        }}
                        className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                          selectedOS === os
                            ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        {OS_LABELS[os].label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* One-Line CLI Installer */}
                <div className="pt-2">
                  <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1.5">
                    <span className="inline-flex items-center gap-1.5">
                      <Terminal className="w-3.5 h-3.5" />
                      أمر التنصيب السريع عبر الطرفية
                    </span>
                    <button
                      type="button"
                      onClick={handleCopy}
                      className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 hover:underline"
                    >
                      {copiedCmd ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedCmd ? 'تم النسخ' : 'نسخ الأمر'}
                    </button>
                  </div>
                  <pre className="p-3 rounded-lg bg-slate-950 text-slate-100 text-xs font-mono overflow-x-auto border border-slate-800">
                    <code>{cliCommand}</code>
                  </pre>
                </div>
              </div>

              {/* Left Direct Download Box */}
              <div className="lg:col-span-5 bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span className="inline-flex items-center gap-1.5">
                    <Monitor className="w-4 h-4 text-emerald-600" />
                    حزمة {OS_LABELS[selectedOS].label}
                  </span>
                  <span className="font-mono">{OS_LABELS[selectedOS].arch}</span>
                </div>

                <div>
                  <button
                    type="button"
                    disabled={installing}
                    onClick={handleDirectInstall}
                    className="w-full py-3.5 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white text-sm font-bold transition-colors flex items-center justify-center gap-2.5"
                  >
                    <Download className="w-4 h-4" />
                    <span>
                      {installing
                        ? downloadProgress
                          ? `جاري التحميل (${downloadProgress.percent}%)...`
                          : 'جاري تجهيز الحزمة...'
                        : installedVer && !isUpToDate
                          ? `تحديث مباشر إلى v${activeApp.latestVersion} (${OS_LABELS[selectedOS].label})`
                          : `تحميل وتنصيب مباشر (${OS_LABELS[selectedOS].label})`}
                    </span>
                  </button>

                  {installing && downloadProgress && (
                    <div className="mt-3 p-3.5 rounded-lg bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-900 space-y-2 text-xs">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-medium text-emerald-800 dark:text-emerald-300 truncate">
                          {downloadProgress.statusText}
                        </span>
                        <button
                          type="button"
                          onClick={handleCancelDownload}
                          className="inline-flex items-center gap-1 text-red-600 hover:text-red-700 font-medium shrink-0"
                        >
                          <X className="w-3.5 h-3.5" />
                          إلغاء
                        </button>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-emerald-600 transition-all duration-200"
                          style={{ width: `${Math.max(4, downloadProgress.percent)}%` }}
                        />
                      </div>
                      <div className="flex items-center justify-between text-[11px] font-mono tabular-nums text-slate-600 dark:text-slate-400">
                        <span>
                          {(downloadProgress.receivedBytes / (1024 * 1024)).toFixed(1)} /{' '}
                          {downloadProgress.totalBytes > 0
                            ? `${(downloadProgress.totalBytes / (1024 * 1024)).toFixed(1)} MB`
                            : '—'}
                        </span>
                        <span>
                          {downloadProgress.speedBytesPerSec > 0
                            ? `${(downloadProgress.speedBytesPerSec / (1024 * 1024)).toFixed(1)} MB/s`
                            : '—'}
                        </span>
                      </div>
                    </div>
                  )}

                  {downloadError && (
                    <div className="mt-3 p-3 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{downloadError}</span>
                    </div>
                  )}

                  {installedVer && (
                    <div className="mt-3 flex items-center gap-2 text-xs text-emerald-700 dark:text-emerald-400">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span>
                        {isUpToDate
                          ? `مثبّت على جهازك بالإصدار الأحدث v${installedVer} — ستصلك إشعارات التحديث تلقائياً.`
                          : `مثبّت لديك الإصدار v${installedVer} — يتوفر تحديث v${activeApp.latestVersion}.`}
                      </span>
                    </div>
                  )}

                  {installSuccess && !installedVer && (
                    <div className="mt-3 text-xs text-emerald-700 dark:text-emerald-400">
                      اكتمل تحميل حزمة التنصيب المباشر وتم تسجيل جهازك لتلقي التحديثات التلقائية الفورية.
                    </div>
                  )}
                </div>

                <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">حجم الحزمة</span>
                    <span className="font-mono text-slate-800 dark:text-slate-200 tabular-nums">
                      {matchingRelease
                        ? `${Math.max(0.1, matchingRelease.fileSizeBytes / (1024 * 1024)).toFixed(1)} MB`
                        : 'أداة تنصيب فورية'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">عدد التحميلات</span>
                    <span className="font-mono text-slate-800 dark:text-slate-200 tabular-nums">
                      {activeApp.downloadsCount.toLocaleString('en-US')}
                    </span>
                  </div>
                  <div className="flex items-start justify-between gap-3">
                    <span className="text-slate-500 shrink-0">SHA-256</span>
                    <span className="font-mono text-[11px] text-slate-600 dark:text-slate-400 truncate max-w-[200px]">
                      {matchingRelease?.sha256 || 'يُتحقق تلقائياً عبر TLS / AlKarim'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 pt-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>حزمة موقّعة رقمياً ومفحوصة بالتكامل السحابي</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
