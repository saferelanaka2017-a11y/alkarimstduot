import React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Cpu,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  XCircle,
} from 'lucide-react';
import { CompatibilityCheckResult, OS_LABELS } from '../types';

interface CompatibilityReportPanelProps {
  report: CompatibilityCheckResult | null;
  loading: boolean;
  onRerun: () => void;
}

export const CompatibilityReportPanel: React.FC<CompatibilityReportPanelProps> = ({
  report,
  loading,
  onRerun,
}) => {
  if (loading) {
    return (
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5 text-slate-700 dark:text-slate-300">
          <RefreshCw className="w-4 h-4 animate-spin text-emerald-600 shrink-0" />
          <span>جاري تشغيل الاختبار التلقائي للتوافق وفحص الترويسة الثنائية مقابل متطلبات النظام...</span>
        </div>
      </div>
    );
  }

  if (!report) {
    return null;
  }

  const isFailed = report.overallStatus === 'failed';
  const isWarning = report.overallStatus === 'warnings';

  return (
    <div
      className={`rounded-xl border p-4 space-y-4 ${
        isFailed
          ? 'bg-red-50/70 dark:bg-red-950/30 border-red-200 dark:border-red-900'
          : isWarning
            ? 'bg-amber-50/70 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900'
            : 'bg-emerald-50/60 dark:bg-emerald-950/25 border-emerald-200 dark:border-emerald-900'
      }`}
    >
      {/* Header Summary */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start gap-2.5">
          {isFailed ? (
            <ShieldAlert className="w-5 h-5 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
          ) : isWarning ? (
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          ) : (
            <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
          )}
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs font-bold text-slate-900 dark:text-white">
              <span>تقرير اختبار التوافق الفوري ({OS_LABELS[report.targetOS].label})</span>
              <span aria-hidden="true">·</span>
              <span
                className={`font-mono tabular-nums ${
                  isFailed
                    ? 'text-red-700 dark:text-red-400'
                    : isWarning
                      ? 'text-amber-700 dark:text-amber-400'
                      : 'text-emerald-700 dark:text-emerald-400'
                }`}
              >
                {report.score}% جاهزية
              </span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
              {report.summary}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onRerun}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          إعادة الفحص
        </button>
      </div>

      {/* Detected Binary & Arch Meta */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-slate-600 dark:text-slate-400 pt-2 border-t border-slate-200/70 dark:border-slate-800">
        <span className="inline-flex items-center gap-1">
          <Cpu className="w-3.5 h-3.5" />
          الصيغة المكتشفة: <strong className="text-slate-800 dark:text-slate-200">{report.detectedFormat}</strong>
        </span>
        <span aria-hidden="true">·</span>
        <span>
          المعمارية: <span className="font-mono text-slate-800 dark:text-slate-200">{report.detectedArch}</span>
        </span>
      </div>

      {/* Individual Checks */}
      <div className="space-y-2">
        {report.checks.map((item) => (
          <div
            key={item.id}
            className="p-2.5 rounded-lg bg-white/90 dark:bg-slate-900/90 border border-slate-200/80 dark:border-slate-800 flex items-start gap-2.5 text-xs"
          >
            {item.status === 'pass' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            ) : item.status === 'warning' ? (
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            ) : (
              <XCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            )}
            <div className="min-w-0">
              <div className="font-semibold text-slate-900 dark:text-white">{item.title}</div>
              <div className="text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">{item.detail}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Target OS Baseline Requirements */}
      <div className="pt-2 border-t border-slate-200/70 dark:border-slate-800">
        <div className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
          قائمة متطلبات {OS_LABELS[report.targetOS].label} التي تم الفحص مقابلها:
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-[11px] text-slate-600 dark:text-slate-400">
          {report.osRequirements.map((req) => (
            <div key={req} className="flex items-center gap-1.5">
              <span className="w-1 h-1 rounded-full bg-slate-400 shrink-0" />
              <span>{req}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
