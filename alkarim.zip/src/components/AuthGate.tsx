import React, { useEffect, useState } from 'react';
import {
  Auth,
  createUserWithEmailAndPassword,
  getRedirectResult,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect,
  updateProfile,
} from 'firebase/auth';
import {
  ShieldCheck,
  Mail,
  Lock,
  User as UserIcon,
  Eye,
  EyeOff,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  Check,
  Copy,
  ExternalLink,
  Download,
} from 'lucide-react';
import { auth, facebookProvider, githubProvider, googleProvider, twitterProvider } from '../firebase';
import firebaseConfig from '../../firebase-applet-config.json';
import { PortalEntryMode } from '../lib/portalRoutes';

const OFFICIAL_APP_URL = 'https://ais-dev-pbb243ak4wcrfmbdpfvvid-913751017831.europe-west2.run.app';

interface AuthGateProps {
  selectedRole: 'user' | 'developer';
  onSelectRole: (role: 'user' | 'developer') => void;
  onOpenPublicPortal: () => void;
  entryMode?: PortalEntryMode;
  onSwitchEntryMode?: (mode: 'developer' | 'client') => void;
  authInstance?: Auth;
  externalError?: string | null;
  onClearExternalError?: () => void;
}

export const AuthGate: React.FC<AuthGateProps> = ({
  selectedRole,
  onSelectRole,
  onOpenPublicPortal,
  entryMode = 'default',
  onSwitchEntryMode,
  authInstance = auth,
  externalError = null,
  onClearExternalError,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [unauthorizedHost, setUnauthorizedHost] = useState('');
  const [blockedPopupProvider, setBlockedPopupProvider] = useState<'google' | 'facebook' | 'github' | 'twitter' | null>(null);
  const [suggestGoogleFallback, setSuggestGoogleFallback] = useState(false);
  const [copiedHost, setCopiedHost] = useState(false);
  const [infoMsg, setInfoMsg] = useState('');

  const getProviderInstance = (providerType: 'google' | 'facebook' | 'github' | 'twitter') => {
    if (providerType === 'google') return googleProvider;
    if (providerType === 'facebook') return facebookProvider;
    if (providerType === 'github') return githubProvider;
    return twitterProvider;
  };

  const getProviderLabel = (providerType: 'google' | 'facebook' | 'github' | 'twitter') => {
    if (providerType === 'google') return 'Google';
    if (providerType === 'facebook') return 'Facebook';
    if (providerType === 'github') return 'GitHub';
    return 'X (Twitter)';
  };

  const handleAuthError = (
    err: unknown,
    providerName?: string,
    providerType?: 'google' | 'facebook' | 'github' | 'twitter'
  ) => {
    const code = (err as { code?: string })?.code || '';
    setUnauthorizedHost('');
    setBlockedPopupProvider(null);
    setSuggestGoogleFallback(false);

    if (code === 'auth/unauthorized-domain') {
      const host = typeof window !== 'undefined' ? window.location.hostname : '';
      setUnauthorizedHost(host);
      setErrorMsg(
        `النطاق الحالي (${host || 'غير معروف'}) غير مصرح به في إعدادات Firebase Authentication لتسجيل الدخول عبر ${providerName || 'المزود الخارجي'}.`
      );
    } else if (code === 'auth/operation-not-allowed') {
      setSuggestGoogleFallback(providerType !== 'google');
      setErrorMsg(
        `مزود تسجيل الدخول (${providerName || 'المحدد'}) غير مفعّل حالياً في Firebase Console ← Authentication ← Sign-in method (مشروع ${firebaseConfig.projectId}).`
      );
    } else if (code === 'auth/popup-blocked') {
      if (providerType) setBlockedPopupProvider(providerType);
      setErrorMsg('قام المتصفح بحظر النافذة المنبثقة لتسجيل الدخول. يمكنك السماح بالنوافذ المنبثقة أو استخدام خيار إعادة التوجيه أدناه.');
    } else if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
      setErrorMsg('تم إغلاق نافذة المصادقة قبل إتمام تسجيل الدخول.');
    } else if (code === 'auth/invalid-credential' || code === 'auth/wrong-password' || code === 'auth/user-not-found') {
      setSuggestGoogleFallback(true);
      setErrorMsg(
        'بيانات البريد الإلكتروني أو كلمة المرور غير صحيحة. تأكد من كتابة البريد وكلمة المرور بشكل صحيح، أو استخدم الدخول عبر Google إذا سجلت به سابقاً.'
      );
    } else if (code === 'auth/invalid-email') {
      setErrorMsg('صيغة البريد الإلكتروني غير صحيحة.');
    } else if (code === 'auth/email-already-in-use') {
      setErrorMsg('هذا البريد الإلكتروني مسجل مسبقاً. بدّل إلى تبويب «تسجيل الدخول» أو استخدم المتابعة عبر Google.');
    } else if (code === 'auth/weak-password') {
      setErrorMsg('كلمة المرور ضعيفة؛ يجب أن تكون 6 أحرف على الأقل.');
    } else if (code === 'auth/network-request-failed') {
      setErrorMsg('تعذر الاتصال بخوادم المصادقة. تحقق من اتصالك بالإنترنت ثم أعد المحاولة.');
    } else if (code === 'auth/too-many-requests') {
      setErrorMsg('تم إرسال محاولات متكررة. انتظر قليلاً ثم أعد المحاولة.');
    } else if (code === 'auth/account-exists-with-different-credential') {
      setSuggestGoogleFallback(true);
      setErrorMsg('يوجد حساب مرتبط بهذا البريد عبر مزود آخر. سجّل الدخول بالطريقة الأصلية (مثل Google).');
    } else {
      setErrorMsg(err instanceof Error ? err.message : 'تعذر إتمام تسجيل الدخول.');
    }
  };

  // Surface any errors if a redirect fallback sign-in returned to this page
  useEffect(() => {
    let active = true;
    getRedirectResult(authInstance).catch((err) => {
      if (active && err) {
        handleAuthError(err, 'إعادة التوجيه');
      }
    });
    return () => {
      active = false;
    };
  }, [authInstance]);

  const clearErrors = () => {
    setErrorMsg('');
    setInfoMsg('');
    setUnauthorizedHost('');
    setBlockedPopupProvider(null);
    setSuggestGoogleFallback(false);
    onClearExternalError?.();
  };

  const handleSocialLogin = async (providerType: 'google' | 'facebook' | 'github' | 'twitter') => {
    clearErrors();
    setLoading(true);
    try {
      const provider = getProviderInstance(providerType);
      await signInWithPopup(authInstance, provider);
    } catch (err) {
      handleAuthError(err, getProviderLabel(providerType), providerType);
    } finally {
      setLoading(false);
    }
  };

  const handleSocialRedirectFallback = async (providerType: 'google' | 'facebook' | 'github' | 'twitter') => {
    clearErrors();
    setLoading(true);
    try {
      await signInWithRedirect(authInstance, getProviderInstance(providerType));
    } catch (err) {
      handleAuthError(err, getProviderLabel(providerType), providerType);
      setLoading(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearErrors();

    const trimmedEmail = email.trim();
    if (!trimmedEmail || !password) {
      setErrorMsg('يرجى إدخال البريد الإلكتروني وكلمة المرور.');
      return;
    }
    if (mode === 'register') {
      if (!displayName.trim()) {
        setErrorMsg(
          entryMode === 'client' ? 'يرجى إدخال الاسم الكامل.' : 'يرجى إدخال الاسم الكامل أو اسم الفريق.'
        );
        return;
      }
      if (password.length < 6) {
        setErrorMsg('يجب أن تتكون كلمة المرور من 6 أحرف على الأقل.');
        return;
      }
    }

    setLoading(true);
    try {
      if (mode === 'register') {
        const cred = await createUserWithEmailAndPassword(authInstance, trimmedEmail, password);
        if (displayName.trim()) {
          await updateProfile(cred.user, { displayName: displayName.trim() });
          await cred.user.reload();
        }
      } else {
        await signInWithEmailAndPassword(authInstance, trimmedEmail, password);
      }
    } catch (err) {
      handleAuthError(err, 'البريد الإلكتروني وكلمة المرور');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordReset = async () => {
    clearErrors();
    const trimmedEmail = email.trim();
    if (!trimmedEmail) {
      setErrorMsg('أدخل بريدك الإلكتروني أولاً ثم اضغط على «نسيت كلمة المرور؟».');
      return;
    }
    setLoading(true);
    try {
      await sendPasswordResetEmail(authInstance, trimmedEmail);
      setInfoMsg(`تم إرسال رابط إعادة تعيين كلمة المرور إلى ${trimmedEmail}.`);
    } catch (err) {
      handleAuthError(err, 'البريد الإلكتروني');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 grid lg:grid-cols-12" dir="rtl">
      {/* Right Column: Auth Card */}
      <div className="lg:col-span-6 flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <img
                src="/src/assets/images/alkarim_brand_emblem_1795296596572.jpg"
                alt="شعار منصة AlKarim"
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-lg object-cover border border-slate-200 dark:border-slate-800"
              />
              <div>
                <span className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">AlKarim</span>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {entryMode === 'developer'
                    ? 'بوابة المطورين — لوحة التحكم والنشر'
                    : entryMode === 'client'
                      ? 'بوابة العملاء — تسجيل دخول العميل'
                      : 'منصة نشر التطبيقات والتحديث السحابي'}
                </p>
              </div>
            </div>
            {entryMode === 'developer' && onSwitchEntryMode ? (
              <button
                type="button"
                onClick={() => onSwitchEntryMode('client')}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline whitespace-nowrap shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                بوابة العملاء
              </button>
            ) : (
              <button
                type="button"
                onClick={onOpenPublicPortal}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400 hover:underline whitespace-nowrap shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                تصفح البرامج العامة
              </button>
            )}
          </div>

          {/* Segmented Switch: Login vs Register */}
          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg mb-5">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                clearErrors();
              }}
              className={`py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                mode === 'login'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              تسجيل الدخول
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                clearErrors();
              }}
              className={`py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                mode === 'register'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              إنشاء حساب جديد
            </button>
          </div>

          {/* Account Role Selection (shown in default mode; locked in /developer or /client mode) */}
          {entryMode === 'default' && (
            <div className="mb-5 p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800">
              <div className="text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-2">
                نوع الحساب (للمستخدمين الجدد):
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => onSelectRole('developer')}
                  className={`py-2 px-2.5 rounded-md border text-xs font-medium transition-colors whitespace-nowrap ${
                    selectedRole === 'developer'
                      ? 'bg-emerald-600 border-emerald-600 text-white'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  مطور (لوحة النشر والإدارة)
                </button>
                <button
                  type="button"
                  onClick={() => onSelectRole('user')}
                  className={`py-2 px-2.5 rounded-md border text-xs font-medium transition-colors whitespace-nowrap ${
                    selectedRole === 'user'
                      ? 'bg-emerald-600 border-emerald-600 text-white'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  عميل (تحميل وتحديث فقط)
                </button>
              </div>
            </div>
          )}

          {(externalError || errorMsg) && (
            <div className="mb-4 p-3.5 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 space-y-2.5 leading-relaxed">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{externalError || errorMsg}</span>
              </div>
              {unauthorizedHost && (
                <div className="pt-2 border-t border-red-200 dark:border-red-900/70 space-y-2 text-[11px] text-red-800 dark:text-red-200">
                  <p>
                    للتسجيل من هذا الرابط الخارجي، أضف النطاق التالي في{' '}
                    <span className="font-mono" dir="ltr">
                      Firebase Console ({firebaseConfig.projectId}) → Authentication → Settings → Authorized domains
                    </span>
                    :
                  </p>
                  <div className="flex items-center justify-between gap-2 bg-white dark:bg-slate-900 px-2.5 py-1.5 rounded border border-red-200 dark:border-red-900">
                    <code className="font-mono text-slate-900 dark:text-white truncate" dir="ltr">
                      {unauthorizedHost}
                    </code>
                    <button
                      type="button"
                      onClick={async () => {
                        await navigator.clipboard.writeText(unauthorizedHost);
                        setCopiedHost(true);
                        setTimeout(() => setCopiedHost(false), 1800);
                      }}
                      className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 font-medium shrink-0"
                    >
                      {copiedHost ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedHost ? 'تم النسخ' : 'نسخ النطاق'}
                    </button>
                  </div>
                  <a
                    href={OFFICIAL_APP_URL}
                    target="_top"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white font-medium transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>فتح الرابط الرسمي المعتمد للدخول الفوري</span>
                  </a>
                </div>
              )}
              {blockedPopupProvider && (
                <div className="pt-2 border-t border-red-200 dark:border-red-900/70">
                  <button
                    type="button"
                    disabled={loading}
                    onClick={() => handleSocialRedirectFallback(blockedPopupProvider)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-medium text-[11px]"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>المتابعة عبر إعادة التوجيه ({getProviderLabel(blockedPopupProvider)})</span>
                  </button>
                </div>
              )}
              {suggestGoogleFallback && !unauthorizedHost && (
                <div className="pt-2 border-t border-red-200 dark:border-red-900/70">
                  <button
                    type="button"
                    disabled={loading}
                    onClick={() => handleSocialLogin('google')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-medium text-[11px]"
                  >
                    <span>المتابعة السريعة عبر حساب Google</span>
                  </button>
                </div>
              )}
            </div>
          )}
          {infoMsg && (
            <div className="mb-4 p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-700 dark:text-emerald-300 flex items-start gap-2 leading-relaxed">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{infoMsg}</span>
            </div>
          )}

          {/* Primary Standard Email & Password Login / Register Form */}
          <form onSubmit={handleEmailSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  الاسم الكامل أو اسم الفريق
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="كريم شحاتة"
                    className="w-full pr-10 pl-3 py-2.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    required
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                البريد الإلكتروني
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  dir="ltr"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="developer@alkarim.app"
                  className="w-full pr-10 pl-3 py-2.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600 text-left"
                  required
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                  كلمة المرور
                </label>
                {mode === 'login' && (
                  <button
                    type="button"
                    disabled={loading}
                    onClick={handlePasswordReset}
                    className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400 hover:underline"
                  >
                    نسيت كلمة المرور؟
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  dir="ltr"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pr-10 pl-10 py-2.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-600 text-left"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  aria-label="إظهار أو إخفاء كلمة المرور"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-medium transition-colors"
            >
              <span>
                {loading
                  ? 'جاري التنفيذ...'
                  : mode === 'login'
                    ? entryMode === 'client'
                      ? 'دخول إلى بوابة العملاء'
                      : 'دخول إلى المنصة'
                    : entryMode === 'client' || selectedRole === 'user'
                      ? 'إنشاء حساب عميل جديد'
                      : 'إنشاء حساب المطور'}
              </span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200 dark:border-slate-800" />
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="px-3 bg-white dark:bg-slate-900 text-slate-500">أو المتابعة عبر حسابات التواصل</span>
            </div>
          </div>

          {/* Optional Social Login Buttons */}
          <div className="space-y-2.5">
            <button
              type="button"
              disabled={loading}
              onClick={() => handleSocialLogin('google')}
              className="w-full flex items-center justify-center gap-2.5 py-2.5 px-4 rounded-lg bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-100 text-sm font-medium transition-colors whitespace-nowrap"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                <path
                  fill="currentColor"
                  d="M21.35 11.1h-9.17v2.73h6.51c-.33 3.81-3.5 5.44-6.5 5.44C8.36 19.27 5 16.25 5 12c0-4.1 3.2-7.27 7.2-7.27c3.09 0 4.9 1.97 4.9 1.97L19 4.72S16.56 2 12.1 2C6.42 2 2.03 6.8 2.03 12c0 5.05 4.13 10 10.22 10c5.35 0 9.25-3.67 9.25-9.09c0-1.15-.15-1.81-.15-1.81Z"
                />
              </svg>
              المتابعة عبر حساب Google
            </button>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                disabled={loading}
                onClick={() => handleSocialLogin('facebook')}
                className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap"
              >
                Facebook
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={() => handleSocialLogin('github')}
                className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap"
              >
                GitHub
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={() => handleSocialLogin('twitter')}
                className="flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap"
              >
                منصة X
              </button>
            </div>
          </div>

          <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>تسجيل دخول مباشر ومشفر بالبريد الإلكتروني وكلمة المرور</span>
          </div>
        </div>
      </div>

      {/* Left Column: Platform Overview */}
      <div className="hidden lg:flex lg:col-span-6 bg-slate-900 text-white p-14 flex-col justify-between border-r border-slate-800">
        {entryMode === 'client' ? (
          <>
            <div>
              <span className="text-xs font-medium text-emerald-400 tracking-wide">
                بوابة العملاء والتحميل المباشر
              </span>
              <h2 className="text-3xl font-bold mt-4 mb-5 leading-snug max-w-xl" style={{ textWrap: 'balance' }}>
                حمّل تطبيقاتك واحصل على التحديثات التلقائية بأمان وسرعة
              </h2>
              <p className="text-slate-300 text-sm leading-relaxed max-w-lg">
                سجّل الدخول بحسابك كعميل للوصول إلى جميع الإصدارات المتاحة لجهازك، متابعة ملاحظات التحديث، وتثبيت النسخ المعتمدة بضغطة واحدة.
              </p>
            </div>

            <div className="space-y-6 border-t border-slate-800 pt-8">
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <p className="text-xs text-slate-400 mb-1">التحديث التلقائي الفوري</p>
                  <p className="text-base font-semibold text-white">أحدث إصدار على جهازك دائماً</p>
                  <p className="text-xs text-slate-400 mt-1">تنبيهات فورية عند توفر نسخة جديدة وتطبيق سلس للتحديثات.</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">التحقق من السلامة</p>
                  <p className="text-base font-semibold text-white">حزم موثّقة ببصمة SHA-256</p>
                  <p className="text-xs text-slate-400 mt-1">تأكيد سلامة كل ملف قبل التثبيت لحماية جهازك.</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">توافق الأنظمة</p>
                  <p className="text-base font-semibold text-white">Windows · macOS · Linux · Mobile</p>
                  <p className="text-xs text-slate-400 mt-1">كشف تلقائي لنظام التشغيل واقتراح النسخة الأنسب لك.</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">سجل التغييرات</p>
                  <p className="text-base font-semibold text-white">ملاحظات واضحة لكل إصدار</p>
                  <p className="text-xs text-slate-400 mt-1">تعرّف على المزايا والإصلاحات الجديدة قبل التنزيل.</p>
                </div>
              </div>
            </div>
          </>
        ) : (
          <>
            <div>
              <span className="text-xs font-medium text-emerald-400 tracking-wide">
                سحابة النشر وإدارة الإصدارات
              </span>
              <h2 className="text-3xl font-bold mt-4 mb-5 leading-snug max-w-xl" style={{ textWrap: 'balance' }}>
                تحكم مركزي كامل ببرامجك، التحديثات الفورية، وإحصائيات التشغيل
              </h2>
              <p className="text-slate-300 text-sm leading-relaxed max-w-lg">
                ارفع تطبيقاتك بمختلف أنظمة التشغيل، ووفّر للمستخدمين بوابة تحميل وتنصيب مباشر مع مزامنة سحابية لحظية وتقارير أداء دقيقة.
              </p>
            </div>

            <div className="space-y-6 border-t border-slate-800 pt-8">
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <p className="text-xs text-slate-400 mb-1">التحديث التلقائي الفوري</p>
                  <p className="text-base font-semibold text-white">دفع الإصدارات لجميع الأجهزة</p>
                  <p className="text-xs text-slate-400 mt-1">تحقق SHA-256 وتطبيق فوري عبر قنوات Stable و Beta.</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">تحليلات الاستخدام</p>
                  <p className="text-base font-semibold text-white">إحصائيات تحميل ونشاط لحظية</p>
                  <p className="text-xs text-slate-400 mt-1">فلترة حسب النطاق الزمني والنظام مع تقارير CSV و JSON.</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">توافق الأنظمة</p>
                  <p className="text-base font-semibold text-white">Windows · macOS · Linux · Mobile</p>
                  <p className="text-xs text-slate-400 mt-1">كشف تلقائي لنظام الزائر وتنصيب مباشر بضغطة واحدة.</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">واجهات البرمجة</p>
                  <p className="text-base font-semibold text-white">REST API & OTA Manifests</p>
                  <p className="text-xs text-slate-400 mt-1">مفاتيح وصول مشفرة ونقاط اتصال جاهزة للتكامل.</p>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
