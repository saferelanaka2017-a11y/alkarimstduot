import React, { useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileSpreadsheet,
  FileText,
  Plus,
  Trash2,
} from 'lucide-react';
import { PeriodicReport, ReportPeriod, SoftwareApp } from '../types';

interface ReportsViewProps {
  apps: SoftwareApp[];
  reports: PeriodicReport[];
  onGenerateReport: (app: SoftwareApp, period: ReportPeriod) => Promise<void>;
  onDeleteReport: (reportId: string) => Promise<void>;
}

const PERIOD_LABELS: Record<ReportPeriod, string> = {
  daily: 'تقرير يومي',
  weekly: 'تقرير أسبوعي',
  monthly: 'تقرير شهري',
};

export const ReportsView: React.FC<ReportsViewProps> = ({
  apps,
  reports,
  onGenerateReport,
  onDeleteReport,
}) => {
  const [selectedAppId, setSelectedAppId] = useState(apps[0]?.id || '');
  const [period, setPeriod] = useState<ReportPeriod>('weekly');
  const [generating, setGenerating] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    const targetApp = apps.find((a) => a.id === selectedAppId) || apps[0];
    if (!targetApp) return;
    setGenerating(true);
    try {
      await onGenerateReport(targetApp, period);
    } finally {
      setGenerating(false);
    }
  };

  const exportAllCsv = () => {
    const headers = [
      'اسم التطبيق',
      'الفترة',
      'إجمالي التحميلات',
      'المستخدمون النشطون',
      'نسبة التحديث التلقائي %',
      'معدل الاستقرار %',
      'الملخص',
    ];
    const rows = reports.map((r) => [
      `"${r.appName.replace(/"/g, '""')}"`,
      PERIOD_LABELS[r.period],
      r.totalDownloads,
      r.activeUsers,
      r.autoUpdateRate,
      r.crashFreeRate,
      `"${r.summary.replace(/"/g, '""')}"`,
    ]);
    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `alkarim-reports-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const exportSingleJson = (rep: PeriodicReport) => {
    const blob = new Blob([JSON.stringify(rep, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `alkarim-report-${rep.id}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Report Generator Bar */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              إصدار التقارير الدورية الدقيقة للأداء
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              أنشئ تقارير دورية موثقة لكل تطبيق تتابع معدلات التحميل، التحديث الفوري، واستقرار التشغيل.
            </p>
          </div>

          <form onSubmit={handleGenerate} className="flex flex-wrap items-center gap-3">
            <select
              value={selectedAppId || apps[0]?.id || ''}
              onChange={(e) => setSelectedAppId(e.target.value)}
              className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200"
            >
              {apps.map((app) => (
                <option key={app.id} value={app.id}>{app.name}</option>
              ))}
            </select>

            <select
              value={period}
              onChange={(e) => setPeriod(e.target.value as ReportPeriod)}
              className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200"
            >
              <option value="daily">يومي</option>
              <option value="weekly">أسبوعي</option>
              <option value="monthly">شهري</option>
            </select>

            <button
              type="submit"
              disabled={generating || apps.length === 0}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-medium whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              {generating ? 'جاري التوليد...' : 'توليد تقرير دوري'}
            </button>

            {reports.length > 0 && (
              <button
                type="button"
                onClick={exportAllCsv}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                تصدير CSV
              </button>
            )}
          </form>
        </div>
      </section>

      {/* Reports Archive */}
      <section className="space-y-3">
        {reports.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-10 text-center">
            <FileText className="w-8 h-8 text-slate-400 mx-auto mb-3" />
            <p className="text-sm font-medium text-slate-900 dark:text-white">
              لا توجد تقارير محفوظة بعد
            </p>
            <p className="text-xs text-slate-500 mt-1">
              اختر تطبيقاً واضغط "توليد تقرير دوري" لحفظ أول تقرير أداء في قاعدة البيانات.
            </p>
          </div>
        ) : (
          reports.map((rep) => (
            <div
              key={rep.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
            >
              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="text-sm font-bold text-slate-900 dark:text-white">{rep.appName}</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                    {PERIOD_LABELS[rep.period]}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1 text-slate-500">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    استقرار {rep.crashFreeRate}%
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-3xl">
                  {rep.summary}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-5 shrink-0">
                <div className="flex items-center gap-5 text-xs font-mono tabular-nums">
                  <div>
                    <div className="text-slate-400 text-[11px]">التحميلات</div>
                    <div className="font-bold text-slate-900 dark:text-white">
                      {rep.totalDownloads.toLocaleString('en-US')}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-[11px]">النشطون</div>
                    <div className="font-bold text-slate-900 dark:text-white">
                      {rep.activeUsers.toLocaleString('en-US')}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-[11px]">التحديث التلقائي</div>
                    <div className="font-bold text-emerald-700 dark:text-emerald-400">
                      {rep.autoUpdateRate}%
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => exportSingleJson(rep)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200"
                  >
                    <Download className="w-3.5 h-3.5" />
                    JSON
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteReport(rep.id)}
                    className="p-1.5 text-red-600 hover:text-red-700 dark:text-red-400"
                    aria-label="حذف التقرير"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </section>
    </div>
  );
};
