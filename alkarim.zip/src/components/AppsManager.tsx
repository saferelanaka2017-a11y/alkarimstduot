import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  BookOpen,
  CalendarClock,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  Copy,
  Cpu,
  Download,
  ExternalLink,
  FileArchive,
  Laptop,
  Plus,
  RefreshCw,
  Search,
  Send,
  Settings2,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  AppCategory,
  AppRelease,
  AppVisibility,
  CATEGORY_LABELS,
  CHANNEL_LABELS,
  CompatibilityCheckResult,
  CompatibilityReportRecord,
  OS_LABELS,
  ReleaseChannel,
  SoftwareApp,
  TargetOS,
} from '../types';
import { auth } from '../firebase';
import {
  DownloadCancelledError,
  downloadPackage,
  type DownloadProgressState,
} from '../lib/chunkedDownload';
import {
  UploadCancelledError,
  uploadFileInChunks,
  type UploadProgressState,
} from '../lib/chunkedUpload';
import { CompatibilityReportPanel } from './CompatibilityReportPanel';

interface AppsManagerProps {
  apps: SoftwareApp[];
  releasesByApp: Record<string, AppRelease[]>;
  compatReportsByApp: Record<string, CompatibilityReportRecord[]>;
  selectedAppId: string | null;
  onSelectApp: (appId: string) => void;
  onCreateApp: (payload: {
    name: string;
    slug: string;
    description: string;
    category: AppCategory;
    version: string;
    channel: ReleaseChannel;
    autoUpdate: boolean;
    mandatoryUpdate: boolean;
    supportedOS: TargetOS[];
    visibility: AppVisibility;
    fileInfo: {
      fileName: string;
      fileSizeBytes: number;
      sha256: string;
      downloadUrl: string;
      persistentFile?: File;
    };
    releaseNotes: string;
    primaryTargetOS?: TargetOS;
    compatibilityReport?: CompatibilityCheckResult | null;
  }) => Promise<void>;
  onPublishUpdate: (payload: {
    app: SoftwareApp;
    version: string;
    channel: ReleaseChannel;
    targetOS: TargetOS;
    mandatory: boolean;
    releaseNotes: string;
    fileInfo: {
      fileName: string;
      fileSizeBytes: number;
      sha256: string;
      downloadUrl: string;
      persistentFile?: File;
    };
    compatibilityReport?: CompatibilityCheckResult | null;
    publishMode?: 'immediate' | 'scheduled';
    scheduledFor?: string;
  }) => Promise<void>;
  onPublishScheduledNow: (app: SoftwareApp, release: AppRelease) => Promise<void>;
  onDeleteRelease: (appId: string, releaseId: string) => Promise<void>;
  onToggleAutoUpdate: (app: SoftwareApp) => Promise<void>;
  onDeleteApp: (appId: string) => Promise<void>;
  onDeleteAllApps?: () => Promise<void>;
  onOpenInPortal: (appId: string) => void;
  openCreateModalTrigger: number;
}

function toLocalDatetimeInputValue(date: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function getDefaultScheduledDatetime(hoursAhead = 1): string {
  return toLocalDatetimeInputValue(new Date(Date.now() + hoursAhead * 60 * 60 * 1000));
}

function formatScheduledDateTimeArabic(isoOrLocal: string): string {
  const ms = Date.parse(isoOrLocal);
  if (!Number.isFinite(ms)) return isoOrLocal;
  return new Date(ms).toLocaleString('ar-EG', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
}

function formatTransferSpeed(bytesPerSec: number): string {
  if (!bytesPerSec || bytesPerSec <= 0) return '—';
  if (bytesPerSec >= 1024 * 1024) {
    return `${(bytesPerSec / (1024 * 1024)).toFixed(1)} MB/s`;
  }
  return `${Math.round(bytesPerSec / 1024)} KB/s`;
}

function formatEta(seconds: number | null): string {
  if (seconds === null || !Number.isFinite(seconds) || seconds < 0) return '';
  if (seconds < 60) return `متبقي ~${seconds} ثانية`;
  const mins = Math.floor(seconds / 60);
  const rem = seconds % 60;
  return `متبقي ~${mins} د ${rem} ث`;
}

function semverCompare(a: string, b: string): number {
  const pa = a.replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
  const pb = b.replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length, 3);
  for (let i = 0; i < len; i++) {
    const va = pa[i] || 0;
    const vb = pb[i] || 0;
    if (va > vb) return 1;
    if (va < vb) return -1;
  }
  return 0;
}

function getReleaseTimeMs(createdAt: unknown): number {
  if (!createdAt) return 0;
  if (typeof createdAt === 'object' && createdAt !== null) {
    const ts = createdAt as { toMillis?: () => number; seconds?: number };
    if (typeof ts.toMillis === 'function') return ts.toMillis();
    if (typeof ts.seconds === 'number') return ts.seconds * 1000;
  }
  if (typeof createdAt === 'string') {
    const ms = Date.parse(createdAt);
    return Number.isFinite(ms) ? ms : 0;
  }
  return 0;
}

function inferOSFromFile(file: File): TargetOS | null {
  const name = file.name.toLowerCase();
  if (name.endsWith('.apk') || name.endsWith('.aab')) return 'android';
  if (name.endsWith('.ipa')) return 'ios';
  if (name.endsWith('.exe') || name.endsWith('.msi') || name.endsWith('.ps1')) return 'windows';
  if (name.endsWith('.dmg') || name.endsWith('.pkg')) return 'macos';
  if (
    name.endsWith('.appimage') ||
    name.endsWith('.deb') ||
    name.endsWith('.rpm') ||
    name.endsWith('.tar.gz') ||
    name.endsWith('.tgz')
  ) {
    return 'linux';
  }
  if (name.endsWith('.sh')) return 'cli';
  return null;
}

async function safeJsonFetch<T>(
  url: string,
  init: RequestInit,
  timeoutMs = 45000
): Promise<{ ok: boolean; status: number; data: T | null; rawError: string }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const resp = await fetch(url, { ...init, signal: controller.signal });
    const text = await resp.text();
    let parsed: T | null = null;
    if (text) {
      try {
        parsed = JSON.parse(text) as T;
      } catch {
        parsed = null;
      }
    }
    if (!resp.ok) {
      const errFromJson =
        parsed && typeof parsed === 'object' && 'error' in parsed && typeof (parsed as { error?: unknown }).error === 'string'
          ? (parsed as { error: string }).error
          : '';
      return {
        ok: false,
        status: resp.status,
        data: parsed,
        rawError: errFromJson || `فشل الطلب من الخادم (HTTP ${resp.status})`,
      };
    }
    return { ok: true, status: resp.status, data: parsed, rawError: '' };
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      return {
        ok: false,
        status: 408,
        data: null,
        rawError: 'انتهت مهلة الاتصال أثناء رفع الملف. يرجى التحقق من الشبكة والمحاولة مجدداً.',
      };
    }
    return {
      ok: false,
      status: 0,
      data: null,
      rawError: err instanceof Error ? err.message : 'تعذر الاتصال بالخادم',
    };
  } finally {
    clearTimeout(timer);
  }
}

interface SimulatedEndpoint {
  id: string;
  deviceName: string;
  os: TargetOS;
  runningVersion: string;
  status: 'synced' | 'checking' | 'updating';
}

export const AppsManager: React.FC<AppsManagerProps> = ({
  apps,
  releasesByApp,
  compatReportsByApp,
  selectedAppId,
  onSelectApp,
  onCreateApp,
  onPublishUpdate,
  onPublishScheduledNow,
  onDeleteRelease,
  onToggleAutoUpdate,
  onDeleteApp,
  onDeleteAllApps,
  onOpenInPortal,
  openCreateModalTrigger,
}) => {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'all' | AppCategory>('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [updateModalApp, setUpdateModalApp] = useState<SoftwareApp | null>(null);

  // Create App State
  const [appName, setAppName] = useState('');
  const [appSlug, setAppSlug] = useState('');
  const [appDesc, setAppDesc] = useState('');
  const [appCategory, setAppCategory] = useState<AppCategory>('productivity');
  const [appVersion, setAppVersion] = useState('1.0.0');
  const [appChannel, setAppChannel] = useState<ReleaseChannel>('stable');
  const [appAutoUpdate, setAppAutoUpdate] = useState(true);
  const [appMandatory, setAppMandatory] = useState(false);
  const [appVisibility, setAppVisibility] = useState<AppVisibility>('public');
  const [appOS, setAppOS] = useState<TargetOS[]>(['windows', 'macos', 'linux']);
  const [packageTargetOS, setPackageTargetOS] = useState<TargetOS>('windows');
  const [releaseNotes, setReleaseNotes] = useState('الإصدار الأولي مع دعم المزامنة والتحديث التلقائي.');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<UploadProgressState | null>(null);
  const [formError, setFormError] = useState('');
  const uploadAbortRef = useRef<AbortController | null>(null);

  // Publish Update State
  const [updVersion, setUpdVersion] = useState('');
  const [updChannel, setUpdChannel] = useState<ReleaseChannel>('stable');
  const [updOS, setUpdOS] = useState<TargetOS>('windows');
  const [updMandatory, setUpdMandatory] = useState(false);
  const [updNotes, setUpdNotes] = useState('');
  const [updFile, setUpdFile] = useState<File | null>(null);
  const [updPublishMode, setUpdPublishMode] = useState<'immediate' | 'scheduled'>('immediate');
  const [updScheduledFor, setUpdScheduledFor] = useState<string>(() => getDefaultScheduledDatetime(1));
  const [actingReleaseId, setActingReleaseId] = useState<string | null>(null);
  const [confirmDeleteAppId, setConfirmDeleteAppId] = useState<string | null>(null);
  const [deletingAppId, setDeletingAppId] = useState<string | null>(null);
  const [confirmDeleteAll, setConfirmDeleteAll] = useState(false);
  const [deletingAll, setDeletingAll] = useState(false);
  const [deleteError, setDeleteError] = useState('');

  // Release Notes Reading Mode State
  const [readingModeEnabled, setReadingModeEnabled] = useState(false);
  const [expandedNotesIds, setExpandedNotesIds] = useState<Record<string, boolean>>({});
  const [readerRelease, setReaderRelease] = useState<AppRelease | null>(null);
  const [readerFontSize, setReaderFontSize] = useState<'sm' | 'md' | 'lg'>('md');
  const [copiedReaderSha, setCopiedReaderSha] = useState(false);

  // Automatic Pre-Publish Compatibility Testing State
  const [createCompatReport, setCreateCompatReport] = useState<CompatibilityCheckResult | null>(null);
  const [createCompatLoading, setCreateCompatLoading] = useState(false);
  const [createCompatOverride, setCreateCompatOverride] = useState(false);
  const [updCompatReport, setUpdCompatReport] = useState<CompatibilityCheckResult | null>(null);
  const [updCompatLoading, setUpdCompatLoading] = useState(false);
  const [updCompatOverride, setUpdCompatOverride] = useState(false);

  // Connected OTA Endpoints Watcher
  const [endpoints, setEndpoints] = useState<SimulatedEndpoint[]>([]);
  const [downloadingReleaseId, setDownloadingReleaseId] = useState<string | null>(null);
  const [releaseDownloadProgress, setReleaseDownloadProgress] = useState<DownloadProgressState | null>(null);
  const [releaseDownloadError, setReleaseDownloadError] = useState('');
  const releaseDownloadAbortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (openCreateModalTrigger > 0) {
      setShowCreateModal(true);
    }
  }, [openCreateModalTrigger]);

  const activeApp = apps.find((a) => a.id === selectedAppId) || apps[0] || null;
  const activeReleases = useMemo(() => {
    if (!activeApp) return [];
    const list = [...(releasesByApp[activeApp.id] || [])];
    return list.sort((a, b) => {
      const aScheduled = a.status === 'scheduled' ? 1 : 0;
      const bScheduled = b.status === 'scheduled' ? 1 : 0;
      if (aScheduled !== bScheduled) return bScheduled - aScheduled;
      const timeDiff = getReleaseTimeMs(b.createdAt) - getReleaseTimeMs(a.createdAt);
      if (timeDiff !== 0) return timeDiff;
      const verDiff = semverCompare(b.version, a.version);
      if (verDiff !== 0) return verDiff;
      return b.id.localeCompare(a.id);
    });
  }, [activeApp, releasesByApp]);
  const activeCompatReports = activeApp ? compatReportsByApp[activeApp.id] || [] : [];

  const runCompatibilityAnalysis = async (params: {
    file: File | null;
    targetOS: TargetOS;
    version: string;
    autoUpdate: boolean;
  }): Promise<CompatibilityCheckResult | null> => {
    const token = await auth.currentUser?.getIdToken();
    const formData = new FormData();
    formData.append('targetOS', params.targetOS);
    formData.append('version', params.version || '1.0.0');
    formData.append('autoUpdate', String(params.autoUpdate));
    if (params.file) {
      const sliceSize = 65536;
      const headBlob = params.file.slice(0, Math.min(params.file.size, sliceSize));
      formData.append('headerSlice', headBlob, params.file.name);
      if (params.file.size > sliceSize) {
        const tailBlob = params.file.slice(Math.max(0, params.file.size - sliceSize));
        formData.append('tailSlice', tailBlob, 'tail.bin');
      }
      formData.append('originalName', params.file.name);
      formData.append('reportedSizeBytes', String(params.file.size));
    }

    const res = await safeJsonFetch<CompatibilityCheckResult>(
      '/api/packages/compatibility-check',
      {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: formData,
      },
      20000
    );
    if (!res.ok || !res.data) return null;
    return res.data;
  };

  // Auto-run compatibility test when Create App modal inputs change
  useEffect(() => {
    if (!showCreateModal) return;
    let cancelled = false;
    setCreateCompatOverride(false);
    const timer = setTimeout(async () => {
      setCreateCompatLoading(true);
      try {
        const res = await runCompatibilityAnalysis({
          file: selectedFile,
          targetOS: packageTargetOS,
          version: appVersion,
          autoUpdate: appAutoUpdate,
        });
        if (!cancelled) setCreateCompatReport(res);
      } finally {
        if (!cancelled) setCreateCompatLoading(false);
      }
    }, 220);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [showCreateModal, selectedFile, packageTargetOS, appVersion, appAutoUpdate]);

  // Auto-run compatibility test when Publish Update modal inputs change
  useEffect(() => {
    if (!updateModalApp) return;
    let cancelled = false;
    setUpdCompatOverride(false);
    const timer = setTimeout(async () => {
      setUpdCompatLoading(true);
      try {
        const res = await runCompatibilityAnalysis({
          file: updFile,
          targetOS: updOS,
          version: updVersion,
          autoUpdate: updateModalApp.autoUpdate,
        });
        if (!cancelled) setUpdCompatReport(res);
      } finally {
        if (!cancelled) setUpdCompatLoading(false);
      }
    }, 220);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [updateModalApp, updFile, updOS, updVersion]);

  // Initialize and auto-sync connected endpoints whenever activeApp.latestVersion updates via Firestore!
  useEffect(() => {
    if (!activeApp) return;
    setEndpoints((prev) => {
      if (prev.length === 0) {
        return [
          { id: 'ep-1', deviceName: 'محطة عمل الرياض - Win11', os: activeApp.supportedOS[0] || 'windows', runningVersion: activeApp.latestVersion, status: 'synced' },
          { id: 'ep-2', deviceName: 'جهاز تطوير دبي - MacBook Pro', os: activeApp.supportedOS[1] || 'macos', runningVersion: activeApp.latestVersion, status: 'synced' },
          { id: 'ep-3', deviceName: 'خادم الإنتاج - Ubuntu 24.04', os: activeApp.supportedOS[2] || 'linux', runningVersion: activeApp.latestVersion, status: 'synced' },
          { id: 'ep-4', deviceName: 'تطبيق ميداني - Android 15', os: activeApp.supportedOS[3] || 'android', runningVersion: activeApp.latestVersion, status: 'synced' },
        ];
      }
      const needsUpdate = prev.some((ep) => ep.runningVersion !== activeApp.latestVersion);
      if (!needsUpdate || !activeApp.autoUpdate) return prev;

      return prev.map((ep) => ({
        ...ep,
        status: 'updating',
      }));
    });
  }, [activeApp?.id, activeApp?.latestVersion, activeApp?.autoUpdate]);

  // Automatically complete OTA transition when endpoints enter 'updating'
  useEffect(() => {
    if (!activeApp || !activeApp.autoUpdate) return;
    const hasUpdating = endpoints.some((ep) => ep.status === 'updating');
    if (!hasUpdating) return;

    const timer = setTimeout(() => {
      setEndpoints((prev) =>
        prev.map((ep) => ({
          ...ep,
          runningVersion: activeApp.latestVersion,
          status: 'synced',
        }))
      );
    }, 1100);
    return () => clearTimeout(timer);
  }, [endpoints, activeApp]);

  const filteredApps = apps.filter((a) => {
    if (categoryFilter !== 'all' && a.category !== categoryFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        a.name.toLowerCase().includes(q) ||
        a.slug.toLowerCase().includes(q) ||
        a.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCancelUpload = () => {
    uploadAbortRef.current?.abort();
  };

  const handleDownloadRelease = async (rel: AppRelease) => {
    if (downloadingReleaseId) return;
    const abortController = new AbortController();
    releaseDownloadAbortRef.current = abortController;
    setDownloadingReleaseId(rel.id);
    setReleaseDownloadError('');
    setReleaseDownloadProgress(null);

    try {
      await downloadPackage({
        downloadUrl: rel.downloadUrl,
        fileName: rel.fileName || `release-v${rel.version}`,
        appId: activeApp?.id,
        targetOS: rel.targetOS,
        getToken: async () => auth.currentUser?.getIdToken(),
        onProgress: (state) => setReleaseDownloadProgress(state),
        signal: abortController.signal,
      });
    } catch (err) {
      if (err instanceof DownloadCancelledError) {
        setReleaseDownloadError('تم إلغاء تحميل الحزمة.');
      } else {
        setReleaseDownloadError(
          err instanceof Error ? err.message : 'تعذر تحميل الحزمة من الخادم.'
        );
      }
    } finally {
      releaseDownloadAbortRef.current = null;
      setDownloadingReleaseId(null);
      setReleaseDownloadProgress(null);
    }
  };

  const uploadBinaryToServer = async (
    file: File | null,
    fallbackSlug: string,
    version: string,
    targetOS: TargetOS
  ) => {
    if (!file) {
      const ext = targetOS === 'windows' ? 'exe' : targetOS === 'macos' ? 'dmg' : targetOS === 'android' ? 'apk' : 'AppImage';
      return {
        fileName: `${fallbackSlug}-v${version}-${targetOS}.${ext}`,
        fileSizeBytes: 18420000,
        sha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        downloadUrl: `/api/packages/download/pkg-${fallbackSlug}?os=${targetOS}&version=${encodeURIComponent(version)}`,
      };
    }

    const abortController = new AbortController();
    uploadAbortRef.current = abortController;
    try {
      const result = await uploadFileInChunks({
        file,
        getToken: async () => auth.currentUser?.getIdToken(),
        onProgress: (state) => setUploadProgress(state),
        signal: abortController.signal,
      });
      return {
        fileName: result.fileName,
        fileSizeBytes: result.fileSizeBytes,
        sha256: result.sha256,
        downloadUrl: result.downloadUrl,
        persistentFile: file.size > 0 && file.size <= 2048000 ? file : undefined,
      };
    } finally {
      uploadAbortRef.current = null;
    }
  };

  const handleToggleOSSelection = (os: TargetOS) => {
    setAppOS((prev) => {
      const next = prev.includes(os)
        ? prev.length > 1
          ? prev.filter((item) => item !== os)
          : prev
        : [...prev, os];
      if (!next.includes(packageTargetOS)) {
        setPackageTargetOS(next[0]);
      }
      return next;
    });
  };

  const handleCreateFileChange = (file: File | null) => {
    setSelectedFile(file);
    if (file) {
      const detected = inferOSFromFile(file);
      if (detected) {
        setPackageTargetOS(detected);
        setAppOS((prev) => (prev.includes(detected) ? prev : [detected, ...prev]));
      }
    }
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    const cleanSlug = (appSlug || appName)
      .toLowerCase()
      .replace(/[^a-z0-9-]+/g, '-')
      .replace(/^-|-$/g, '') || `app-${Date.now().toString(36)}`;

    if (!appName.trim()) {
      setFormError('يرجى إدخال اسم البرنامج.');
      return;
    }
    if (createCompatReport?.overallStatus === 'failed' && !createCompatOverride) {
      setFormError('فشل اختبار التوافق التلقائي مع النظام المحدد. يرجى تصحيح الملف أو تأكيد المتابعة.');
      return;
    }
    setUploading(true);
    setUploadProgress(null);
    try {
      const fileInfo = await uploadBinaryToServer(
        selectedFile,
        cleanSlug,
        appVersion.trim(),
        packageTargetOS
      );
      await onCreateApp({
        name: appName.trim(),
        slug: cleanSlug.slice(0, 48),
        description: appDesc.trim() || 'تطبيق مدار سحابياً عبر منصة AlKarim.',
        category: appCategory,
        version: appVersion.trim() || '1.0.0',
        channel: appChannel,
        autoUpdate: appAutoUpdate,
        mandatoryUpdate: appMandatory,
        supportedOS: appOS,
        visibility: appVisibility,
        fileInfo,
        releaseNotes: releaseNotes.trim(),
        primaryTargetOS: packageTargetOS,
        compatibilityReport: createCompatReport,
      });
      setShowCreateModal(false);
      setAppName('');
      setAppSlug('');
      setAppDesc('');
      setSelectedFile(null);
      setCreateCompatReport(null);
    } catch (err) {
      if (err instanceof UploadCancelledError) {
        setFormError('تم إلغاء عملية الرفع. يمكنك اختيار ملف آخر أو إعادة المحاولة في أي وقت.');
      } else {
        setFormError(err instanceof Error ? err.message : 'تعذر نشر التطبيق بسبب خطأ غير متوقع.');
      }
    } finally {
      setUploading(false);
      setUploadProgress(null);
    }
  };

  const openUpdateModal = (app: SoftwareApp) => {
    const parts = app.latestVersion.split('.').map((n) => parseInt(n, 10) || 0);
    const nextPatch = `${parts[0] || 1}.${parts[1] || 0}.${(parts[2] || 0) + 1}`;
    setUpdVersion(nextPatch);
    setUpdChannel(app.channel);
    setUpdOS(app.supportedOS[0] || 'windows');
    setUpdMandatory(app.mandatoryUpdate);
    setUpdNotes('تحسينات في الأداء وإصلاحات أمنية مع مزامنة التحديث الفوري.');
    setUpdFile(null);
    setUpdPublishMode('immediate');
    setUpdScheduledFor(getDefaultScheduledDatetime(1));
    setFormError('');
    setUpdateModalApp(app);
  };

  const handlePublishUpdateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!updateModalApp) return;
    setFormError('');
    if (updCompatReport?.overallStatus === 'failed' && !updCompatOverride) {
      setFormError('فشل اختبار التوافق التلقائي لهذا الإصدار. يرجى مراجعة التقرير قبل النشر.');
      return;
    }

    let scheduledIso: string | undefined;
    if (updPublishMode === 'scheduled') {
      const parsedMs = Date.parse(updScheduledFor);
      if (!updScheduledFor || !Number.isFinite(parsedMs)) {
        setFormError('يرجى تحديد تاريخ ووقت صالحين لجدولة الإصدار.');
        return;
      }
      if (parsedMs <= Date.now() + 30_000) {
        setFormError('يجب أن يكون موعد الجدولة في المستقبل (بعد الوقت الحالي بدقيقة على الأقل).');
        return;
      }
      scheduledIso = new Date(parsedMs).toISOString();
    }

    setUploading(true);
    setUploadProgress(null);
    try {
      const fileInfo = await uploadBinaryToServer(
        updFile,
        updateModalApp.slug,
        updVersion.trim(),
        updOS
      );
      await onPublishUpdate({
        app: updateModalApp,
        version: updVersion.trim(),
        channel: updChannel,
        targetOS: updOS,
        mandatory: updMandatory,
        releaseNotes: updNotes.trim(),
        fileInfo,
        compatibilityReport: updCompatReport,
        publishMode: updPublishMode,
        scheduledFor: scheduledIso,
      });
      setUpdateModalApp(null);
      setUpdCompatReport(null);
    } catch (err) {
      if (err instanceof UploadCancelledError) {
        setFormError('تم إلغاء رفع ملف التحديث. يمكنك إعادة المحاولة في أي وقت.');
      } else {
        setFormError(err instanceof Error ? err.message : 'تعذر نشر التحديث الجديد بسبب خطأ غير متوقع.');
      }
    } finally {
      setUploading(false);
      setUploadProgress(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث عن برنامج أو معرف slug..."
              className="w-full pr-9 pl-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
            />
          </div>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value as 'all' | AppCategory)}
            aria-label="تصفية حسب التصنيف"
            className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200"
          >
            <option value="all">جميع التصنيفات</option>
            {(Object.keys(CATEGORY_LABELS) as AppCategory[]).map((cat) => (
              <option key={cat} value={cat}>
                {CATEGORY_LABELS[cat]}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {apps.length > 0 && onDeleteAllApps && (
            confirmDeleteAll ? (
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/40 text-xs">
                <span className="text-red-700 dark:text-red-300 font-medium">حذف الكل؟</span>
                <button
                  type="button"
                  disabled={deletingAll}
                  onClick={async () => {
                    setDeletingAll(true);
                    setDeleteError('');
                    try {
                      await onDeleteAllApps();
                      setConfirmDeleteAll(false);
                    } catch (err) {
                      setDeleteError(
                        err instanceof Error
                          ? `تعذر حذف جميع البرامج: ${err.message}`
                          : 'تعذر حذف جميع البرامج من قاعدة البيانات.'
                      );
                    } finally {
                      setDeletingAll(false);
                    }
                  }}
                  className="px-2 py-0.5 rounded bg-red-600 hover:bg-red-700 text-white font-medium disabled:opacity-50"
                >
                  {deletingAll ? 'جاري الحذف...' : 'تأكيد'}
                </button>
                <button
                  type="button"
                  disabled={deletingAll}
                  onClick={() => setConfirmDeleteAll(false)}
                  className="px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300"
                >
                  إلغاء
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setDeleteError('');
                  setConfirmDeleteAll(true);
                }}
                className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-lg border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 text-xs font-medium transition-colors whitespace-nowrap"
              >
                <Trash2 className="w-3.5 h-3.5" />
                حذف جميع البرامج
              </button>
            )
          )}
          <button
            type="button"
            onClick={() => {
              setFormError('');
              setShowCreateModal(true);
            }}
            className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            رفع برنامج جديد
          </button>
        </div>
      </div>

      {deleteError && (
        <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span className="break-words">{deleteError}</span>
          </div>
          <button
            type="button"
            onClick={() => setDeleteError('')}
            className="text-red-600 dark:text-red-300 hover:underline shrink-0"
          >
            إغلاق
          </button>
        </div>
      )}

      {/* Split Workspace: Apps Catalog + Selected App OTA & Releases */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Apps List */}
        <div className="lg:col-span-5 space-y-3">
          {filteredApps.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center">
              <FileArchive className="w-8 h-8 text-slate-400 mx-auto mb-3" />
              <p className="text-sm font-medium text-slate-900 dark:text-white mb-1">
                لا توجد برامج مطابقة
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                ارفع أول برنامج الآن لتفعيل التحديث الفوري وبوابة التحميل المباشر.
              </p>
              <button
                type="button"
                onClick={() => setShowCreateModal(true)}
                className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-xs font-medium"
              >
                رفع برنامج جديد
              </button>
            </div>
          ) : (
            filteredApps.map((app) => {
              const isSelected = activeApp?.id === app.id;
              const isConfirming = confirmDeleteAppId === app.id;
              const isDeletingThis = deletingAppId === app.id;
              return (
                <div
                  key={app.id}
                  onClick={() => onSelectApp(app.id)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') onSelectApp(app.id);
                  }}
                  className={`p-4 rounded-xl border transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-white dark:bg-slate-900 border-emerald-600 dark:border-emerald-500'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <img
                        src={app.iconUrl || '/src/assets/images/app_icon_cloudsync_1795296596170.jpg'}
                        alt={app.name}
                        referrerPolicy="no-referrer"
                        className="w-11 h-11 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                      />
                      <div className="min-w-0">
                        <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {app.name}
                        </h3>
                        <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 flex flex-wrap items-center gap-1.5">
                          <span className="font-mono text-emerald-700 dark:text-emerald-400">v{app.latestVersion}</span>
                          <span aria-hidden="true">·</span>
                          <span>{CATEGORY_LABELS[app.category]}</span>
                          <span aria-hidden="true">·</span>
                          <span>{app.visibility === 'public' ? 'متاح للعامة' : 'خاص'}</span>
                        </div>
                      </div>
                    </div>

                    <div
                      className="shrink-0 flex items-center gap-1.5"
                      onClick={(e) => e.stopPropagation()}
                      onKeyDown={(e) => e.stopPropagation()}
                    >
                      {isConfirming ? (
                        <>
                          <button
                            type="button"
                            disabled={isDeletingThis}
                            onClick={async () => {
                              setDeletingAppId(app.id);
                              setDeleteError('');
                              try {
                                await onDeleteApp(app.id);
                                setConfirmDeleteAppId(null);
                              } catch (err) {
                                setDeleteError(
                                  err instanceof Error
                                    ? `تعذر حذف البرنامج: ${err.message}`
                                    : 'تعذر حذف البرنامج من قاعدة البيانات.'
                                );
                              } finally {
                                setDeletingAppId(null);
                              }
                            }}
                            className="px-2 py-1 rounded-md bg-red-600 hover:bg-red-700 text-white text-[11px] font-medium disabled:opacity-50"
                          >
                            {isDeletingThis ? 'جاري...' : 'تأكيد الحذف'}
                          </button>
                          <button
                            type="button"
                            disabled={isDeletingThis}
                            onClick={() => setConfirmDeleteAppId(null)}
                            className="px-2 py-1 rounded-md border border-slate-200 dark:border-slate-700 text-[11px] text-slate-600 dark:text-slate-300"
                          >
                            إلغاء
                          </button>
                        </>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            setDeleteError('');
                            setConfirmDeleteAppId(app.id);
                          }}
                          aria-label={`حذف ${app.name}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-red-200 dark:border-red-900/70 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 text-[11px] font-medium transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          حذف
                        </button>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-3 line-clamp-2 leading-relaxed">
                    {app.description}
                  </p>

                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                    <span>{app.downloadsCount.toLocaleString('en-US')} تحميل</span>
                    <span>{app.activeUsersCount.toLocaleString('en-US')} نشط</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Selected App Details & Live OTA Auto-Update Panel */}
        <div className="lg:col-span-7">
          {activeApp ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-6">
              {/* App Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3.5">
                  <img
                    src={activeApp.iconUrl || '/src/assets/images/app_icon_cloudsync_1795296596170.jpg'}
                    alt={activeApp.name}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
                  />
                  <div>
                    <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                      {activeApp.name}
                    </h2>
                    <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5">
                      <span className="font-mono">/{activeApp.slug}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-emerald-700 dark:text-emerald-400">v{activeApp.latestVersion}</span>
                      <span aria-hidden="true">·</span>
                      <span>{CHANNEL_LABELS[activeApp.channel]}</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onOpenInPortal(activeApp.id)}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    بوابة التحميل
                  </button>
                  <button
                    type="button"
                    onClick={() => openUpdateModal(activeApp)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium whitespace-nowrap"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    دفع تحديث فوري
                  </button>
                  {confirmDeleteAppId === activeApp.id ? (
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        disabled={deletingAppId === activeApp.id}
                        onClick={async () => {
                          setDeletingAppId(activeApp.id);
                          setDeleteError('');
                          try {
                            await onDeleteApp(activeApp.id);
                            setConfirmDeleteAppId(null);
                          } catch (err) {
                            setDeleteError(
                              err instanceof Error
                                ? `تعذر حذف البرنامج: ${err.message}`
                                : 'تعذر حذف البرنامج من قاعدة البيانات.'
                            );
                          } finally {
                            setDeletingAppId(null);
                          }
                        }}
                        className="px-3 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-medium disabled:opacity-50 whitespace-nowrap"
                      >
                        {deletingAppId === activeApp.id ? 'جاري الحذف...' : 'تأكيد الحذف'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteAppId(null)}
                        className="px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300"
                      >
                        إلغاء
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setDeleteError('');
                        setConfirmDeleteAppId(activeApp.id);
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 text-xs font-medium whitespace-nowrap"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      حذف البرنامج
                    </button>
                  )}
                </div>
              </div>

              {/* Auto-Update Policy Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">
                      التحديث التلقائي الفوري (OTA)
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      يحدّث التطبيق لدى جميع المستخدمين فور نشر أي إصدار
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onToggleAutoUpdate(activeApp)}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                      activeApp.autoUpdate
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {activeApp.autoUpdate ? 'مفعّل' : 'متوقف'}
                  </button>
                </div>

                <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">
                      الأنظمة المتوافقة
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {activeApp.supportedOS.map((os) => OS_LABELS[os].label).join(' · ')}
                    </div>
                  </div>
                  <Cpu className="w-4 h-4 text-slate-400 shrink-0" />
                </div>
              </div>

              {/* Connected Endpoints Live Sync Monitor */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    مراقبة الأجهزة المتصلة والتحديث الفوري
                  </h3>
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    متصل لحظياً بالإصدار <span className="font-mono">v{activeApp.latestVersion}</span>
                  </span>
                </div>
                <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
                  {endpoints.map((ep) => (
                    <div key={ep.id} className="px-4 py-2.5 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2.5">
                        <Laptop className="w-4 h-4 text-slate-400 shrink-0" />
                        <span className="font-medium text-slate-800 dark:text-slate-200">{ep.deviceName}</span>
                        <span className="text-slate-400 font-mono">{OS_LABELS[ep.os].label}</span>
                      </div>
                      <div className="flex items-center gap-3 font-mono tabular-nums">
                        <span className="text-slate-600 dark:text-slate-300">v{ep.runningVersion}</span>
                        {ep.status === 'updating' ? (
                          <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400">
                            <RefreshCw className="w-3 h-3 animate-spin" />
                            جاري التحديث التلقائي
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            محدّث
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Release History */}
              <div>
                <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    سجل الإصدارات والحزم المرفوعة ({activeReleases.length})
                  </h3>
                  <div className="flex flex-wrap items-center gap-3">
                    {activeReleases.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setReadingModeEnabled((v) => !v)}
                        aria-pressed={readingModeEnabled}
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
                          readingModeEnabled
                            ? 'bg-emerald-600 border-emerald-600 text-white'
                            : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                        }`}
                      >
                        <BookOpen className="w-3.5 h-3.5" />
                        {readingModeEnabled ? 'إيقاف وضع القراءة' : 'وضع القراءة المريح'}
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setDeleteError('');
                        setConfirmDeleteAppId(activeApp.id);
                      }}
                      className="inline-flex items-center gap-1 text-xs text-red-600 hover:text-red-700 dark:text-red-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      حذف التطبيق
                    </button>
                  </div>
                </div>

                {releaseDownloadError && (
                  <div className="mb-3 p-3 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-start gap-2 min-w-0 flex-1">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{releaseDownloadError}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {(releaseDownloadError.includes('غير متوفر') ||
                        releaseDownloadError.includes('لم يتم العثور')) && (
                        <button
                          type="button"
                          onClick={() => {
                            setReleaseDownloadError('');
                            openUpdateModal(activeApp);
                          }}
                          className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white font-medium"
                        >
                          رفع ملف التحديث مجدداً
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setReleaseDownloadError('')}
                        className="text-red-600 dark:text-red-300 hover:underline"
                      >
                        إغلاق
                      </button>
                    </div>
                  </div>
                )}

                {activeReleases.length === 0 ? (
                  <p className="text-xs text-slate-500 dark:text-slate-400 py-4 border border-dashed border-slate-200 dark:border-slate-800 rounded-lg text-center">
                    لا توجد حزم مسجلة بعد. اضغط "دفع تحديث فوري" لرفع حزمة جديدة.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {activeReleases.map((rel) => {
                      const isThisDownloading = downloadingReleaseId === rel.id;
                      const isScheduled = rel.status === 'scheduled';
                      const isActing = actingReleaseId === rel.id;
                      const notesText = (rel.releaseNotes || '').trim();
                      const isLongNotes =
                        notesText.length > 160 || notesText.split(/\r?\n/).length > 3;
                      const isNotesExpanded =
                        readingModeEnabled || Boolean(expandedNotesIds[rel.id]);
                      return (
                        <div
                          key={rel.id}
                          className={`p-4 rounded-xl border space-y-3 transition-colors ${
                            isScheduled
                              ? 'border-amber-200 dark:border-amber-800/80 bg-amber-50/50 dark:bg-amber-950/25'
                              : readingModeEnabled
                                ? 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900/95'
                                : 'border-slate-200 dark:border-slate-800'
                          }`}
                        >
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                            <div className="min-w-0 flex-1 space-y-2">
                              <div className="flex flex-wrap items-center gap-2 text-xs">
                                <span className="font-mono font-bold text-slate-900 dark:text-white">v{rel.version}</span>
                                <span aria-hidden="true" className="text-slate-400 dark:text-slate-500">·</span>
                                <span className="text-slate-700 dark:text-slate-200 font-medium">{OS_LABELS[rel.targetOS].label}</span>
                                <span aria-hidden="true" className="text-slate-400 dark:text-slate-500">·</span>
                                <span className="font-mono text-slate-600 dark:text-slate-300">{(rel.fileSizeBytes / (1024 * 1024)).toFixed(1)} MB</span>
                                {isScheduled && (
                                  <>
                                    <span aria-hidden="true" className="text-slate-400 dark:text-slate-500">·</span>
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200 font-medium">
                                      <CalendarClock className="w-3 h-3" />
                                      مجدول للنشر
                                    </span>
                                  </>
                                )}
                                {rel.mandatory && (
                                  <>
                                    <span aria-hidden="true" className="text-slate-400 dark:text-slate-500">·</span>
                                    <span className="text-amber-700 dark:text-amber-300 font-medium">تحديث إلزامي</span>
                                  </>
                                )}
                              </div>
                              {isScheduled && rel.scheduledFor && (
                                <p className="text-[11px] text-amber-800 dark:text-amber-200 font-medium flex items-center gap-1.5">
                                  <Clock className="w-3 h-3 shrink-0" />
                                  موعد النشر التلقائي: {formatScheduledDateTimeArabic(rel.scheduledFor)}
                                </p>
                              )}

                              {/* High-Contrast Release Notes Surface */}
                              <div
                                className={`rounded-lg border transition-colors ${
                                  readingModeEnabled
                                    ? 'p-4 bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-700/90'
                                    : 'px-3.5 py-2.5 bg-slate-50/90 dark:bg-slate-950/85 border-slate-200/80 dark:border-slate-700/80'
                                }`}
                              >
                                <div className="flex items-center justify-between gap-2 mb-1.5">
                                  <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-300">
                                    ملاحظات الإصدار (Release Notes)
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setCopiedReaderSha(false);
                                      setReaderRelease(rel);
                                    }}
                                    className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 dark:text-emerald-300 hover:underline shrink-0"
                                  >
                                    <BookOpen className="w-3 h-3" />
                                    فتح في وضع القراءة
                                  </button>
                                </div>
                                <p
                                  className={`whitespace-pre-line break-words text-slate-800 dark:text-slate-100 ${
                                    readingModeEnabled
                                      ? 'text-sm leading-8 max-w-prose'
                                      : 'text-[13px] leading-7'
                                  } ${!isNotesExpanded && isLongNotes ? 'line-clamp-3' : ''}`}
                                >
                                  {notesText || 'لا توجد ملاحظات مسجلة لهذا الإصدار.'}
                                </p>
                                {!readingModeEnabled && isLongNotes && (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setExpandedNotesIds((prev) => ({
                                        ...prev,
                                        [rel.id]: !prev[rel.id],
                                      }))
                                    }
                                    className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-300 hover:underline"
                                  >
                                    {isNotesExpanded ? (
                                      <>
                                        <ChevronUp className="w-3.5 h-3.5" />
                                        طي الملاحظات
                                      </>
                                    ) : (
                                      <>
                                        <ChevronDown className="w-3.5 h-3.5" />
                                        عرض كامل الملاحظات
                                      </>
                                    )}
                                  </button>
                                )}
                              </div>

                              <p className="text-[11px] font-mono text-slate-500 dark:text-slate-300 truncate max-w-md">
                                SHA-256: {rel.sha256}
                              </p>
                            </div>
                            <div className="flex flex-wrap items-center gap-2 shrink-0">
                              {isScheduled && (
                                <>
                                  <button
                                    type="button"
                                    disabled={isActing}
                                    onClick={async () => {
                                      setActingReleaseId(rel.id);
                                      try {
                                        await onPublishScheduledNow(activeApp, rel);
                                      } finally {
                                        setActingReleaseId(null);
                                      }
                                    }}
                                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-medium whitespace-nowrap"
                                  >
                                    <Send className="w-3.5 h-3.5" />
                                    {isActing ? 'جاري النشر...' : 'نشر الآن'}
                                  </button>
                                  <button
                                    type="button"
                                    disabled={isActing}
                                    onClick={async () => {
                                      setActingReleaseId(rel.id);
                                      try {
                                        await onDeleteRelease(activeApp.id, rel.id);
                                      } finally {
                                        setActingReleaseId(null);
                                      }
                                    }}
                                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 disabled:opacity-50 text-xs font-medium whitespace-nowrap"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                    إلغاء الجدولة
                                  </button>
                                </>
                              )}
                              {isThisDownloading ? (
                                <button
                                  type="button"
                                  onClick={() => releaseDownloadAbortRef.current?.abort()}
                                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 text-xs font-medium whitespace-nowrap shrink-0"
                                >
                                  <X className="w-3.5 h-3.5" />
                                  إلغاء ({releaseDownloadProgress?.percent ?? 0}%)
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  disabled={Boolean(downloadingReleaseId)}
                                  onClick={() => handleDownloadRelease(rel)}
                                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap shrink-0"
                                >
                                  <Download className="w-3.5 h-3.5" />
                                  تحميل الحزمة
                                </button>
                              )}
                            </div>
                          </div>

                          {isThisDownloading && releaseDownloadProgress && (
                            <div className="space-y-1.5 pt-1">
                              <div className="w-full h-1.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                                <div
                                  className="h-full bg-emerald-600 transition-all duration-200"
                                  style={{ width: `${Math.max(4, releaseDownloadProgress.percent)}%` }}
                                />
                              </div>
                              <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                                <span>{releaseDownloadProgress.statusText}</span>
                                <span>
                                  {(releaseDownloadProgress.receivedBytes / (1024 * 1024)).toFixed(1)} /{' '}
                                  {releaseDownloadProgress.totalBytes > 0
                                    ? `${(releaseDownloadProgress.totalBytes / (1024 * 1024)).toFixed(1)} MB`
                                    : '—'}
                                </span>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Saved Compatibility Test Audits */}
              {activeCompatReports.length > 0 && (
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
                    سجل اختبارات التوافق التلقائية ({activeCompatReports.length})
                  </h3>
                  <div className="space-y-2">
                    {activeCompatReports.map((cr) => (
                      <div
                        key={cr.id}
                        className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                      >
                        <div>
                          <div className="flex items-center gap-2 font-medium text-slate-900 dark:text-white">
                            <span className="font-mono">v{cr.version}</span>
                            <span aria-hidden="true">·</span>
                            <span>{OS_LABELS[cr.targetOS].label}</span>
                            <span aria-hidden="true">·</span>
                            <span className="text-slate-500">{cr.detectedFormat}</span>
                          </div>
                          <p className="text-slate-600 dark:text-slate-400 mt-0.5">{cr.summary}</p>
                        </div>
                        <span
                          className={`font-mono font-bold tabular-nums shrink-0 ${
                            cr.overallStatus === 'passed'
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : cr.overallStatus === 'warnings'
                                ? 'text-amber-700 dark:text-amber-400'
                                : 'text-red-700 dark:text-red-400'
                          }`}
                        >
                          {cr.score}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : null}
        </div>
      </div>

      {/* Create New Software Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden max-h-[92vh] flex flex-col">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                رفع برنامج جديد إلى منصة AlKarim
              </h3>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white"
                aria-label="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-6 space-y-4 overflow-y-auto">
              {formError && (
                <div className="p-3.5 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-800 dark:text-red-200 flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <div className="font-bold">تعذر إتمام عملية الرفع أو النشر</div>
                    <p className="leading-relaxed">{formError}</p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    اسم البرنامج
                  </label>
                  <input
                    type="text"
                    value={appName}
                    onChange={(e) => setAppName(e.target.value)}
                    placeholder="مثال: نظام المحاسبة السحابي"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    المعرّف البرمجي (Slug بالإنجليزية)
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={appSlug}
                    onChange={(e) => setAppSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                    placeholder="alkarim-erp"
                    className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white text-left"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  وصف البرنامج
                </label>
                <textarea
                  rows={2}
                  value={appDesc}
                  onChange={(e) => setAppDesc(e.target.value)}
                  placeholder="وصف مختصر لوظيفة البرنامج ومزاياه للمستخدمين..."
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    التصنيف
                  </label>
                  <select
                    value={appCategory}
                    onChange={(e) => setAppCategory(e.target.value as AppCategory)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  >
                    {(Object.keys(CATEGORY_LABELS) as AppCategory[]).map((cat) => (
                      <option key={cat} value={cat}>{CATEGORY_LABELS[cat]}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    رقم الإصدار
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={appVersion}
                    onChange={(e) => setAppVersion(e.target.value)}
                    placeholder="1.0.0"
                    className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white text-left"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    الظهور
                  </label>
                  <select
                    value={appVisibility}
                    onChange={(e) => setAppVisibility(e.target.value as AppVisibility)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  >
                    <option value="public">عام (متاح بالبوابة المباشرة)</option>
                    <option value="private">خاص (للمالك فقط)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
                  أنظمة التشغيل المدعومة
                </label>
                <div className="flex flex-wrap gap-2">
                  {(Object.keys(OS_LABELS) as TargetOS[]).map((os) => {
                    const active = appOS.includes(os);
                    return (
                      <button
                        key={os}
                        type="button"
                        onClick={() => handleToggleOSSelection(os)}
                        className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
                          active
                            ? 'bg-emerald-600 border-emerald-600 text-white'
                            : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {OS_LABELS[os].label}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    ملف البرنامج التنفيذي أو الحزمة (.exe, .dmg, .AppImage, .apk, .zip)
                  </label>
                  <label className="flex items-center justify-center gap-2 p-4 rounded-lg border border-dashed border-slate-300 dark:border-slate-700 hover:border-emerald-600 cursor-pointer bg-slate-50 dark:bg-slate-950/50 text-xs text-slate-600 dark:text-slate-300">
                    <Upload className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="truncate">
                      {selectedFile
                        ? `${selectedFile.name} (${(selectedFile.size / (1024 * 1024)).toFixed(2)} MB)`
                        : 'اختر ملف البرنامج للرفع وحساب SHA-256 تلقائياً (حتى 250 MB)'}
                    </span>
                    <input
                      type="file"
                      className="hidden"
                      onChange={(e) => handleCreateFileChange(e.target.files?.[0] || null)}
                    />
                  </label>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    نظام هذه الحزمة
                  </label>
                  <select
                    value={packageTargetOS}
                    onChange={(e) => setPackageTargetOS(e.target.value as TargetOS)}
                    className="w-full px-3 py-3 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  >
                    {appOS.map((os) => (
                      <option key={os} value={os}>
                        {OS_LABELS[os].label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-6 pt-1">
                <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={appAutoUpdate}
                    onChange={(e) => setAppAutoUpdate(e.target.checked)}
                    className="rounded border-slate-300 text-emerald-600"
                  />
                  تفعيل التحديث التلقائي الفوري لجميع المستخدمين
                </label>
                <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={appMandatory}
                    onChange={(e) => setAppMandatory(e.target.checked)}
                    className="rounded border-slate-300 text-emerald-600"
                  />
                  فرض التحديث الإلزامي
                </label>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ملاحظات الإصدار
                </label>
                <input
                  type="text"
                  value={releaseNotes}
                  onChange={(e) => setReleaseNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                />
              </div>

              <CompatibilityReportPanel
                report={createCompatReport}
                loading={createCompatLoading}
                onRerun={async () => {
                  setCreateCompatLoading(true);
                  try {
                    const res = await runCompatibilityAnalysis({
                      file: selectedFile,
                      targetOS: packageTargetOS,
                      version: appVersion,
                      autoUpdate: appAutoUpdate,
                    });
                    setCreateCompatReport(res);
                  } finally {
                    setCreateCompatLoading(false);
                  }
                }}
              />

              {createCompatReport?.overallStatus === 'failed' && (
                <label className="inline-flex items-center gap-2 text-xs text-red-700 dark:text-red-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={createCompatOverride}
                    onChange={(e) => setCreateCompatOverride(e.target.checked)}
                    className="rounded border-red-300 text-red-600"
                  />
                  أدرك وجود تعارض في التوافق وأرغب في النشر على مسؤوليتي
                </label>
              )}

              {uploading && uploadProgress && (
                <div
                  className={`p-3.5 rounded-lg border space-y-2 ${
                    uploadProgress.retryAttempt > 0
                      ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900'
                      : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 text-xs font-medium text-slate-900 dark:text-white">
                    <span className="truncate">{uploadProgress.statusText}</span>
                    <button
                      type="button"
                      onClick={handleCancelUpload}
                      className="text-red-600 dark:text-red-400 hover:underline shrink-0 text-[11px] font-semibold"
                    >
                      إلغاء الرفع
                    </button>
                  </div>
                  <div className="h-2.5 w-full rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-150 ${
                        uploadProgress.retryAttempt > 0 ? 'bg-amber-500' : 'bg-emerald-600'
                      }`}
                      style={{ width: `${uploadProgress.pct}%` }}
                    />
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-600 dark:text-slate-300 font-mono tabular-nums">
                    <span>
                      {(uploadProgress.loaded / (1024 * 1024)).toFixed(1)} / {(uploadProgress.total / (1024 * 1024)).toFixed(1)} MB ({uploadProgress.pct}%)
                    </span>
                    <span>
                      الجزء {uploadProgress.chunkIndex}/{uploadProgress.totalChunks}
                      {' · '}
                      {formatTransferSpeed(uploadProgress.speedBps)}
                      {formatEta(uploadProgress.etaSeconds) ? ` · ${formatEta(uploadProgress.etaSeconds)}` : ''}
                    </span>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  disabled={uploading}
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300 disabled:opacity-50"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={
                    uploading ||
                    createCompatLoading ||
                    (createCompatReport?.overallStatus === 'failed' && !createCompatOverride)
                  }
                  className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-medium"
                >
                  {uploading
                    ? uploadProgress
                      ? `جاري الرفع (${uploadProgress.pct}%)...`
                      : 'جاري الحفظ والنشر...'
                    : 'نشر البرنامج سحابياً'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Push Instant OTA Update Modal */}
      {updateModalApp && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden max-h-[92vh] flex flex-col">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {updPublishMode === 'scheduled' ? (
                  <CalendarClock className="w-4 h-4 text-amber-600" />
                ) : (
                  <Settings2 className="w-4 h-4 text-emerald-600" />
                )}
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {updPublishMode === 'scheduled'
                    ? `جدولة تحديث مستقبلي: ${updateModalApp.name}`
                    : `دفع تحديث فوري: ${updateModalApp.name}`}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setUpdateModalApp(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handlePublishUpdateSubmit} className="p-6 space-y-4 overflow-y-auto">
              {formError && (
                <div className="p-3.5 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-800 dark:text-red-200 flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <div className="font-bold">تعذر رفع التحديث ونشره</div>
                    <p className="leading-relaxed">{formError}</p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    الإصدار الجديد
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={updVersion}
                    onChange={(e) => setUpdVersion(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white text-left"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    النظام المستهدف
                  </label>
                  <select
                    value={updOS}
                    onChange={(e) => setUpdOS(e.target.value as TargetOS)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  >
                    {updateModalApp.supportedOS.map((os) => (
                      <option key={os} value={os}>{OS_LABELS[os].label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    القناة
                  </label>
                  <select
                    value={updChannel}
                    onChange={(e) => setUpdChannel(e.target.value as ReleaseChannel)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  >
                    <option value="stable">Stable</option>
                    <option value="beta">Beta</option>
                    <option value="canary">Canary</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  رفع ملف التحديث (يُفحص تلقائياً فور الاختيار — يدعم حتى 250 MB)
                </label>
                <input
                  type="file"
                  onChange={(e) => {
                    const f = e.target.files?.[0] || null;
                    setUpdFile(f);
                    if (f) {
                      const detected = inferOSFromFile(f);
                      if (detected && updateModalApp.supportedOS.includes(detected)) {
                        setUpdOS(detected);
                      }
                    }
                  }}
                  className="w-full text-xs text-slate-600 dark:text-slate-300 file:ml-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:bg-slate-100 dark:file:bg-slate-800 file:text-xs file:font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ملاحظات التحديث (تظهر في إشعار المستخدمين)
                </label>
                <textarea
                  rows={2}
                  value={updNotes}
                  onChange={(e) => setUpdNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                />
              </div>

              <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={updMandatory}
                  onChange={(e) => setUpdMandatory(e.target.checked)}
                  className="rounded border-slate-300 text-emerald-600"
                />
                إرسال إشعار فوري وتحديث إلزامي لجميع المستخدمين النشطين
              </label>

              {/* Release Scheduling Section */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-white">
                    <CalendarClock className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>توقيت نشر الإصدار</span>
                  </div>
                  <div className="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-0.5 text-xs">
                    <button
                      type="button"
                      onClick={() => setUpdPublishMode('immediate')}
                      className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                        updPublishMode === 'immediate'
                          ? 'bg-emerald-600 text-white'
                          : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      نشر فوري الآن
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setUpdPublishMode('scheduled');
                        if (!updScheduledFor || Date.parse(updScheduledFor) <= Date.now()) {
                          setUpdScheduledFor(getDefaultScheduledDatetime(1));
                        }
                      }}
                      className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                        updPublishMode === 'scheduled'
                          ? 'bg-amber-600 text-white'
                          : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      جدولة لوقت مستقبلي
                    </button>
                  </div>
                </div>

                {updPublishMode === 'scheduled' && (
                  <div className="space-y-2.5 pt-1 border-t border-slate-200/80 dark:border-slate-800">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2.5">
                      <div className="flex-1">
                        <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                          تاريخ ووقت النشر التلقائي (بتوقيت جهازك المحلي)
                        </label>
                        <input
                          type="datetime-local"
                          dir="ltr"
                          value={updScheduledFor}
                          min={toLocalDatetimeInputValue(new Date())}
                          onChange={(e) => setUpdScheduledFor(e.target.value)}
                          className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-left"
                          required
                        />
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5 sm:pt-5">
                        <button
                          type="button"
                          onClick={() => setUpdScheduledFor(getDefaultScheduledDatetime(1))}
                          className="px-2.5 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px] text-slate-700 dark:text-slate-300"
                        >
                          +1 ساعة
                        </button>
                        <button
                          type="button"
                          onClick={() => setUpdScheduledFor(getDefaultScheduledDatetime(3))}
                          className="px-2.5 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px] text-slate-700 dark:text-slate-300"
                        >
                          +3 ساعات
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            const tomorrow = new Date();
                            tomorrow.setDate(tomorrow.getDate() + 1);
                            tomorrow.setHours(9, 0, 0, 0);
                            setUpdScheduledFor(toLocalDatetimeInputValue(tomorrow));
                          }}
                          className="px-2.5 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px] text-slate-700 dark:text-slate-300"
                        >
                          غداً 9:00 ص
                        </button>
                      </div>
                    </div>
                    <p className="text-[11px] text-amber-800 dark:text-amber-300 leading-relaxed flex items-start gap-1.5">
                      <Clock className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                      <span>
                        سيُحفظ هذا التحديث بشكل مخفي ولن يظهر للمستخدمين حتى حلول موعده ({formatScheduledDateTimeArabic(updScheduledFor)})، كما يمكنك نشره فوراً أو إلغاء جدولته في أي وقت من سجل الإصدارات.
                      </span>
                    </p>
                  </div>
                )}
              </div>

              <CompatibilityReportPanel
                report={updCompatReport}
                loading={updCompatLoading}
                onRerun={async () => {
                  setUpdCompatLoading(true);
                  try {
                    const res = await runCompatibilityAnalysis({
                      file: updFile,
                      targetOS: updOS,
                      version: updVersion,
                      autoUpdate: updateModalApp.autoUpdate,
                    });
                    setUpdCompatReport(res);
                  } finally {
                    setUpdCompatLoading(false);
                  }
                }}
              />

              {updCompatReport?.overallStatus === 'failed' && (
                <label className="inline-flex items-center gap-2 text-xs text-red-700 dark:text-red-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={updCompatOverride}
                    onChange={(e) => setUpdCompatOverride(e.target.checked)}
                    className="rounded border-red-300 text-red-600"
                  />
                  أدرك وجود تعارض في التوافق وأرغب في النشر على مسؤوليتي
                </label>
              )}

              {uploading && uploadProgress && (
                <div
                  className={`p-3.5 rounded-lg border space-y-2 ${
                    uploadProgress.retryAttempt > 0
                      ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900'
                      : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 text-xs font-medium text-slate-900 dark:text-white">
                    <span className="truncate">{uploadProgress.statusText}</span>
                    <button
                      type="button"
                      onClick={handleCancelUpload}
                      className="text-red-600 dark:text-red-400 hover:underline shrink-0 text-[11px] font-semibold"
                    >
                      إلغاء الرفع
                    </button>
                  </div>
                  <div className="h-2.5 w-full rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-150 ${
                        uploadProgress.retryAttempt > 0 ? 'bg-amber-500' : 'bg-emerald-600'
                      }`}
                      style={{ width: `${uploadProgress.pct}%` }}
                    />
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-600 dark:text-slate-300 font-mono tabular-nums">
                    <span>
                      {(uploadProgress.loaded / (1024 * 1024)).toFixed(1)} / {(uploadProgress.total / (1024 * 1024)).toFixed(1)} MB ({uploadProgress.pct}%)
                    </span>
                    <span>
                      الجزء {uploadProgress.chunkIndex}/{uploadProgress.totalChunks}
                      {' · '}
                      {formatTransferSpeed(uploadProgress.speedBps)}
                      {formatEta(uploadProgress.etaSeconds) ? ` · ${formatEta(uploadProgress.etaSeconds)}` : ''}
                    </span>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  disabled={uploading}
                  onClick={() => setUpdateModalApp(null)}
                  className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300 disabled:opacity-50"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={
                    uploading ||
                    updCompatLoading ||
                    (updCompatReport?.overallStatus === 'failed' && !updCompatOverride)
                  }
                  className={`px-5 py-2 rounded-lg disabled:opacity-50 text-white text-xs font-medium ${
                    updPublishMode === 'scheduled'
                      ? 'bg-amber-600 hover:bg-amber-700'
                      : 'bg-emerald-600 hover:bg-emerald-700'
                  }`}
                >
                  {uploading
                    ? uploadProgress
                      ? `جاري الرفع (${uploadProgress.pct}%)...`
                      : updPublishMode === 'scheduled'
                        ? 'جاري حفظ الجدولة...'
                        : 'جاري النشر...'
                    : updPublishMode === 'scheduled'
                      ? 'جدولة وحفظ الإصدار'
                      : 'نشر وتحديث جميع المستخدمين فوراً'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Comfortable Release Notes Reader Modal */}
      {readerRelease && activeApp && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setReaderRelease(null)}
        >
          <div
            className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl overflow-hidden max-h-[90vh] flex flex-col shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 bg-slate-50/70 dark:bg-slate-950/60">
              <div className="flex items-center gap-2.5 min-w-0">
                <BookOpen className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <div className="min-w-0">
                  <h3 className="text-base font-bold text-slate-900 dark:text-white truncate">
                    سجل التحديث: {activeApp.name} <span className="font-mono text-emerald-700 dark:text-emerald-300">v{readerRelease.version}</span>
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5 flex flex-wrap items-center gap-2">
                    <span>{OS_LABELS[readerRelease.targetOS].label}</span>
                    <span aria-hidden="true">·</span>
                    <span>{CHANNEL_LABELS[readerRelease.channel]}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{(readerRelease.fileSizeBytes / (1024 * 1024)).toFixed(1)} MB</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-0.5 text-[11px]">
                  {(
                    [
                      { id: 'sm', label: 'عادي' },
                      { id: 'md', label: 'مريح' },
                      { id: 'lg', label: 'كبير' },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setReaderFontSize(opt.id)}
                      className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                        readerFontSize === opt.id
                          ? 'bg-emerald-600 text-white'
                          : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
                <button
                  type="button"
                  onClick={() => setReaderRelease(null)}
                  aria-label="إغلاق وضع القراءة"
                  className="p-1.5 rounded-lg text-slate-500 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto space-y-4">
              <div className="p-5 sm:p-6 rounded-xl bg-slate-50 dark:bg-slate-950/90 border border-slate-200 dark:border-slate-800">
                <p
                  className={`whitespace-pre-line break-words text-slate-800 dark:text-slate-100 ${
                    readerFontSize === 'sm'
                      ? 'text-sm leading-7'
                      : readerFontSize === 'lg'
                        ? 'text-lg leading-9'
                        : 'text-base leading-8'
                  }`}
                >
                  {(readerRelease.releaseNotes || '').trim() || 'لا توجد ملاحظات مسجلة لهذا الإصدار.'}
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <span className="font-mono text-slate-600 dark:text-slate-300 truncate">
                  SHA-256: {readerRelease.sha256}
                </span>
                <button
                  type="button"
                  onClick={async () => {
                    await navigator.clipboard.writeText(readerRelease.sha256);
                    setCopiedReaderSha(true);
                    setTimeout(() => setCopiedReaderSha(false), 1800);
                  }}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
                >
                  {copiedReaderSha ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      <span>تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ البصمة</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="px-6 py-3.5 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2 bg-slate-50/50 dark:bg-slate-950/40">
              <button
                type="button"
                onClick={() => setReaderRelease(null)}
                className="px-4 py-2 rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-medium"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
