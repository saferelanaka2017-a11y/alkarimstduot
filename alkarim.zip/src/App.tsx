/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Auth, onAuthStateChanged, signOut, User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  Firestore,
  getDoc,
  getDocs,
  increment,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  AlertTriangle,
  BarChart3,
  Bell,
  Code2,
  Download,
  Eye,
  FileBarChart,
  Layers,
  Link2,
  LogOut,
  Menu,
  Moon,
  Plus,
  RefreshCw,
  ShieldCheck,
  Sun,
  X,
} from 'lucide-react';
import { getFirebaseForMode } from './firebase';
import { handleFirestoreError, OperationType } from './lib/firestoreErrors';
import {
  getAppQueryParam,
  getPortalEntryModeFromLocation,
  navigatePortalRoute,
  PortalEntryMode,
} from './lib/portalRoutes';
import {
  ApiKeyRecord,
  AppCategory,
  AppRelease,
  AppVisibility,
  CompatibilityCheckResult,
  CompatibilityReportRecord,
  NavSection,
  PeriodicReport,
  ReleaseChannel,
  ReportPeriod,
  SoftwareApp,
  TargetOS,
  UserPrivateSecurity,
  UserProfile,
} from './types';
import { AuthGate } from './components/AuthGate';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { AppsManager } from './components/AppsManager';
import { DirectInstallPortal } from './components/DirectInstallPortal';
import { ApiIntegrationView } from './components/ApiIntegrationView';
import { ReportsView } from './components/ReportsView';
import { SecuritySettingsView } from './components/SecuritySettingsView';
import { PortalLinksModal } from './components/PortalLinksModal';

interface UpdateNotification {
  id: string;
  appId: string;
  appName: string;
  version: string;
  message: string;
  timestamp: string;
  read: boolean;
}

const SECTION_TITLES: Record<NavSection, string> = {
  analytics: 'لوحة الإحصائيات والتحليلات اللحظية',
  apps: 'إدارة البرامج والتحديث التلقائي',
  portal: 'بوابة التحميل والتنصيب المباشر',
  api: 'التكامل البرمجي وواجهات API',
  reports: 'التقارير الدورية والأداء',
  security: 'الحساب والإشعارات',
};

const APP_ICONS_BY_CATEGORY: Record<AppCategory, string> = {
  productivity: '/src/assets/images/app_icon_cloudsync_1795296596170.jpg',
  developer: '/src/assets/images/app_icon_devcli_1795296596094.jpg',
  security: '/src/assets/images/app_icon_secshield_1795296596126.jpg',
  utilities: '/src/assets/images/app_icon_devcli_1795296596094.jpg',
  media: '/src/assets/images/app_icon_cloudsync_1795296596170.jpg',
  enterprise: '/src/assets/images/app_icon_secshield_1795296596126.jpg',
};

async function sha256Hex(input: string): Promise<string> {
  const encoded = new TextEncoder().encode(input);
  const hashBuffer = await crypto.subtle.digest('SHA-256', encoded);
  return Array.from(new Uint8Array(hashBuffer))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

const PREEXISTING_PLATFORM_PURGE_CUTOFF_MS = Date.parse('2026-11-23T21:21:15Z');

function getCreatedAtMillis(createdAt: unknown): number | null {
  if (!createdAt) return null;
  if (typeof createdAt === 'object' && createdAt !== null) {
    const maybeTs = createdAt as { toMillis?: () => number; seconds?: number };
    if (typeof maybeTs.toMillis === 'function') return maybeTs.toMillis();
    if (typeof maybeTs.seconds === 'number') return maybeTs.seconds * 1000;
  }
  if (typeof createdAt === 'string') {
    const ms = Date.parse(createdAt);
    return Number.isFinite(ms) ? ms : null;
  }
  return null;
}

const MAX_PERSISTENT_BINARY_BYTES = 2048000; // 4 chunks * 512,000 bytes (stays under Firestore 750k base64 char/doc rule)
const PERSISTENT_CHUNK_RAW_BYTES = 512000;

function extractPackageIdFromUrl(downloadUrl: string): string | null {
  try {
    const parsed = new URL(
      downloadUrl,
      typeof window !== 'undefined' ? window.location.origin : 'http://localhost'
    );
    const prefix = '/api/packages/download/';
    if (parsed.pathname.startsWith(prefix)) {
      return decodeURIComponent(parsed.pathname.slice(prefix.length));
    }
  } catch {
    // ignore malformed URL
  }
  return null;
}

function uint8ToBase64(bytes: Uint8Array): string {
  const sliceLen = 0x8000;
  let binary = '';
  for (let i = 0; i < bytes.length; i += sliceLen) {
    const sub = bytes.subarray(i, Math.min(bytes.length, i + sliceLen));
    binary += String.fromCharCode.apply(null, Array.from(sub));
  }
  return btoa(binary);
}

async function buildPackageChunkPayloads(params: {
  file: File;
  appId: string;
  packageId: string;
  ownerId: string;
  visibility: AppVisibility;
  sha256: string;
}): Promise<
  Array<{
    id: string;
    appId: string;
    packageId: string;
    ownerId: string;
    visibility: AppVisibility;
    chunkIndex: number;
    totalChunks: number;
    fileSizeBytes: number;
    sha256: string;
    dataBase64: string;
    createdAt: ReturnType<typeof serverTimestamp>;
  }>
> {
  const { file, appId, packageId, ownerId, visibility, sha256 } = params;
  if (file.size < 1 || file.size > MAX_PERSISTENT_BINARY_BYTES || packageId.startsWith('pkg-')) {
    return [];
  }
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  const totalChunks = Math.ceil(bytes.length / PERSISTENT_CHUNK_RAW_BYTES);
  if (totalChunks < 1 || totalChunks > 4) return [];

  const sanitizedPkg = packageId.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 64) || 'pkg';
  const chunks = [];
  for (let i = 0; i < totalChunks; i++) {
    const start = i * PERSISTENT_CHUNK_RAW_BYTES;
    const end = Math.min(bytes.length, start + PERSISTENT_CHUNK_RAW_BYTES);
    const chunkBase64 = uint8ToBase64(bytes.subarray(start, end));
    const chunkId = `chk_${sanitizedPkg}_${i}`.slice(0, 96);
    chunks.push({
      id: chunkId,
      appId,
      packageId,
      ownerId,
      visibility,
      chunkIndex: i,
      totalChunks,
      fileSizeBytes: bytes.length,
      sha256,
      dataBase64: chunkBase64,
      createdAt: serverTimestamp(),
    });
  }
  return chunks;
}

export default function App() {
  const [entryMode, setEntryMode] = useState<PortalEntryMode>(() => getPortalEntryModeFromLocation());
  const { auth: activeAuth, db: activeDb } = useMemo(() => getFirebaseForMode(entryMode), [entryMode]);
  const [initialPortalAppParam] = useState<string | null>(() => getAppQueryParam());
  const [authReady, setAuthReady] = useState(false);
  const [authSyncError, setAuthSyncError] = useState<string | null>(null);
  const [portalRoleError, setPortalRoleError] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [publicPortalStandalone, setPublicPortalStandalone] = useState<boolean>(false);
  const [pendingRole, setPendingRole] = useState<'user' | 'developer'>(() => {
    const mode = getPortalEntryModeFromLocation();
    if (mode === 'client') return 'user';
    if (mode === 'developer') return 'developer';
    try {
      return localStorage.getItem('alkarim_pending_role') === 'user' ? 'user' : 'developer';
    } catch {
      return 'developer';
    }
  });
  const pendingRoleRef = useRef<'user' | 'developer'>(pendingRole);
  const entryModeRef = useRef<PortalEntryMode>(entryMode);
  const [previewAsUser, setPreviewAsUser] = useState<boolean>(false);
  const [linksModalOpen, setLinksModalOpen] = useState(false);

  const [darkMode, setDarkMode] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<NavSection>(() =>
    getPortalEntryModeFromLocation() === 'client' ? 'portal' : 'analytics'
  );
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);
  const [createModalTrigger, setCreateModalTrigger] = useState(0);

  // Firestore synced collections
  const [ownerApps, setOwnerApps] = useState<SoftwareApp[]>([]);
  const [publicApps, setPublicApps] = useState<SoftwareApp[]>([]);
  const [syncFromCache, setSyncFromCache] = useState(false);
  const [releasesByApp, setReleasesByApp] = useState<Record<string, AppRelease[]>>({});
  const [compatReportsByApp, setCompatReportsByApp] = useState<Record<string, CompatibilityReportRecord[]>>({});
  const [apiKeys, setApiKeys] = useState<ApiKeyRecord[]>([]);
  const [reports, setReports] = useState<PeriodicReport[]>([]);

  // Installed device registry & real-time notification system
  const [installedVersions, setInstalledVersions] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem('alkarim_installed_apps');
      return saved ? (JSON.parse(saved) as Record<string, string>) : {};
    } catch {
      return {};
    }
  });
  const [notifications, setNotifications] = useState<UpdateNotification[]>([]);
  const [notifOpen, setNotifOpen] = useState(false);
  const [activeToast, setActiveToast] = useState<UpdateNotification | null>(null);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission | 'unsupported'>(() => {
    if (typeof window === 'undefined' || !('Notification' in window)) return 'unsupported';
    return window.Notification.permission;
  });

  const seededUsersRef = useRef<Set<string>>(new Set());
  const prevVersionsRef = useRef<Record<string, string>>({});

  // Sync dark mode class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [darkMode]);

  // Persist installed device registry
  useEffect(() => {
    try {
      localStorage.setItem('alkarim_installed_apps', JSON.stringify(installedVersions));
    } catch {
      // ignore storage quota errors
    }
  }, [installedVersions]);

  const handleSelectPendingRole = (role: 'user' | 'developer') => {
    setPendingRole(role);
    pendingRoleRef.current = role;
    try {
      localStorage.setItem('alkarim_pending_role', role);
    } catch {
      // ignore storage errors
    }
  };

  const syncAuthenticatedUserProfile = async (
    firebaseUser: User,
    targetDb: Firestore,
    targetAuth: Auth
  ) => {
    setAuthSyncError(null);
    const userRef = doc(targetDb, 'users', firebaseUser.uid);
    const secRef = doc(targetDb, 'users', firebaseUser.uid, 'private', 'security');
    const [userSnap, secSnap] = await Promise.all([getDoc(userRef), getDoc(secRef)]);

    const isClientSession = entryModeRef.current === 'client';

    // Client links must never remain logged in with a developer/admin account
    if (isClientSession && userSnap.exists()) {
      const existingProfile = userSnap.data() as UserProfile;
      if (existingProfile.role !== 'user') {
        await signOut(targetAuth);
        setUser(null);
        setUserProfile(null);
        setPortalRoleError(
          'هذا الحساب مسجل كحساب مطور. روابط العملاء مخصصة لتسجيل دخول العملاء فقط؛ يرجى الدخول بحساب عميل أو إنشاء حساب عميل جديد.'
        );
        return;
      }
    }

    const providerId = (firebaseUser.providerData[0]?.providerId || 'password').slice(0, 40) || 'password';
    const defaultLabel = isClientSession ? 'عميل AlKarim' : 'مطور AlKarim';
    const rawName = (firebaseUser.displayName || firebaseUser.email?.split('@')[0] || defaultLabel).trim();
    const displayName = (rawName || defaultLabel).slice(0, 80);
    const safePhotoURL = (firebaseUser.photoURL || '').slice(0, 500);
    const safeEmail = (firebaseUser.email || '').slice(0, 160);

    if (!userSnap.exists()) {
      const resolvedRole: 'user' | 'developer' = isClientSession ? 'user' : pendingRoleRef.current;
      const newProfile: UserProfile = {
        uid: firebaseUser.uid,
        displayName,
        photoURL: safePhotoURL,
        role: resolvedRole,
        twoFactorEnabled: false,
      };
      await setDoc(userRef, {
        ...newProfile,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setUserProfile(newProfile);
      setActiveSection(
        newProfile.role === 'user' || isClientSession ? 'portal' : 'analytics'
      );
    } else {
      const existingProfile = userSnap.data() as UserProfile;
      setUserProfile(existingProfile);
      if (existingProfile.role === 'user' || isClientSession) {
        setActiveSection('portal');
      }
    }

    if (!secSnap.exists()) {
      const initialSec: UserPrivateSecurity = {
        email: safeEmail,
        provider: providerId,
        twoFactorEnabled: false,
        totpSecret: '',
        backupCodesCount: 0,
        updatedAt: serverTimestamp(),
      };
      await setDoc(secRef, initialSec);
    }
  };

  const handleRetryUserSync = async () => {
    const current = activeAuth.currentUser;
    if (!current) return;
    setUser(current);
    try {
      await syncAuthenticatedUserProfile(current, activeDb, activeAuth);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'تعذر مزامنة بيانات الحساب.';
      setAuthSyncError(message);
    }
  };

  const handleSwitchEntryMode = (target: 'developer' | 'client') => {
    navigatePortalRoute(target);
    entryModeRef.current = target;
    setEntryMode(target);
    setPortalRoleError(null);
    setPublicPortalStandalone(false);
    setPreviewAsUser(false);
    if (target === 'client') {
      handleSelectPendingRole('user');
      setActiveSection('portal');
    } else {
      handleSelectPendingRole('developer');
      setActiveSection('analytics');
    }
  };

  useEffect(() => {
    const onPopState = () => {
      const mode = getPortalEntryModeFromLocation();
      entryModeRef.current = mode;
      setEntryMode(mode);
      setPortalRoleError(null);
      setPublicPortalStandalone(false);
      setPreviewAsUser(false);
      if (mode === 'client') {
        handleSelectPendingRole('user');
        setActiveSection('portal');
      } else {
        handleSelectPendingRole('developer');
        setActiveSection('analytics');
      }
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  // Subscribe to Auth state for the active portal (isolated between developer and client)
  useEffect(() => {
    setAuthReady(false);
    const unsub = onAuthStateChanged(activeAuth, async (firebaseUser) => {
      setUser(firebaseUser);
      setUserProfile(null);
      setAuthSyncError(null);

      if (!firebaseUser) {
        setPreviewAsUser(false);
        setOwnerApps([]);
        setApiKeys([]);
        setReports([]);
        setAuthReady(true);
        return;
      }

      try {
        setPortalRoleError(null);
        await syncAuthenticatedUserProfile(firebaseUser, activeDb, activeAuth);
      } catch (err) {
        try {
          handleFirestoreError(err, OperationType.WRITE, `users/${firebaseUser.uid}`, activeAuth);
        } catch (wrappedErr) {
          setAuthSyncError(
            wrappedErr instanceof Error ? wrappedErr.message : 'تعذر مزامنة ملف المستخدم في قاعدة البيانات.'
          );
        }
      } finally {
        setAuthReady(true);
      }
    });
    return () => unsub();
  }, [activeAuth, activeDb]);

  // Subscribe to Public Apps (for Direct Install Portal even before login)
  useEffect(() => {
    const q = query(collection(activeDb, 'apps'), where('visibility', '==', 'public'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as SoftwareApp);
        setPublicApps(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'apps', activeAuth);
      }
    );
    return () => unsub();
  }, [activeDb, activeAuth]);

  const isDeveloperAccount =
    userProfile?.role === 'developer' || userProfile?.role === 'admin';
  const isClientRoute = entryMode === 'client';
  const showDeveloperUI = isDeveloperAccount && !previewAsUser && !isClientRoute;

  // Keep non-developers strictly inside user-facing sections
  useEffect(() => {
    if (!showDeveloperUI && activeSection !== 'portal' && activeSection !== 'security') {
      setActiveSection('portal');
    }
  }, [showDeveloperUI, activeSection]);

  // Subscribe to Authenticated Developer's Workspace Collections
  useEffect(() => {
    if (!user || !isDeveloperAccount || isClientRoute) return;

    const ownerAppsQuery = query(collection(activeDb, 'apps'), where('ownerId', '==', user.uid));
    const unsubApps = onSnapshot(
      ownerAppsQuery,
      (snap) => {
        setSyncFromCache(snap.metadata.fromCache);
        const list = snap.docs.map((d) => d.data() as SoftwareApp);
        setOwnerApps(list);

        // Remove pre-existing demo/uploaded apps created before this cleanup cutoff (never touches newly uploaded apps)
        if (!snap.metadata.fromCache && list.length > 0) {
          for (const existingApp of list) {
            if (seededUsersRef.current.has(existingApp.id)) continue;
            const isSeededDemo =
              existingApp.id.startsWith('app_cloudsync_') ||
              existingApp.id.startsWith('app_devcli_') ||
              existingApp.id.startsWith('app_secshield_');
            const createdMs = getCreatedAtMillis(existingApp.createdAt);
            if (
              isSeededDemo ||
              (createdMs !== null && createdMs <= PREEXISTING_PLATFORM_PURGE_CUTOFF_MS)
            ) {
              seededUsersRef.current.add(existingApp.id);
              void handleDeleteApp(existingApp.id);
            }
          }
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'apps', activeAuth);
      }
    );

    const keysQuery = query(collection(activeDb, 'api_keys'), where('ownerId', '==', user.uid));
    const unsubKeys = onSnapshot(
      keysQuery,
      (snap) => {
        setApiKeys(snap.docs.map((d) => d.data() as ApiKeyRecord));
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'api_keys', activeAuth);
      }
    );

    const reportsQuery = query(collection(activeDb, 'reports'), where('ownerId', '==', user.uid));
    const unsubReports = onSnapshot(
      reportsQuery,
      (snap) => {
        setReports(snap.docs.map((d) => d.data() as PeriodicReport));
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'reports', activeAuth);
      }
    );

    return () => {
      unsubApps();
      unsubKeys();
      unsubReports();
    };
  }, [user, isDeveloperAccount, isClientRoute, activeDb, activeAuth]);

  // Merge ownerApps + publicApps cleanly for the Direct Install Portal
  const allVisibleApps = useMemo(() => {
    const map = new Map<string, SoftwareApp>();
    for (const a of publicApps) map.set(a.id, a);
    for (const a of ownerApps) map.set(a.id, a);
    return Array.from(map.values());
  }, [ownerApps, publicApps]);

  // Developer workspace strictly manages the developer's own applications
  const workspaceApps = ownerApps;

  // Subscribe to releases for active apps
  useEffect(() => {
    if (allVisibleApps.length === 0) return;
    const unsubs: Array<() => void> = [];

    for (const app of allVisibleApps) {
      const relQuery =
        user && app.ownerId === user.uid
          ? query(collection(activeDb, 'apps', app.id, 'releases'), where('ownerId', '==', user.uid))
          : query(collection(activeDb, 'apps', app.id, 'releases'), where('visibility', '==', 'public'));

      const unsub = onSnapshot(
        relQuery,
        (snap) => {
          const list = snap.docs.map((d) => d.data() as AppRelease);
          setReleasesByApp((prev) => ({ ...prev, [app.id]: list }));
        },
        (err) => {
          handleFirestoreError(err, OperationType.LIST, `apps/${app.id}/releases`, activeAuth);
        }
      );
      unsubs.push(unsub);

      if (user && app.ownerId === user.uid) {
        const compatQuery = query(
          collection(activeDb, 'apps', app.id, 'compatibility_reports'),
          where('ownerId', '==', user.uid)
        );
        const unsubCompat = onSnapshot(
          compatQuery,
          (snap) => {
            const list = snap.docs.map((d) => d.data() as CompatibilityReportRecord);
            setCompatReportsByApp((prev) => ({ ...prev, [app.id]: list }));
          },
          (err) => {
            handleFirestoreError(err, OperationType.LIST, `apps/${app.id}/compatibility_reports`, activeAuth);
          }
        );
        unsubs.push(unsubCompat);
      }
    }

    return () => {
      for (const u of unsubs) u();
    };
  }, [allVisibleApps, user, activeDb, activeAuth]);

  // Real-Time Update Notification Detector for Installed Apps!
  useEffect(() => {
    if (allVisibleApps.length === 0) return;

    // Auto-register first app on device if device has zero installed apps yet (for immediate live demonstration)
    if (Object.keys(installedVersions).length === 0 && allVisibleApps[0]) {
      setInstalledVersions({ [allVisibleApps[0].id]: allVisibleApps[0].latestVersion });
      prevVersionsRef.current[allVisibleApps[0].id] = allVisibleApps[0].latestVersion;
      return;
    }

    for (const app of allVisibleApps) {
      const installedVer = installedVersions[app.id];
      const prevKnown = prevVersionsRef.current[app.id];
      prevVersionsRef.current[app.id] = app.latestVersion;

      if (installedVer && app.latestVersion !== installedVer && prevKnown !== app.latestVersion) {
        const notif: UpdateNotification = {
          id: `notif_${app.id}_${Date.now()}`,
          appId: app.id,
          appName: app.name,
          version: app.latestVersion,
          message: app.autoUpdate
            ? `تم إصدار v${app.latestVersion} من ${app.name}. جاري التحديث التلقائي الفوري على جهازك.`
            : `يتوفر إصدار جديد v${app.latestVersion} من ${app.name} وجاهز للتثبيت.`,
          timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
          read: false,
        };

        setNotifications((prev) => [notif, ...prev].slice(0, 20));
        setActiveToast(notif);

        if (typeof window !== 'undefined' && 'Notification' in window && window.Notification.permission === 'granted') {
          try {
            new window.Notification(`تحديث فوري من AlKarim: ${app.name}`, {
              body: notif.message,
              icon: app.iconUrl || '/src/assets/images/alkarim_brand_emblem_1795296596572.jpg',
            });
          } catch {
            // ignore notification errors in restricted contexts
          }
        }

        if (app.autoUpdate) {
          setTimeout(() => {
            setInstalledVersions((prev) => ({
              ...prev,
              [app.id]: app.latestVersion,
            }));
          }, 1500);
        }
      }
    }
  }, [allVisibleApps, installedVersions]);

  const activatingReleasesRef = useRef<Set<string>>(new Set());

  const handleActivateScheduledRelease = async (app: SoftwareApp, rel: AppRelease) => {
    if (!user) return;
    const key = `${app.id}/${rel.id}`;
    if (activatingReleasesRef.current.has(key)) return;
    activatingReleasesRef.current.add(key);

    try {
      const batch = writeBatch(activeDb);
      batch.update(doc(activeDb, 'apps', app.id, 'releases', rel.id), {
        status: 'published',
        scheduledFor: '',
        visibility: app.visibility,
      });
      batch.update(doc(activeDb, 'apps', app.id), {
        latestVersion: rel.version,
        channel: rel.channel,
        mandatoryUpdate: rel.mandatory,
        updatedAt: serverTimestamp(),
      });
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `apps/${app.id}/releases/${rel.id}`, activeAuth);
    } finally {
      activatingReleasesRef.current.delete(key);
    }
  };

  // Automatic Release Scheduler: publishes due scheduled releases every 15s when developer console is open
  useEffect(() => {
    if (!user || workspaceApps.length === 0) return;

    const checkDueScheduledReleases = () => {
      const now = Date.now();
      for (const app of workspaceApps) {
        const appReleases = releasesByApp[app.id] || [];
        for (const rel of appReleases) {
          if (rel.status === 'scheduled' && rel.scheduledFor) {
            const targetMs = Date.parse(rel.scheduledFor);
            if (Number.isFinite(targetMs) && targetMs <= now) {
              void handleActivateScheduledRelease(app, rel);
            }
          }
        }
      }
    };

    checkDueScheduledReleases();
    const intervalId = window.setInterval(checkDueScheduledReleases, 15000);
    return () => window.clearInterval(intervalId);
  }, [user, workspaceApps, releasesByApp]);

  const handleRequestNotifications = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setNotificationPermission('unsupported');
      return;
    }
    const perm = await window.Notification.requestPermission();
    setNotificationPermission(perm);
  };

  // Create New Application + Initial Release
  const handleCreateApp = async (payload: {
    name: string;
    slug: string;
    description: string;
    category: AppCategory;
    version: string;
    channel: ReleaseChannel;
    autoUpdate: boolean;
    mandatoryUpdate: boolean;
    supportedOS: TargetOS[];
    visibility: AppVisibility;
    fileInfo: {
      fileName: string;
      fileSizeBytes: number;
      sha256: string;
      downloadUrl: string;
      persistentFile?: File;
    };
    releaseNotes: string;
    primaryTargetOS?: TargetOS;
    compatibilityReport?: CompatibilityCheckResult | null;
  }) => {
    if (!user) return;
    const initialTargetOS = payload.primaryTargetOS || payload.supportedOS[0];
    const appId = `app_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
    const safeVersion = (payload.version.trim() || '1.0.0').slice(0, 32);
    const releaseId = `rel_${safeVersion.replace(/[^a-zA-Z0-9]/g, '_')}_${initialTargetOS}`.slice(0, 64);
    const ownerName = (user.displayName || user.email?.split('@')[0] || 'مطور AlKarim').trim().slice(0, 80) || 'مطور AlKarim';
    const rawSlug = payload.slug.toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-|-$/g, '');
    const safeSlug = (rawSlug.length >= 2 ? rawSlug : `app-${Date.now().toString(36)}`).slice(0, 64);
    const safeName = (payload.name.trim() || 'تطبيق AlKarim').slice(0, 80);
    const safeDesc = (payload.description.trim() || 'تطبيق مدار سحابياً عبر منصة AlKarim.').slice(0, 500);

    try {
      // Step 1: Commit parent app document first so subcollection security rules
      // (exists/get on /apps/{appId}) see the committed parent document.
      await setDoc(doc(activeDb, 'apps', appId), {
        id: appId,
        slug: safeSlug,
        ownerId: user.uid,
        ownerName,
        name: safeName,
        description: safeDesc,
        category: payload.category,
        iconUrl: APP_ICONS_BY_CATEGORY[payload.category],
        latestVersion: safeVersion,
        channel: payload.channel,
        autoUpdate: payload.autoUpdate,
        mandatoryUpdate: payload.mandatoryUpdate,
        supportedOS: payload.supportedOS,
        downloadsCount: 0,
        activeUsersCount: 1,
        crashFreeRate: 100,
        apiEnabled: true,
        visibility: payload.visibility,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      // Step 2: Commit initial release, compatibility audit, and persistent binary backup chunks (<= 2 MB)
      const childBatch = writeBatch(activeDb);
      childBatch.set(doc(activeDb, 'apps', appId, 'releases', releaseId), {
        id: releaseId,
        appId,
        ownerId: user.uid,
        version: safeVersion,
        channel: payload.channel,
        targetOS: initialTargetOS,
        fileName: payload.fileInfo.fileName.slice(0, 160),
        fileSizeBytes: payload.fileInfo.fileSizeBytes,
        sha256: payload.fileInfo.sha256,
        downloadUrl: payload.fileInfo.downloadUrl.slice(0, 500),
        releaseNotes: (payload.releaseNotes || 'إصدار أولي.').slice(0, 2000),
        mandatory: payload.mandatoryUpdate,
        visibility: payload.visibility,
        status: 'published',
        scheduledFor: '',
        downloads: 0,
        createdAt: serverTimestamp(),
      });

      if (payload.compatibilityReport) {
        const compatId = `compat_${Date.now().toString(36)}`;
        childBatch.set(doc(activeDb, 'apps', appId, 'compatibility_reports', compatId), {
          id: compatId,
          appId,
          ownerId: user.uid,
          version: safeVersion,
          targetOS: payload.compatibilityReport.targetOS,
          overallStatus: payload.compatibilityReport.overallStatus,
          score: payload.compatibilityReport.score,
          detectedFormat: payload.compatibilityReport.detectedFormat.slice(0, 120),
          summary: payload.compatibilityReport.summary.slice(0, 500),
          createdAt: serverTimestamp(),
        });
      }

      const packageId = extractPackageIdFromUrl(payload.fileInfo.downloadUrl);
      if (payload.fileInfo.persistentFile && packageId) {
        const chunkPayloads = await buildPackageChunkPayloads({
          file: payload.fileInfo.persistentFile,
          appId,
          packageId,
          ownerId: user.uid,
          visibility: payload.visibility,
          sha256: payload.fileInfo.sha256,
        });
        for (const chunk of chunkPayloads) {
          childBatch.set(doc(activeDb, 'apps', appId, 'package_chunks', chunk.id), chunk);
        }
      }

      await childBatch.commit();
      setSelectedAppId(appId);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `apps/${appId}`, activeAuth);
    }
  };

  // Publish Instant or Scheduled OTA Update
  const handlePublishUpdate = async (payload: {
    app: SoftwareApp;
    version: string;
    channel: ReleaseChannel;
    targetOS: TargetOS;
    mandatory: boolean;
    releaseNotes: string;
    fileInfo: {
      fileName: string;
      fileSizeBytes: number;
      sha256: string;
      downloadUrl: string;
      persistentFile?: File;
    };
    compatibilityReport?: CompatibilityCheckResult | null;
    publishMode?: 'immediate' | 'scheduled';
    scheduledFor?: string;
  }) => {
    if (!user) return;
    const safeVersion = (payload.version.trim() || '1.0.0').slice(0, 32);
    const releaseId = `rel_${safeVersion.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now().toString(36)}`.slice(0, 64);
    const isScheduled = payload.publishMode === 'scheduled' && Boolean(payload.scheduledFor);
    const safeScheduledFor = isScheduled ? (payload.scheduledFor || '').slice(0, 40) : '';
    const batch = writeBatch(activeDb);

    batch.set(doc(activeDb, 'apps', payload.app.id, 'releases', releaseId), {
      id: releaseId,
      appId: payload.app.id,
      ownerId: user.uid,
      version: safeVersion,
      channel: payload.channel,
      targetOS: payload.targetOS,
      fileName: payload.fileInfo.fileName.slice(0, 160),
      fileSizeBytes: payload.fileInfo.fileSizeBytes,
      sha256: payload.fileInfo.sha256,
      downloadUrl: payload.fileInfo.downloadUrl.slice(0, 500),
      releaseNotes: (payload.releaseNotes || '').slice(0, 2000),
      mandatory: payload.mandatory,
      visibility: isScheduled ? 'private' : payload.app.visibility,
      status: isScheduled ? 'scheduled' : 'published',
      scheduledFor: safeScheduledFor,
      downloads: 0,
      createdAt: serverTimestamp(),
    });

    if (payload.compatibilityReport) {
      const compatId = `compat_${Date.now().toString(36)}`;
      batch.set(doc(activeDb, 'apps', payload.app.id, 'compatibility_reports', compatId), {
        id: compatId,
        appId: payload.app.id,
        ownerId: user.uid,
        version: safeVersion,
        targetOS: payload.compatibilityReport.targetOS,
        overallStatus: payload.compatibilityReport.overallStatus,
        score: payload.compatibilityReport.score,
        detectedFormat: payload.compatibilityReport.detectedFormat.slice(0, 120),
        summary: payload.compatibilityReport.summary.slice(0, 500),
        createdAt: serverTimestamp(),
      });
    }

    const packageId = extractPackageIdFromUrl(payload.fileInfo.downloadUrl);
    if (payload.fileInfo.persistentFile && packageId) {
      const chunkPayloads = await buildPackageChunkPayloads({
        file: payload.fileInfo.persistentFile,
        appId: payload.app.id,
        packageId,
        ownerId: user.uid,
        visibility: payload.app.visibility,
        sha256: payload.fileInfo.sha256,
      });
      for (const chunk of chunkPayloads) {
        batch.set(doc(activeDb, 'apps', payload.app.id, 'package_chunks', chunk.id), chunk);
      }
    }

    if (!isScheduled) {
      batch.update(doc(activeDb, 'apps', payload.app.id), {
        latestVersion: safeVersion,
        channel: payload.channel,
        mandatoryUpdate: payload.mandatory,
        updatedAt: serverTimestamp(),
      });
    }

    try {
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `apps/${payload.app.id}`, activeAuth);
    }
  };

  const handleDeleteRelease = async (appId: string, releaseId: string) => {
    try {
      const existingRelease = (releasesByApp[appId] || []).find((r) => r.id === releaseId);
      const pkgId = existingRelease ? extractPackageIdFromUrl(existingRelease.downloadUrl) : null;

      await deleteDoc(doc(activeDb, 'apps', appId, 'releases', releaseId));

      if (user && pkgId && !pkgId.startsWith('pkg-')) {
        const stillReferenced = (releasesByApp[appId] || []).some(
          (r) => r.id !== releaseId && extractPackageIdFromUrl(r.downloadUrl) === pkgId
        );
        if (!stillReferenced) {
          const chunksSnap = await getDocs(
            query(
              collection(activeDb, 'apps', appId, 'package_chunks'),
              where('ownerId', '==', user.uid)
            )
          );
          const matching = chunksSnap.docs.filter((d) => d.data().packageId === pkgId);
          if (matching.length > 0) {
            const cleanupBatch = writeBatch(activeDb);
            for (const d of matching) cleanupBatch.delete(d.ref);
            await cleanupBatch.commit();
          }
        }
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `apps/${appId}/releases/${releaseId}`, activeAuth);
    }
  };

  const handleToggleAutoUpdate = async (app: SoftwareApp) => {
    try {
      await updateDoc(doc(activeDb, 'apps', app.id), {
        autoUpdate: !app.autoUpdate,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `apps/${app.id}`, activeAuth);
    }
  };

  const handleDeleteApp = async (appId: string) => {
    if (!user) {
      throw new Error('يجب تسجيل الدخول لحذف البرنامج.');
    }
    try {
      const targetApp =
        ownerApps.find((a) => a.id === appId) || publicApps.find((a) => a.id === appId);
      const ownerUid = targetApp?.ownerId || user.uid;

      const [relSnap, compatSnap, chunkSnap] = await Promise.all([
        getDocs(query(collection(activeDb, 'apps', appId, 'releases'), where('ownerId', '==', ownerUid))),
        getDocs(
          query(
            collection(activeDb, 'apps', appId, 'compatibility_reports'),
            where('ownerId', '==', ownerUid)
          )
        ),
        getDocs(
          query(
            collection(activeDb, 'apps', appId, 'package_chunks'),
            where('ownerId', '==', ownerUid)
          )
        ),
      ]);

      const childRefs = new Map<string, ReturnType<typeof doc>>();
      for (const d of relSnap.docs) childRefs.set(d.ref.path, d.ref);
      for (const d of compatSnap.docs) childRefs.set(d.ref.path, d.ref);
      for (const d of chunkSnap.docs) childRefs.set(d.ref.path, d.ref);
      for (const rel of releasesByApp[appId] || []) {
        const ref = doc(activeDb, 'apps', appId, 'releases', rel.id);
        childRefs.set(ref.path, ref);
      }
      for (const cr of compatReportsByApp[appId] || []) {
        const ref = doc(activeDb, 'apps', appId, 'compatibility_reports', cr.id);
        childRefs.set(ref.path, ref);
      }

      const refsList = Array.from(childRefs.values());
      for (let i = 0; i < refsList.length; i += 400) {
        const subBatch = writeBatch(activeDb);
        for (const ref of refsList.slice(i, i + 400)) {
          subBatch.delete(ref);
        }
        await subBatch.commit();
      }

      await deleteDoc(doc(activeDb, 'apps', appId));

      setReleasesByApp((prev) => {
        const next = { ...prev };
        delete next[appId];
        return next;
      });
      setCompatReportsByApp((prev) => {
        const next = { ...prev };
        delete next[appId];
        return next;
      });
      setInstalledVersions((prev) => {
        if (!(appId in prev)) return prev;
        const next = { ...prev };
        delete next[appId];
        return next;
      });
      if (selectedAppId === appId) setSelectedAppId(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `apps/${appId}`, activeAuth);
    }
  };

  const handleDeleteAllApps = async () => {
    for (const app of workspaceApps) {
      await handleDeleteApp(app.id);
    }
  };

  const handleSimulateActivity = async (app: SoftwareApp, type: 'download' | 'active') => {
    try {
      if (type === 'download') {
        await updateDoc(doc(activeDb, 'apps', app.id), {
          downloadsCount: app.downloadsCount + 1,
          updatedAt: serverTimestamp(),
        });
      } else {
        await updateDoc(doc(activeDb, 'apps', app.id), {
          activeUsersCount: app.activeUsersCount + 1,
          updatedAt: serverTimestamp(),
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `apps/${app.id}`, activeAuth);
    }
  };

  const handlePortalInstall = async (app: SoftwareApp, _os: TargetOS) => {
    // Register app as installed on this device so future updates trigger real-time notifications
    setInstalledVersions((prev) => ({
      ...prev,
      [app.id]: app.latestVersion,
    }));
    prevVersionsRef.current[app.id] = app.latestVersion;

    if (user && (app.visibility === 'public' || app.ownerId === user.uid)) {
      try {
        await updateDoc(doc(activeDb, 'apps', app.id), {
          downloadsCount: increment(1),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `apps/${app.id}`, activeAuth);
      }
    }
  };

  const handleCreateApiKey = async (label: string, appId: string, scopes: string[]): Promise<string> => {
    if (!user) return '';
    const randomPart = Array.from(crypto.getRandomValues(new Uint8Array(18)))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
    const rawKey = `ak_live_${randomPart}`;
    const prefix = rawKey.slice(0, 14);
    const keyHash = await sha256Hex(rawKey);
    const keyId = `key_${Date.now().toString(36)}`;

    try {
      await setDoc(doc(activeDb, 'api_keys', keyId), {
        id: keyId,
        ownerId: user.uid,
        appId,
        label,
        prefix,
        keyHash,
        scopes,
        status: 'active',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `api_keys/${keyId}`, activeAuth);
    }
    return rawKey;
  };

  const handleRevokeOrDeleteKey = async (key: ApiKeyRecord, action: 'revoke' | 'delete') => {
    try {
      if (action === 'delete') {
        await deleteDoc(doc(activeDb, 'api_keys', key.id));
      } else {
        await updateDoc(doc(activeDb, 'api_keys', key.id), {
          status: 'revoked',
          updatedAt: serverTimestamp(),
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `api_keys/${key.id}`, activeAuth);
    }
  };

  const handleGenerateReport = async (app: SoftwareApp, period: ReportPeriod) => {
    if (!user) return;
    const reportId = `rep_${Date.now().toString(36)}`;
    const autoUpdateRate = app.autoUpdate ? 96.8 : 42.0;
    const summary = `تقرير ${period === 'daily' ? 'يومي' : period === 'weekly' ? 'أسبوعي' : 'شهري'} لتطبيق ${app.name} (الإصدار v${app.latestVersion}): استقرار بنسبة ${app.crashFreeRate}% مع ${app.activeUsersCount.toLocaleString('en-US')} مستخدم نشط ومعدل استجابة للتحديث التلقائي ${autoUpdateRate}%.`;

    try {
      await setDoc(doc(activeDb, 'reports', reportId), {
        id: reportId,
        ownerId: user.uid,
        appId: app.id,
        appName: app.name,
        period,
        totalDownloads: app.downloadsCount,
        activeUsers: app.activeUsersCount,
        autoUpdateRate,
        crashFreeRate: app.crashFreeRate,
        summary,
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `reports/${reportId}`, activeAuth);
    }
  };

  const handleDeleteReport = async (reportId: string) => {
    try {
      await deleteDoc(doc(activeDb, 'reports', reportId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `reports/${reportId}`, activeAuth);
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  // Loading state while Firebase Auth settles
  if (!authReady) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center" dir="rtl">
        <div className="flex items-center gap-3 text-sm text-slate-600 dark:text-slate-300">
          <RefreshCw className="w-4 h-4 animate-spin text-emerald-600" />
          <span>جاري الاتصال بمنصة AlKarim...</span>
        </div>
      </div>
    );
  }

  // Standalone Public Direct Download Portal for unauthenticated clients
  if (publicPortalStandalone && !user) {
    return (
      <DirectInstallPortal
        apps={publicApps}
        releasesByApp={releasesByApp}
        installedVersions={installedVersions}
        initialSelectedAppId={initialPortalAppParam}
        onDownloadAndInstall={handlePortalInstall}
        getAuthToken={async () => activeAuth.currentUser?.getIdToken()}
        isPublicStandalone
        onBackToLogin={() => setPublicPortalStandalone(false)}
      />
    );
  }

  // Recovery screen if Firestore profile initialization failed
  if (authSyncError && user) {
    let readableError = authSyncError;
    try {
      const parsed = JSON.parse(authSyncError) as { error?: string; operationType?: string; path?: string };
      if (parsed.error) {
        readableError = `تعذر مزامنة الحساب (${parsed.path || parsed.operationType || 'users'}): ${parsed.error}`;
      }
    } catch {
      // plain string
    }
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-6" dir="rtl">
        <div className="max-w-md w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center space-y-4">
          <div className="w-12 h-12 mx-auto rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 flex items-center justify-center text-red-600 dark:text-red-400">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">تعذر إكمال تهيئة الحساب</h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed break-words">{readableError}</p>
          <div className="flex flex-col gap-2.5 pt-2">
            <button
              type="button"
              onClick={handleRetryUserSync}
              className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium transition-colors"
            >
              إعادة المحاولة
            </button>
            <button
              type="button"
              onClick={() => signOut(activeAuth)}
              className="w-full py-2 px-4 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-medium transition-colors"
            >
              تسجيل الخروج
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Auth Gate (Direct Login / Register)
  if (!user) {
    return (
      <AuthGate
        selectedRole={pendingRole}
        onSelectRole={handleSelectPendingRole}
        entryMode={entryMode}
        onSwitchEntryMode={handleSwitchEntryMode}
        authInstance={activeAuth}
        externalError={portalRoleError}
        onClearExternalError={() => setPortalRoleError(null)}
        onOpenPublicPortal={() => {
          handleSwitchEntryMode('client');
          setPublicPortalStandalone(true);
        }}
      />
    );
  }

  const developerOnlyNav: { id: NavSection; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'analytics', label: 'لوحة الإحصائيات', icon: BarChart3 },
    { id: 'apps', label: 'التطبيقات والتحديثات', icon: Layers },
    { id: 'api', label: 'التكامل البرمجي API', icon: Code2 },
    { id: 'reports', label: 'التقارير الدورية', icon: FileBarChart },
  ];

  const userFacingNav: { id: NavSection; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'portal', label: 'بوابة التحميل المباشر', icon: Download },
    { id: 'security', label: 'الحساب والإشعارات', icon: ShieldCheck },
  ];

  const mobileNavItems = showDeveloperUI
    ? [...developerOnlyNav, ...userFacingNav]
    : userFacingNav;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex" dir="rtl">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 shrink-0 flex-col justify-between bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 sticky top-0 h-screen">
        <div className="p-5 space-y-6">
          <div className="flex items-center gap-3 px-2">
            <img
              src="/src/assets/images/alkarim_brand_emblem_1795296596572.jpg"
              alt="شعار AlKarim"
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-lg object-cover border border-slate-200 dark:border-slate-700"
            />
            <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
              AlKarim
            </span>
          </div>

          <nav className="space-y-4">
            {showDeveloperUI && (
              <div>
                <div className="px-3 mb-1.5 text-[11px] font-semibold text-slate-400">
                  لوحة المطور (للمطور فقط)
                </div>
                <div className="space-y-1">
                  {developerOnlyNav.map((item) => {
                    const Icon = item.icon;
                    const active = activeSection === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setActiveSection(item.id)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                          active
                            ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                            : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-emerald-600 dark:text-emerald-400' : ''}`} />
                        <span>{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <div>
              {showDeveloperUI && (
                <div className="px-3 mb-1.5 text-[11px] font-semibold text-slate-400">
                  بوابة المستخدمين والحساب
                </div>
              )}
              <div className="space-y-1">
                {userFacingNav.map((item) => {
                  const Icon = item.icon;
                  const active = activeSection === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setActiveSection(item.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                        active
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                          : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-emerald-600 dark:text-emerald-400' : ''}`} />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </nav>
        </div>

        {/* Bottom User Profile */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3 mb-3">
            <img
              src={user.photoURL || '/src/assets/images/avatar_developer_karim_1795296596397.jpg'}
              alt={user.displayName || 'المطور'}
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
            />
            <div className="min-w-0">
              <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                {user.displayName || user.email?.split('@')[0]}
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                {isDeveloperAccount && !isClientRoute ? 'حساب مطور' : 'حساب عميل'}
              </div>
            </div>
          </div>
          <div className="space-y-2">
            {isDeveloperAccount && !isClientRoute && (
              <button
                type="button"
                onClick={() => setLinksModalOpen(true)}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg border border-emerald-200 dark:border-emerald-900/70 bg-emerald-50/70 dark:bg-emerald-950/40 hover:bg-emerald-100/80 dark:hover:bg-emerald-950/70 text-xs font-medium text-emerald-800 dark:text-emerald-300 transition-colors"
              >
                <Link2 className="w-3.5 h-3.5" />
                روابط المطور والعملاء
              </button>
            )}
            <button
              type="button"
              onClick={() => signOut(activeAuth)}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              تسجيل الخروج
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="fixed inset-0 bg-slate-950/50" onClick={() => setMobileMenuOpen(false)} />
          <div className="relative w-72 bg-white dark:bg-slate-900 h-full p-5 flex flex-col justify-between z-10 border-l border-slate-200 dark:border-slate-800">
            <div>
              <div className="flex items-center justify-between mb-6">
                <span className="text-lg font-bold text-slate-900 dark:text-white">AlKarim</span>
                <button type="button" onClick={() => setMobileMenuOpen(false)} aria-label="إغلاق القائمة">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <nav className="space-y-1">
                {mobileNavItems.map((item) => {
                  const Icon = item.icon;
                  const active = activeSection === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setActiveSection(item.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium ${
                        active
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            </div>
            <button
              type="button"
              onClick={() => signOut(activeAuth)}
              className="w-full py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium"
            >
              تسجيل الخروج
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Bar (3-zone contract) */}
        <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm border-b border-slate-200 dark:border-slate-800 px-4 sm:px-8 h-16 flex items-center justify-between gap-4">
          {/* Zone 1: Breadcrumb + Mobile Menu */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-lg border border-slate-200 dark:border-slate-700"
              aria-label="فتح القائمة"
            >
              <Menu className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2 text-xs sm:text-sm truncate">
              <span className="text-slate-400 hidden sm:inline">منصة AlKarim</span>
              <span className="text-slate-300 hidden sm:inline">/</span>
              <h1 className="font-bold text-slate-900 dark:text-white truncate">
                {SECTION_TITLES[activeSection]}
              </h1>
            </div>
          </div>

          {/* Zone 2 & 3: Real-time Notifications, Theme Toggle & Primary CTA */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Real-Time Notifications Bell */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setNotifOpen((o) => !o);
                  setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
                }}
                aria-label="إشعارات التحديث الفورية"
                className="relative p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -left-1 w-4 h-4 rounded-full bg-emerald-600 text-white text-[10px] font-mono flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>

              {notifOpen && (
                <div className="absolute left-0 mt-2 w-80 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-lg p-4 z-50">
                  <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-slate-100 dark:border-slate-800">
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      إشعارات التحديث الفورية
                    </span>
                    <button
                      type="button"
                      onClick={() => setNotifOpen(false)}
                      className="text-xs text-slate-400 hover:text-slate-700"
                    >
                      إغلاق
                    </button>
                  </div>
                  {notifications.length === 0 ? (
                    <p className="text-xs text-slate-500 py-4 text-center">
                      لا توجد إشعارات تحديث جديدة حالياً. عند دفع أي تحديث لتطبيق مثبّت سيظهر التنبيه فوراً هنا.
                    </p>
                  ) : (
                    <div className="space-y-2.5 max-h-64 overflow-y-auto">
                      {notifications.map((n) => (
                        <div
                          key={n.id}
                          className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 text-xs"
                        >
                          <div className="flex items-center justify-between font-semibold text-slate-900 dark:text-white">
                            <span>{n.appName}</span>
                            <span className="font-mono text-[11px] text-emerald-700 dark:text-emerald-400">
                              v{n.version}
                            </span>
                          </div>
                          <p className="text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">{n.message}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              aria-label="تبديل المظهر الفاتح والداكن"
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {isDeveloperAccount && !isClientRoute && (
              <button
                type="button"
                onClick={() => setLinksModalOpen(true)}
                aria-label="روابط المطور والعملاء"
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap shrink-0"
              >
                <Link2 className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden sm:inline">روابط المنصة</span>
              </button>
            )}

            {isDeveloperAccount && !isClientRoute && (
              <button
                type="button"
                onClick={() => {
                  setPreviewAsUser((prev) => {
                    const next = !prev;
                    setActiveSection(next ? 'portal' : 'analytics');
                    return next;
                  });
                }}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap shrink-0"
              >
                <Eye className="w-3.5 h-3.5 text-emerald-600" />
                {previewAsUser ? 'العودة للوحة المطور' : 'معاينة واجهة العميل'}
              </button>
            )}

            {showDeveloperUI && (
              <button
                type="button"
                onClick={() => {
                  setActiveSection('apps');
                  setCreateModalTrigger((c) => c + 1);
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium transition-colors whitespace-nowrap shrink-0"
              >
                <Plus className="w-4 h-4" />
                رفع برنامج جديد
              </button>
            )}
          </div>
        </header>

        {/* Developer User-Preview Notice Banner */}
        {isDeveloperAccount && !isClientRoute && previewAsUser && (
          <div className="mx-4 sm:mx-8 mt-4 p-3.5 rounded-xl bg-slate-900 text-white border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5">
              <Eye className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                أنت تعاين المنصة الآن كما يراها المستخدم العادي (الإحصائيات، رفع التطبيقات، اختبارات التوافق، ومفاتيح API مخفية تماماً).
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                setPreviewAsUser(false);
                setActiveSection('analytics');
              }}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-medium whitespace-nowrap shrink-0"
            >
              العودة للوحة المطور
            </button>
          </div>
        )}

        {/* Live Update Notification Toast */}
        {activeToast && (
          <div className="mx-4 sm:mx-8 mt-4 p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 flex items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-2.5 text-emerald-900 dark:text-emerald-200">
              <RefreshCw className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{activeToast.message}</span>
            </div>
            <button
              type="button"
              onClick={() => setActiveToast(null)}
              className="text-emerald-700 dark:text-emerald-300 hover:underline shrink-0"
            >
              إخفاء
            </button>
          </div>
        )}

        {/* Active View Content */}
        <main className="flex-1 p-4 sm:p-8 max-w-7xl w-full mx-auto">
          {showDeveloperUI && activeSection === 'analytics' && (
            <AnalyticsDashboard
              apps={workspaceApps}
              syncFromCache={syncFromCache}
              onSimulateActivity={handleSimulateActivity}
              onDeleteApp={handleDeleteApp}
              onSelectApp={(appId) => {
                setSelectedAppId(appId);
                setActiveSection('apps');
              }}
            />
          )}

          {showDeveloperUI && activeSection === 'apps' && (
            <AppsManager
              apps={workspaceApps}
              releasesByApp={releasesByApp}
              compatReportsByApp={compatReportsByApp}
              selectedAppId={selectedAppId}
              onSelectApp={setSelectedAppId}
              onCreateApp={handleCreateApp}
              onPublishUpdate={handlePublishUpdate}
              onPublishScheduledNow={handleActivateScheduledRelease}
              onDeleteRelease={handleDeleteRelease}
              onToggleAutoUpdate={handleToggleAutoUpdate}
              onDeleteApp={handleDeleteApp}
              onDeleteAllApps={handleDeleteAllApps}
              onOpenInPortal={(appId) => {
                setSelectedAppId(appId);
                setActiveSection('portal');
              }}
              openCreateModalTrigger={createModalTrigger}
            />
          )}

          {activeSection === 'portal' && (
            <DirectInstallPortal
              apps={allVisibleApps}
              releasesByApp={releasesByApp}
              installedVersions={installedVersions}
              initialSelectedAppId={selectedAppId || initialPortalAppParam}
              onDownloadAndInstall={handlePortalInstall}
              getAuthToken={async () => activeAuth.currentUser?.getIdToken()}
            />
          )}

          {showDeveloperUI && activeSection === 'api' && (
            <ApiIntegrationView
              apps={workspaceApps}
              apiKeys={apiKeys}
              onCreateApiKey={handleCreateApiKey}
              onRevokeOrDeleteKey={handleRevokeOrDeleteKey}
            />
          )}

          {showDeveloperUI && activeSection === 'reports' && (
            <ReportsView
              apps={workspaceApps}
              reports={reports}
              onGenerateReport={handleGenerateReport}
              onDeleteReport={handleDeleteReport}
            />
          )}

          {activeSection === 'security' && (
            <SecuritySettingsView
              user={user}
              notificationPermission={notificationPermission}
              onRequestNotifications={handleRequestNotifications}
            />
          )}
        </main>
      </div>

      <PortalLinksModal
        open={linksModalOpen}
        onClose={() => setLinksModalOpen(false)}
        selectedApp={workspaceApps.find((a) => a.id === selectedAppId) || workspaceApps[0] || null}
        onOpenInCurrentTab={handleSwitchEntryMode}
      />
    </div>
  );
}
